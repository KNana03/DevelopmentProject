using SupplierCRUD.Models;
using SupplierCRUD.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.DataProtection;
using SupplierCRUD.Repositories;

namespace SupplierCRUD
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var configuration = builder.Configuration;

            // Add services to the container
            ConfigureServices(builder.Services, configuration);

            var app = builder.Build();

            // Configure the HTTP request pipeline
            ConfigureMiddleware(app);

            app.Run();
        }

        private static void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));

            services.AddIdentity<IdentityUser, IdentityRole>()
                .AddEntityFrameworkStores<AppDbContext>()
                .AddDefaultTokenProviders();

            services.Configure<IdentityOptions>(opts =>
                opts.SignIn.RequireConfirmedEmail = true);

            services.Configure<DataProtectionTokenProviderOptions>(opts =>
                opts.TokenLifespan = TimeSpan.FromHours(10));

            // Data Protection Configuration
            services.AddDataProtection()
                .PersistKeysToFileSystem(new DirectoryInfo(@"C:\keys"))
                .SetApplicationName("SupplierCRUD");

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {
                options.SaveToken = true;
                options.RequireHttpsMetadata = false;
                options.TokenValidationParameters = new TokenValidationParameters()
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ClockSkew = TimeSpan.Zero,
                    ValidAudience = configuration["JWT:ValidAudience"],
                    ValidIssuer = configuration["JWT:ValidIssuer"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["JWT:Secret"]))
                };
            });

            var emailConfig = configuration.GetSection("EmailConfiguration").Get<EmailConfiguration>();
            services.AddSingleton(emailConfig);
            services.AddScoped<IEmailService, EmailService>();
            services.AddHttpContextAccessor(); // Needed to get the IP address
            // Register other services
            services.AddScoped<IExcelImportService, ExcelImportService>();
            services.AddScoped<ISupplierRepository, SupplierRepository>();
            services.AddScoped<IAdminRepository, AdminRepository>();
            services.AddScoped<IStaffRepository, StaffRepository>();
            services.AddScoped<IProductRepository, ProductRepository>();
            services.AddScoped<IOrderRepository, OrderRepository>();
            services.AddScoped<IRecommendationService, RecommendationService>();
            services.AddScoped<ICategoryRepository, CategoryRepository>();
            services.AddScoped<IBrandRepository, BrandRepository>();
            services.AddScoped<IShiftTypeRepository, ShiftTypeRepository>();
            services.AddScoped<IShiftRepository, ShiftRepository>();
            services.AddScoped<IShiftService, ShiftService>();
            services.AddScoped<IShiftAssignmentRepository, ShiftAssignment_repository>();
            services.AddScoped<IInventoryService, InventoryService>();
            services.AddScoped<IInventoryTypeService, InventoryTypeService>();
            services.AddScoped<IWriteOffReasonService, WriteOffReasonService>();
            services.AddScoped<IExcelExportService, ExcelExportService>();
            // Register InventoryTypeService
            services.AddScoped<IInventoryTypeService, InventoryTypeService>();
            services.AddScoped<IStaffAttendanceRepository, StaffAttendanceRepository>();
            services.AddScoped<IStaffAttendanceService, StaffAttendanceService>();
            services.AddScoped<IVATRepository, VATRepository>();
            services.AddScoped<IProductInventoryService, ProductInventoryService>();
            services.AddScoped<IDocumentRepository, Models.DocumentRepository>();
            services.AddScoped<IStockTakeRepository, StockTakeRepository>();
            services.AddScoped<ICustomerReviewService, CustomerReviewService>();
            services.AddScoped<ICountryRepository, CountryRepository>();
            services.AddScoped<IWarehouseRepository, WarehouseRepository>();
            services.AddScoped<IAuditTrailService, AuditTrailService>();
            services.AddDistributedMemoryCache();

           services.AddSession(options =>
            {
                var sessionTimeout = configuration.GetValue<int>("SessionTimeout");
                options.IdleTimeout = TimeSpan.FromMinutes(sessionTimeout);
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
            });
            // Register IHttpClientFactory
            services.AddHttpClient();

            // Register the Google Custom Search API key and CSE ID as configuration
            services.AddSingleton(new GoogleSearchConfig
            {
                ApiKey = configuration["GoogleSearchConfig:ApiKey"],
                CseId = configuration["GoogleSearchConfig:CseId"]
            });

            // Register OpenAI configuration
            services.Configure<OpenAIConfig>(configuration.GetSection("OpenAI"));

            // CORS configuration
            services.AddCors(options =>
            {
                options.AddPolicy("AllowSpecificOrigin",
                    builder => builder
                        .WithOrigins("http://localhost:8100") // Add your frontend URL here
                        .AllowAnyHeader()
                        .AllowAnyMethod());
            });

            services.AddControllers();

            // Swagger configuration
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen(option =>
            {
                option.SwaggerDoc("v1", new OpenApiInfo { Title = "Auth API", Version = "v1" });
                option.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    In = ParameterLocation.Header,
                    Description = "Please enter a valid JWT token",
                    Name = "Authorization",
                    Type = SecuritySchemeType.Http,
                    BearerFormat = "JWT",
                    Scheme = "Bearer"
                });
                option.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        new string[] {}
                    }
                });
            });

            services.AddLogging(loggingBuilder =>
            {
                loggingBuilder.ClearProviders();
                loggingBuilder.AddConsole();
            });
        }

        private static void ConfigureMiddleware(WebApplication app)
        {
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            app.UseCors("AllowSpecificOrigin"); // Apply the CORS policy
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseSession();
            app.MapControllers();
        }
    }

    // Configuration classes
    public class GoogleSearchConfig
    {
        public string ApiKey { get; set; }
        public string CseId { get; set; }
    }

    public class OpenAIConfig
    {
        public string ApiKey { get; set; }
    }

    public class EmailConfiguration
    {
        public string From { get; set; }
        public string SmtpServer { get; set; }
        public int Port { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
