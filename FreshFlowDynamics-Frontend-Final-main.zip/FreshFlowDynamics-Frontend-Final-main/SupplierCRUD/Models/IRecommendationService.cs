﻿namespace SupplierCRUD.Models
{
    public interface IRecommendationService
    {
        Task<IEnumerable<Product>> GetRecommendationsAsync();
    }
}
