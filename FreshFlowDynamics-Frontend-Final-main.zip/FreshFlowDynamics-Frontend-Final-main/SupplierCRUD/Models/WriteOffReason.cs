﻿using System.ComponentModel.DataAnnotations;

namespace SupplierCRUD.Models
{
    public class WriteOffReason
    {
        public int Id { get; set; }

        [Required]
        [StringLength(500)]
        public string Reason { get; set; }
    }
}
