﻿namespace SupplierCRUD.Models
{
    public class ShiftAssignment
    {
        public int Id { get; set; }
        public int StaffId { get; set; }
        public Staff Staff { get; set; }
        public int ShiftId { get; set; }
        public Shift Shift { get; set; }
        public int ScanCount { get; set; } // Track number of scans
        // Add navigation property for QR codes if needed
      
    }
}
