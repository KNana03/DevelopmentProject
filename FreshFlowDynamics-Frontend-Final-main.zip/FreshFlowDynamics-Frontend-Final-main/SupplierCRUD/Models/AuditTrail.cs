﻿namespace SupplierCRUD.Models
{
    public class AuditTrail
    {
        public int Id { get; set; }
        public string Event { get; set; }  // Type of event: Sale, Purchase, CheckIn, CheckOut, UserActivity
        public int EntityId { get; set; }  // ID of the entity involved
        public string UserId { get; set; } // ID of the user who performed the action
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string? OldValue { get; set; }  // Previous value of the data (if applicable)
        public string? NewValue { get; set; }  // New value of the data
        public string Description { get; set; }  // Brief description of the event
        public string? IPAddress { get; set; }  // IP address from where the action was performed
    }
}
