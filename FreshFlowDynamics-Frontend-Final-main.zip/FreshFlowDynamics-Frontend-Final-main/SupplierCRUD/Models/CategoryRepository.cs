﻿using Microsoft.EntityFrameworkCore;
using SupplierCRUD.Models;

namespace SupplierCRUD.Models
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly AppDbContext _context;

        public CategoryRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Category>> GetAllCategories()
        {
            return await _context.Categories.ToListAsync();
        }

        public Category GetCategory(int id)
        {
            return _context.Categories.Where(p => p.CategoryId == id).FirstOrDefault();
        }

        public bool CategoryAvailable(int catId)
        {
            return _context.Categories.Any(p => p.CategoryId == catId);
        }

        public async Task<Category> CreateCategoryAsync(Category category)
        {
            _context.Categories.Add(category);
            await _context.SaveChangesAsync();
            return category;
        }

        public async Task<Category> UpdateCategoryAsync(Category category)
        {
            _context.Entry(category).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return category;
        }

        public async Task DeleteCategoryAsync(int id)
        {
            var category = await _context.Categories.FindAsync(id);
            if (category != null)
            {
                _context.Categories.Remove(category);
                await _context.SaveChangesAsync();
            }
        }
    }


    /*public static class CategoryEndpoints
    {
        public static void MapCategoryEndpoints (this IEndpointRouteBuilder routes)
        {
            routes.MapGet("/api/Category", () =>
            {
                return new [] { new Category() };
            })
            .WithName("GetAllCategories")
            .Produces<Category[]>(StatusCodes.Status200OK);

            routes.MapGet("/api/Category/{id}", (int id) =>
            {
                //return new Category { ID = id };
            })
            .WithName("GetCategoryById")
            .Produces<Category>(StatusCodes.Status200OK);

            routes.MapPut("/api/Category/{id}", (int id, Category input) =>
            {
                return Results.NoContent();
            })
            .WithName("UpdateCategory")
            .Produces(StatusCodes.Status204NoContent);

            routes.MapPost("/api/Category/", (Category model) =>
            {
                //return Results.Created($"//api/Categories/{model.ID}", model);
            })
            .WithName("CreateCategory")
            .Produces<Category>(StatusCodes.Status201Created);

            routes.MapDelete("/api/Category/{id}", (int id) =>
            {
                //return Results.Ok(new Category { ID = id });
            })
            .WithName("DeleteCategory")
            .Produces<Category>(StatusCodes.Status200OK);
        }
    }*/
}