﻿namespace SupplierCRUD.Models
{
    public interface IBrandRepository
    {
        Task<IEnumerable<Brand>> GetAllBrands();
        Brand GetBrand(int id);
        Task<Brand> CreateBrandAsync(Brand brand);
        Task<Brand> UpdateBrandAsync(Brand brand);
        Task DeleteBrandAsync(int id);
        bool BrandAvailable(int catId);
    }
}
