﻿namespace SupplierCRUD.Models
{
    public interface IOrderRepository
    {
        Task<IEnumerable<Order>> GetAllOrdersAsync();
        Task<Order> GetOrderByIdAsync(int id);
        Task<Order> CreateOrderAsync(Order order);
        Task UpdateOrderAsync(Order order);
        Task ReceiveOrderAsync(int id);
        Task PaySupplierAsync(int id);
        Task DeleteOrderAsync(int id);
        Task<IEnumerable<PaymentType>> GetPaymentTypesAsync();

    }
}
