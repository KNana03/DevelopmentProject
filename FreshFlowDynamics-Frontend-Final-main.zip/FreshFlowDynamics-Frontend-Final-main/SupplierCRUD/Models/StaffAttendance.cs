﻿namespace SupplierCRUD.Models
{
    namespace SupplierCRUD.Models
    {
        public class StaffAttendance
        {
            public int Id { get; set; }
            public int StaffId { get; set; }
            public int ShiftAssignmentId { get; set; }
            public DateTime CheckInTime { get; set; }
            public DateTime? CheckOutTime { get; set; }
            public bool IsCheckedIn { get; set; }
            public bool IsCheckedOut { get; set; }

            // Navigation properties
            public Staff Staff { get; set; }
            public ShiftAssignment ShiftAssignment { get; set; }
        }
    }
}
