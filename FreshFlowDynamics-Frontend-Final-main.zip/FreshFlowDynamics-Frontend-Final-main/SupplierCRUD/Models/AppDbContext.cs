﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SupplierCRUD.Models;
using SupplierCRUD.Models.SupplierCRUD.Models;
using System;
using System.Reflection.Metadata;

namespace SupplierCRUD.Models
{
    public class AppDbContext : IdentityDbContext<IdentityUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<PageRequest> PageRequests { get; set; }
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Staff> Staffs { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Brand> Brands { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Inventory> Inventories { get; set; }
        public DbSet<InventoryType> InventoryTypes { get; set; }
        public DbSet<WriteOffReason> WriteOffReasons { get; set; }
        public DbSet<Sales> Sales { get; set; }
        public DbSet<Shift> Shifts { get; set; }
        public DbSet<ShiftAssignment> ShiftAssignments { get; set; }
        public DbSet<ShiftType> ShiftTypes { get; set; }
        public DbSet<StaffAttendance> StaffAttendances { get; set; }
        public DbSet<VAT> VAT { get; set; }
        public DbSet<PaymentType> PaymentTypes { get; set; }
        public DbSet<StockTake> StockTakes { get; set; }
        public DbSet<Warehouse> Warehouses { get; set; }
        public DbSet<InventoryWriteOff> InventoryWriteOffs { get; set; }
        public DbSet<ReturnedStock> ReturnedStocks { get; set; }

        public DbSet<Document> Documents { get; set; }
        public DbSet<CustomerReview> CustomerReviews { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<CurrencyExchangeRate> CurrencyExchangeRates { get; set; }
        public DbSet<Discount> Discounts { get; set; }
        public DbSet<SupplierContact> SupplierContacts { get; set; }
        public DbSet<Country> Countries { get; set; }
        public DbSet<State> States { get; set; }
        public DbSet<City> Cities { get; set; }
        public DbSet<AuditTrail> AuditTrails { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Explicitly set the primary key for Product
            modelBuilder.Entity<Product>().HasKey(p => p.ProductId);

            modelBuilder.Entity<VAT>().HasData(
                new VAT
                {
                    VATId = 1,
                    Amount = 0.15m,
                    Date = DateTime.Now
                });

            // Configure the Brand-Category relationship
            modelBuilder.Entity<Brand>()
                .HasOne(b => b.Category)
                .WithMany(c => c.Brands)
                .HasForeignKey(b => b.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure the Product-Brand relationship
            modelBuilder.Entity<Product>()
                .HasOne(p => p.Brand)
                .WithMany(b => b.Products)
                .HasForeignKey(p => p.BrandId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure the Product-Category relationship
            modelBuilder.Entity<Product>()
                .HasOne(p => p.Category)
                .WithMany(c => c.Products)
                .HasForeignKey(p => p.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<StaffAttendance>()
                .HasKey(sa => sa.Id);

            modelBuilder.Entity<StaffAttendance>()
                .Property(sa => sa.CheckInTime)
                .IsRequired();

            modelBuilder.Entity<StaffAttendance>()
                .Property(sa => sa.IsCheckedIn)
                .IsRequired();

            modelBuilder.Entity<StaffAttendance>()
                .HasOne(sa => sa.Staff)
                .WithMany()
                .HasForeignKey(sa => sa.StaffId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<StaffAttendance>()
                .HasOne(sa => sa.ShiftAssignment)
                .WithMany()
                .HasForeignKey(sa => sa.ShiftAssignmentId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<InventoryWriteOff>()
           .HasKey(iw => new { iw.InventoryId, iw.WriteOffReasonId });

            modelBuilder.Entity<InventoryWriteOff>()
                .HasOne(iw => iw.Inventory)
                .WithMany()
                .HasForeignKey(iw => iw.InventoryId);

            modelBuilder.Entity<InventoryWriteOff>()
                .HasOne(iw => iw.WriteOffReason)
                .WithMany()
                .HasForeignKey(iw => iw.WriteOffReasonId);

            modelBuilder.Entity<Shift>()
              .HasOne(s => s.ShiftType)
              .WithMany() // Assuming a one-to-many relationship from ShiftType to Shift
              .HasForeignKey(s => s.ShiftTypeId)
              .OnDelete(DeleteBehavior.Cascade);

            // Example of a one-to-many relationship between Product and CustomerReview
            modelBuilder.Entity<CustomerReview>()
                .HasOne(cr => cr.Product)
                .WithMany()  // Note: Since Product does not have a collection of CustomerReviews, we just specify "WithMany()"
                .HasForeignKey(cr => cr.ProductId)
                .OnDelete(DeleteBehavior.Cascade);

            // Example of a one-to-many relationship between Supplier and SupplierContact
            modelBuilder.Entity<SupplierContact>()
                .HasOne(sc => sc.Supplier)
                .WithMany()  // Note: Since Supplier does not have a collection of SupplierContacts, we just specify "WithMany()"
                .HasForeignKey(sc => sc.SupplierId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Country>()
            .HasMany(c => c.States)
            .WithOne(s => s.Country)
            .HasForeignKey(s => s.CountryId)
            .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Country>()
                .HasMany(c => c.Cities)
                .WithOne(ci => ci.Country)
                .HasForeignKey(ci => ci.CountryId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<State>()
                .HasMany(s => s.Cities)
                .WithOne(ci => ci.State)
                .HasForeignKey(ci => ci.StateId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<State>()
                .HasMany(s => s.Warehouses)
                .WithOne(w => w.State)
                .HasForeignKey(w => w.StateId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<City>()
                .HasMany(ci => ci.Warehouses)
                .WithOne(w => w.City)
                .HasForeignKey(w => w.CityId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Warehouse>()
               .HasOne(w => w.Country)
               .WithMany(c => c.Warehouses)
               .HasForeignKey(w => w.CountryId)
               .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<CurrencyExchangeRate>().HasData(
           new CurrencyExchangeRate
           {
               CurrencyExchangeRateId = 1,
               CurrencyCode = "USD",
               ExchangeRate = 15.50m,
               Date = DateTime.UtcNow
           },
           new CurrencyExchangeRate
           {
               CurrencyExchangeRateId = 2,
               CurrencyCode = "EUR",
               ExchangeRate = 17.80m,
               Date = DateTime.UtcNow
           },
           new CurrencyExchangeRate
           {
               CurrencyExchangeRateId = 3,
               CurrencyCode = "GBP",
               ExchangeRate = 20.50m,
               Date = DateTime.UtcNow
           }
       );


            modelBuilder.Entity<PaymentType>().HasData(
               new PaymentType { Id = 1, Type = "Cash" },
               new PaymentType { Id = 2, Type = "Card" }
           );

            modelBuilder.Entity<Category>().HasData(
                new Category
                {
                    CategoryId = 1,
                    Name = "Packaged Goods",
                    Description = "Packaged Goods",
                    DateCreated = DateTime.Now
                },
                new Category
                {
                    CategoryId = 2,
                    Name = "Beverages",
                    Description = "Drinks",
                    DateCreated = DateTime.Now
                });

            modelBuilder.Entity<Brand>().HasData(
                new Brand
                {
                    BrandId = 1,
                    Name = "Liqui Fruit",
                    Description = "The first ever long-shelf life fruit juice",
                    CategoryId = 2, // Link to Beverages category
                    DateCreated = DateTime.Now
                },
                new Brand
                {
                    BrandId = 2,
                    Name = "Magnum",
                    Description = "A rich coat of chocolate, ice cream infused with Madagascan Bourbon vanilla.",
                    CategoryId = 1, // Link to Packaged Goods category
                    DateCreated = DateTime.Now
                });

            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    ProductId = 1,
                    Name = "Orange Juice",
                    Description = "Orange",
                    QuantityOnHand = 180,
                    Price = 1200.99m,
                    BrandId = 1,
                    CategoryId = 2,
                    DateCreated = DateTime.Now
                },
                new Product
                {
                    ProductId = 2,
                    Name = "Magnum White Ice Cream Pint",
                    Description = "Dairy (reconstituted skim milk, whole milk powder, skim milk powder and/or concentrate, butteroil, skim milk powder, cream (17%)), sugar, cocoa components* (8%), (cocoa butter and cocoa mass), glucose-fructose syrup, glucose syrup, emulsifiers (E471, E442, E476), stabilisers (E410, E412, E407 (contains wheat), vanilla bean pieces, flavourings, colour (160a). *100% Cocoa components from Rain Forest Alliance Certified™ farms",
                    QuantityOnHand = 160,
                    Price = 19.99m,
                    BrandId = 2,
                    CategoryId = 1,
                    DateCreated = DateTime.Now
                });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(e => e.Price).HasColumnType("decimal(18,2)");
            });

            SeedRoles(modelBuilder);
        }

        private static void SeedRoles(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<IdentityRole>().HasData(
                new IdentityRole() { Name = "Admin", ConcurrencyStamp = "1", NormalizedName = "ADMIN" },
                new IdentityRole() { Name = "Staff", ConcurrencyStamp = "2", NormalizedName = "STAFF" },
                new IdentityRole() { Name = "WarehouseManager", ConcurrencyStamp = "3", NormalizedName = "WAREHOUSEMANAGER" },
                new IdentityRole() { Name = "Cashier", ConcurrencyStamp = "4", NormalizedName = "CASHIER" }
            );
        }
    }
}
