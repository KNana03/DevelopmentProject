﻿namespace SupplierCRUD.Models
{
    public class Category : BaseEntity
    {
        public int CategoryId { get; set; }

        public virtual ICollection<Product> Products { get; set; }
        public virtual ICollection<Brand> Brands { get; set; } // Add this line
    }

}
