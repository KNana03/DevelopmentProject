﻿namespace SupplierCRUD.Models
{
    public class InventoryWriteOff
    {
        public int Id { get; set; }

        // Foreign key to the Inventory table
        public int InventoryId { get; set; }
        public Inventory Inventory { get; set; }

        // Foreign key to the WriteOffReason table
        public int WriteOffReasonId { get; set; }
        public WriteOffReason WriteOffReason { get; set; }

        // New field to store the quantity written off
        public int Quantity { get; set; }
    }
}
