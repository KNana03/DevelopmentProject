﻿namespace SupplierCRUD.Models
{
    public interface ICountryRepository
    {
        Task<IEnumerable<Country>> GetAllCountries();
        Country GetCountry(int id);
        Task<Country> CreateCountryAsync(Country country);
        Task<Country> UpdateCountryAsync(Country country);
        Task DeleteCountryAsync(int id);
        bool CountryAvailable(int countryId);

        // relates to State
        Task<IEnumerable<State>> GetAllStatesAsync();
        Task<State> GetStateAsync(int id);
        Task<State> CreateStateAsync(State state);
        Task<State> UpdateStateAsync(State state);
        Task DeleteStateAsync(int id);
        bool StateAvailable(int stateId);

        // relates to City
        Task<IEnumerable<City>> GetAllCitiesAsync();
        Task<City> GetCityAsync(int id);
        Task<City> CreateCityAsync(City city);
        Task<City> UpdateCityAsync(City city);
        Task DeleteCityAsync(int id);
        bool CityAvailable(int cityId);

    }
}
