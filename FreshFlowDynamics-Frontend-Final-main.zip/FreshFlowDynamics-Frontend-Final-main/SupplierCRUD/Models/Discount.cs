﻿namespace SupplierCRUD.Models
{
    public class Discount
    {
        public int DiscountId { get; set; }
        public string Name { get; set; }
        public decimal Percentage { get; set; } // Percentage discount
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int ProductId { get; set; }
        public Product Product { get; set; }
    }
}

