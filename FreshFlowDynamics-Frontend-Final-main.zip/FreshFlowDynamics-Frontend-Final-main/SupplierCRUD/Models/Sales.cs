﻿using System.ComponentModel.DataAnnotations;

namespace SupplierCRUD.Models
{
    public class Sales
    {
        public int Id { get; set; }

        [Required]
        public int StaffId { get; set; }

        [Required]
        public int ShiftId { get; set; }

        [Required]
        public int InventoryId { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Quantity must be greater than zero.")]
        public int Quantity { get; set; }

        [Required]
        public DateTime Date { get; set; }
    }
}
