﻿using System.ComponentModel.DataAnnotations;

namespace SupplierCRUD.Models
{
    public class Inventory
    {
        public int Id { get; set; }

        // Removed the [Required] attribute for ProductId, as it will now be automatically assigned
        public int ProductId { get; set; }

        [Required]
        public int WarehouseId { get; set; }

        [Required]
        public int TypeId { get; set; } // TypeId will now automatically be set to non-sellable (e.g., 1)

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Range(0, int.MaxValue)]
        public int Quantity { get; set; }

        [Required]
        [StringLength(50)]
        public string InventoryType { get; set; }
    }
}
