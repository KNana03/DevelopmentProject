﻿namespace SupplierCRUD.Models
{
    public class SupplierContact
    {
        public int SupplierContactId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public int SupplierId { get; set; }
        public Supplier Supplier { get; set; }
    }


}
