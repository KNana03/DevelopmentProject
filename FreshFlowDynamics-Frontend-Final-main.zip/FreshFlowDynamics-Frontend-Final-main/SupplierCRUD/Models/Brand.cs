﻿namespace SupplierCRUD.Models
{
    public class Brand : BaseEntity
    {
        public int BrandId { get; set; }
        public int CategoryId { get; set; } // Add this line
        public virtual Category Category { get; set; } // Add this line
        public virtual ICollection<Product> Products { get; set; }
    }

}
