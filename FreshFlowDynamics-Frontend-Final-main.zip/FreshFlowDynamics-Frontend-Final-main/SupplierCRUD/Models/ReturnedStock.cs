﻿namespace SupplierCRUD.Models
{
    public class ReturnedStock
    {
        public int Id { get; set; }
        public int InventoryId { get; set; }    // Reference to the inventory item
        public int StaffId { get; set; }        // Reference to the staff member handling the return
        public int SaleId { get; set; }         // Reference to the original sale
        public int Quantity { get; set; }       // Quantity being returned
        public string Reason { get; set; }      // Reason for the return
        public DateTime ReturnDate { get; set; } = DateTime.UtcNow; // Date of return
    }
}
