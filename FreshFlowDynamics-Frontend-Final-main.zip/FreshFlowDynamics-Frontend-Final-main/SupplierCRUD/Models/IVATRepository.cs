﻿namespace SupplierCRUD.Models
{
    public interface IVATRepository
    {
        Task<IEnumerable<VAT>> GetVAT();
        Task<VAT> UpdateVATAsync(VAT vat);
    }
}