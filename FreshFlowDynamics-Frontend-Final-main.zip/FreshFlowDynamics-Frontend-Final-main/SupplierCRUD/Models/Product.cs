﻿namespace SupplierCRUD.Models
{
    public class Product : BaseEntity
    {
        public int ProductId { get; set; }  // Ensure this property is explicitly defined and is an integer
        public int QuantityOnHand { get; set; }
        public decimal Price { get; set; }
        public string? Image { get; set; }
        public int BrandId { get; set; }
        public int CategoryId { get; set; }
        public Category Category { get; set; }
        public Brand Brand { get; set; }
    }
}
