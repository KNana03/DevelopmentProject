﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SupplierCRUD.Models
{
    public class CountryRepository : ICountryRepository
    {
        private readonly AppDbContext _context;

        public CountryRepository(AppDbContext context)
        {
            _context = context;
        }

        // Country Methods
        public async Task<IEnumerable<Country>> GetAllCountries()
        {
            return await _context.Countries.ToListAsync();
        }

        public Country GetCountry(int id)
        {
            return _context.Countries.Where(p => p.CountryId == id).FirstOrDefault();
        }

        public bool CountryAvailable(int countryId)
        {
            return _context.Countries.Any(p => p.CountryId == countryId);
        }

        public async Task<Country> CreateCountryAsync(Country country)
        {
            _context.Countries.Add(country);
            await _context.SaveChangesAsync();
            return country;
        }

        public async Task<Country> UpdateCountryAsync(Country country)
        {
            _context.Entry(country).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return country;
        }

        public async Task DeleteCountryAsync(int id)
        {
            var country = await _context.Countries.FindAsync(id);
            if (country != null)
            {
                _context.Countries.Remove(country);
                await _context.SaveChangesAsync();
            }
        }

        // State Methods
        public async Task<IEnumerable<State>> GetAllStatesAsync()
        {
            return await _context.States.ToListAsync();
        }

        public async Task<State> GetStateAsync(int id)
        {
            return await _context.States.FindAsync(id);
        }

        public bool StateAvailable(int stateId)
        {
            return _context.States.Any(p => p.StateId == stateId);
        }

        public async Task<State> CreateStateAsync(State state)
        {
            _context.States.Add(state);
            await _context.SaveChangesAsync();
            return state;
        }

        public async Task<State> UpdateStateAsync(State state)
        {
            _context.Entry(state).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return state;
        }

        public async Task DeleteStateAsync(int id)
        {
            var state = await _context.States.FindAsync(id);
            if (state != null)
            {
                _context.States.Remove(state);
                await _context.SaveChangesAsync();
            }
        }

        // City Methods
        public async Task<IEnumerable<City>> GetAllCitiesAsync()
        {
            return await _context.Cities.ToListAsync();
        }

        public async Task<City> GetCityAsync(int id)
        {
            return await _context.Cities.FindAsync(id);
        }

        public bool CityAvailable(int cityId)
        {
            return _context.Cities.Any(c => c.CityId == cityId);
        }

        public async Task<City> CreateCityAsync(City city)
        {
            _context.Cities.Add(city);
            await _context.SaveChangesAsync();
            return city;
        }

        public async Task<City> UpdateCityAsync(City city)
        {
            _context.Entry(city).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return city;
        }

        public async Task DeleteCityAsync(int id)
        {
            var city = await _context.Cities.FindAsync(id);
            if (city != null)
            {
                _context.Cities.Remove(city);
                await _context.SaveChangesAsync();
            }
        }
    }
}
