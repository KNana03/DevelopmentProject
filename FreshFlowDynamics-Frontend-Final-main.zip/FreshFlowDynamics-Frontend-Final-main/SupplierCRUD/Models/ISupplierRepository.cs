﻿namespace SupplierCRUD.Models
{
    public interface ISupplierRepository
    {
        Task<IEnumerable<Supplier>> GetAllSuppliersAsync();
        Task<Supplier> GetSuppliersByIdAsync(int id);
        Task<Supplier>CreateSupplierAsync(Supplier supplier);
        Task UpdateSupplierAsync(Supplier supplier);
        Task DeleteSupplierAsync(int id);
        Task BulkInsertSuppliersAsync(List<Supplier> suppliers);
        Task<Supplier> GetSupplierByEmailAsync(string email);
    }
}
