﻿namespace SupplierCRUD.Models
{
    public class CustomerReview
    {
        public int CustomerReviewId { get; set; }
        public string Review { get; set; }
        public int Rating { get; set; } // Rating out of 5
        public int ProductId { get; set; }
        public Product Product { get; set; }
        public DateTime DateCreated { get; set; } = DateTime.Now;
    }


}
