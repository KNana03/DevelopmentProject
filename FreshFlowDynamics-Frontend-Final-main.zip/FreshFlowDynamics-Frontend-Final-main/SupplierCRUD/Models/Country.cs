﻿namespace SupplierCRUD.Models
{
    public class Country
    {
        public int CountryId { get; set; }
        public string Name { get; set; }
        public virtual ICollection<State> States { get; set; }
        public virtual ICollection<City> Cities { get; set; }
        public virtual ICollection<Warehouse> Warehouses { get; set; }
    }
}
