﻿namespace SupplierCRUD.Models
{
    public class EmailRequest
    {
        public string Email { get; set; }
    }
}
