﻿using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Models
{
    public class ProductRepository : IProductRepository
    {

        private readonly AppDbContext _appDbContext;

        public ProductRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<List<Product>> GetAllProductsAsync()
        {
            List<Product> products = await _appDbContext.Products
                .Join(_appDbContext.Brands, p => p.BrandId, b => b.BrandId, (p, b) => new { Product = p, BrandName = b.Name })
                .Join(_appDbContext.Categories, pc => pc.Product.CategoryId, c => c.CategoryId, (pc, c) => new Product
                {
                    ProductId = pc.Product.ProductId,
                    Price = pc.Product.Price,
                    BrandId = pc.Product.BrandId,
                    CategoryId = pc.Product.CategoryId,
                    QuantityOnHand = pc.Product.QuantityOnHand,
                    Description = pc.Product.Description,
                    Image = pc.Product.Image,
                    Name = pc.Product.Name,
                    Category = new Category
                    {
                        CategoryId = c.CategoryId,
                        Name = c.Name,
                        Description = c.Description,
                        DateCreated = c.DateCreated,
                        DateModified = c.DateModified,
                        IsActive = c.IsActive,
                        IsDeleted = c.IsDeleted
                    },
                    Brand = new Brand
                    {
                        BrandId = pc.Product.BrandId,
                        Name = pc.BrandName,
                        Description = null,
                        CategoryId = pc.Product.CategoryId,
                        DateCreated = pc.Product.DateCreated,
                        DateModified = pc.Product.DateModified,
                        IsActive = pc.Product.IsActive,
                        IsDeleted = pc.Product.IsDeleted
                    }
                })
                .ToListAsync();

            return products;

        }

        public async Task<Product> GetProductByIdAsync(int id)
        {
            return await _appDbContext.Products.FindAsync(id);
        }

        public async Task<Product> AddProductAsync(Product product)
        {
            _appDbContext.Products.Add(product);
            await _appDbContext.SaveChangesAsync();
            return product;
        }

        public async Task<Product> UpdateProductAsync(Product product)
        {
            // Find the existing product in the context (if any)
            var existingProduct = await _appDbContext.Products.FindAsync(product.ProductId);

            if (existingProduct != null)
            {
                // Detach the existing entity to avoid tracking conflict
                _appDbContext.Entry(existingProduct).State = EntityState.Detached;
            }

            // Attach the updated entity and mark it as modified
            _appDbContext.Entry(product).State = EntityState.Modified;
            await _appDbContext.SaveChangesAsync();
            return product;
        }


        public void Add<T>(T entity) where T : class
        {
            _appDbContext.Add(entity);
        }

        public async Task DeleteProductAsync(int id)
        {
            var product = await _appDbContext.Products.FindAsync(id);
            if (product != null)
            {
                _appDbContext.Products.Remove(product);
                await _appDbContext.SaveChangesAsync();
            }
        }

        public async Task<List<Product>> GetLowStockProductsAsync(int threshold)
        {
            return await _appDbContext.Products
                .Where(p => p.QuantityOnHand < threshold)
                .ToListAsync();
        }

    }
}