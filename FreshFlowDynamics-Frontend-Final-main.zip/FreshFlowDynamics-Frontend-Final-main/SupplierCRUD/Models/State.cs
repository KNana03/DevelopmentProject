﻿namespace SupplierCRUD.Models
{
    public class State
    {
        public int StateId { set; get; }
        public string Name { get; set; }
        public int CountryId { get; set; }
        public virtual Country Country { get; set; }
        public virtual ICollection<City> Cities { get; set; }
        public virtual ICollection<Warehouse> Warehouses { get; set; }
    }
}
