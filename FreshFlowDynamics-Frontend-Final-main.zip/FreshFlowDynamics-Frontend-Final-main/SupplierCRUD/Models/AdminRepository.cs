﻿using iText.Commons.Actions.Contexts;
using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Models
{
    public class AdminRepository:IAdminRepository
    {
        private readonly AppDbContext _appDbContext;

        public AdminRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<IEnumerable<Admin>> GetAllAdminsAsync()
        {
            return await _appDbContext.Admins.ToListAsync();
        }
        public async Task<Admin> GetAdminByEmailAsync(string email)
        {
            return await _appDbContext.Admins.FirstOrDefaultAsync(a => a.Email == email);
        }
        public async Task<Admin> GetAdminByIdAsync(int id)
        {
            return await _appDbContext.Admins.FindAsync(id);
        }

        public async Task<Admin> CreateAdminAsync(Admin admin)
        {
            _appDbContext.Admins.Add(admin);
            await _appDbContext.SaveChangesAsync();
            return admin;
        }

        public async Task UpdateAdminAsync(Admin admin)
        {
            // Find the existing admin in the context (if any)
            var existingAdmin = await _appDbContext.Admins.FindAsync(admin.Id);

            if (existingAdmin != null)
            {
                // Detach the existing entity to avoid tracking conflict
                _appDbContext.Entry(existingAdmin).State = EntityState.Detached;
            }

            // Attach the updated entity and mark it as modified
            _appDbContext.Entry(admin).State = EntityState.Modified;
            await _appDbContext.SaveChangesAsync();
        }


        public async Task DeleteAdminAsync(int id)
        {
            var admin = await _appDbContext.Admins.FindAsync(id);
            if (admin != null)
            {
                _appDbContext.Admins.Remove(admin);
                await _appDbContext.SaveChangesAsync();
            }
        }
    }


}

