﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SupplierCRUD.Models
{
    public class OrderRepository : IOrderRepository
    {
        private readonly AppDbContext _appDbContext;

        public OrderRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<IEnumerable<Order>> GetAllOrdersAsync()
        {
            return await _appDbContext.Orders.ToListAsync();
        }

        public async Task<Order> GetOrderByIdAsync(int id)
        {
            return await _appDbContext.Orders
                .FirstOrDefaultAsync(o => o.Id == id);
        }

        public async Task<Order> CreateOrderAsync(Order order)
        {
            order.OrderDate = DateTime.UtcNow;
            _appDbContext.Orders.Add(order);
            await _appDbContext.SaveChangesAsync();
            return order;
        }

        public async Task UpdateOrderAsync(Order order)
        {
            _appDbContext.Entry(order).State = EntityState.Modified;
            await _appDbContext.SaveChangesAsync();
        }

        public async Task ReceiveOrderAsync(int id)
        {
            var order = await _appDbContext.Orders.FindAsync(id);
            if (order != null)
            {
                order.ReceivedDate = DateTime.UtcNow;
                await _appDbContext.SaveChangesAsync();
            }
        }

        public async Task PaySupplierAsync(int id)
        {
            var order = await _appDbContext.Orders.FindAsync(id);
            if (order != null)
            {
                order.IsPaid = true;
                await _appDbContext.SaveChangesAsync();
            }
        }

        public async Task DeleteOrderAsync(int id)
        {
            var order = await _appDbContext.Orders.FindAsync(id);
            if (order != null)
            {
                _appDbContext.Orders.Remove(order);
                await _appDbContext.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<PaymentType>> GetPaymentTypesAsync()
        {
            return await _appDbContext.PaymentTypes.ToListAsync();
        }
    }
}
