﻿namespace SupplierCRUD.Models
{
    public class VAT
    {
        public int VATId { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
    }
}