﻿using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Models
{
    public class VATRepository : IVATRepository
    {
        private readonly AppDbContext _context;
        public VATRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<VAT>> GetVAT()
        {
            return await _context.VAT.ToListAsync();
        }

        public async Task<VAT> UpdateVATAsync(VAT vat)
        {
            _context.Entry(vat).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return vat;
        }
    }
}