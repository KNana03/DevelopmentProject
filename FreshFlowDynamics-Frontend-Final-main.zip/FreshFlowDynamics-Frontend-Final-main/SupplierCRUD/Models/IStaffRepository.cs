﻿namespace SupplierCRUD.Models
{
    public interface IStaffRepository
    {
        // Staff

        Task<IEnumerable<Staff>> GetAllStaffsAsync();
        Task<Staff> GetStaffsByIdAsync(int id);
        Task<Staff> CreateStaffAsync(Staff Staffs);
        Task<Staff> GetStaffByCodeAsync(string code); // Add this method
        Task UpdateStaffAsync(Staff Staffs);
        Task DeleteStaffAsync(int id);

        Task<Staff> GetStaffByIdAsync(int id);

    }
}
