﻿using System.ComponentModel.DataAnnotations;

namespace SupplierCRUD.Models
{
  
        public class ShiftType
        {
            public int Id { get; set; }
            [Required]
            public string Name { get; set; }
            [Required]
            public string Description { get; set; }

        public int ShiftId { get; set; }
    }
    }


