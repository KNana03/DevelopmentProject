﻿namespace SupplierCRUD.Models
{
    public class Document
    {
        public int Id { get; set; }
        public int SupplierId { get; set; }
        public string FileName { get; set; }
        public string FileType { get; set; } // e.g., "Invoice", "Receipt"
        public string FilePath { get; set; } // Path where the file is stored

        public Supplier Supplier { get; set; }
    }
}
