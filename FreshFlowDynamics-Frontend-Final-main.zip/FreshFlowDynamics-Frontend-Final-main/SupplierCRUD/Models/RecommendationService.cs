﻿using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Models
{
    public class RecommendationService : IRecommendationService
    {
        private readonly AppDbContext _context;

        public RecommendationService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Product>> GetRecommendationsAsync()
        {
            // Example logic to fetch top ordered products
            var recommendations = await _context.Orders
                .GroupBy(o => o.Id)
                .OrderByDescending(g => g.Count())
                .Select(g => g.Key)
                .Take(5)
                .ToListAsync();

            return await _context.Products
                .Where(p => recommendations.Contains(p.ProductId))
                .ToListAsync();
        }
    }


}
