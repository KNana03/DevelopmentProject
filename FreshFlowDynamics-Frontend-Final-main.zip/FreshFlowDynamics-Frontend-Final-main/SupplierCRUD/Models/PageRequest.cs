﻿namespace SupplierCRUD.Models
{
    public class PageRequest
    {
        public int Id { get; set; }
        public string PageName { get; set; }
        public int RequestCount { get; set; }
        public string UserName { get; set; }  // Add this property
    }
}
