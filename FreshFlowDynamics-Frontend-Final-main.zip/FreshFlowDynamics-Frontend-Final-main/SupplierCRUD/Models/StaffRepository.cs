﻿using Microsoft.EntityFrameworkCore;
using SupplierCRUD.Models;
using SupplierCRUD.Repositories;

namespace SupplierCRUD.Repositories
{
    public class StaffRepository : IStaffRepository
    {
        private readonly AppDbContext _appDbContext;

        public StaffRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<IEnumerable<Staff>> GetAllStaffsAsync()
        {

            return await _appDbContext.Staffs.ToListAsync();
        }


        public async Task<Staff> GetStaffsByIdAsync(int id)
        {
            return await _appDbContext.Staffs.FindAsync(id);
        }

        public async Task<Staff> GetStaffByCodeAsync(string code)
        {
            return await _appDbContext.Staffs
                .FirstOrDefaultAsync(s => s.FiveDigitCode == code); // Assuming FiveDigitCode is the unique code
        }

        public async Task<Staff> CreateStaffAsync(Staff staff)
        {
            //staff.FiveDigitCode = GenerateFiveDigitCode();
            _appDbContext.Staffs.Add(staff);
            await _appDbContext.SaveChangesAsync();
            return staff;
        }
        /* private string GenerateFiveDigitCode()
         {
             var random = new Random();
             return random.Next(10000, 99999).ToString();
         }*/

        public async Task UpdateStaffAsync(Staff staff)
        {
            // Find the existing staff in the context (if any)
            var existingStaff = await _appDbContext.Staffs.FindAsync(staff.Id);

            if (existingStaff != null)
            {
                // Detach the existing entity to avoid tracking conflict
                _appDbContext.Entry(existingStaff).State = EntityState.Detached;
            }

            // Attach the updated entity and mark it as modified
            _appDbContext.Entry(staff).State = EntityState.Modified;
            await _appDbContext.SaveChangesAsync();
        }


        public async Task DeleteStaffAsync(int id)
        {
            var staff = await _appDbContext.Staffs.FindAsync(id);
            if (staff != null)
            {
                _appDbContext.Staffs.Remove(staff);
                await _appDbContext.SaveChangesAsync();
            }
        }
        public async Task<Staff> GetStaffByIdAsync(int id)
        {
            return await _appDbContext.Staffs.FindAsync(id);
        }



    }
}
