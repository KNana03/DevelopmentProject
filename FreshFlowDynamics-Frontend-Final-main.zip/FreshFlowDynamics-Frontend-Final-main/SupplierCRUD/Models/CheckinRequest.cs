﻿namespace SupplierCRUD.Models
{
    public class CheckinRequest
    {
        public string qrCodeData { get; set; } // Unique code for check-in
    }
}
