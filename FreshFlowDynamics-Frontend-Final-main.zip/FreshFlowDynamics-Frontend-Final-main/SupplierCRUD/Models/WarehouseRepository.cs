﻿using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Models
{
    public class WarehouseRepository : IWarehouseRepository
    {
        private readonly AppDbContext _context;

        public WarehouseRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Warehouse>> GetAllWarehousesAsync()
        {
            List<Warehouse> warehouses = await _context.Warehouses
                .Join(_context.Cities, w => w.CityId, c => c.CityId, (w, c) => new { Warehouse = w, City = c })
                .Join(_context.States, wc => wc.City.StateId, s => s.StateId, (wc, s) => new { wc.Warehouse, wc.City, State = s })
                .Join(_context.Countries, wcs => wcs.State.CountryId, co => co.CountryId, (wcs, co) => new Warehouse
                {
                    WarehouseId = wcs.Warehouse.WarehouseId,
                    Name = wcs.Warehouse.Name,
                    CountryId = wcs.Warehouse.CountryId,
                    StateId = wcs.Warehouse.StateId,
                    CityId = wcs.Warehouse.CityId,
                    Country = new Country
                    {
                        CountryId = co.CountryId,
                        Name = co.Name
                    },
                    State = new State
                    {
                        StateId = wcs.State.StateId,
                        Name = wcs.State.Name,
                        CountryId = wcs.State.CountryId
                    },
                    City = new City
                    {
                        CityId = wcs.City.CityId,
                        Name = wcs.City.Name,
                        StateId = wcs.City.StateId,
                        CountryId = wcs.City.CountryId
                    }
                })
                .ToListAsync();

            return warehouses;
        }


        public Warehouse GetWarehouse(int id)
        {
            return _context.Warehouses.Where(p => p.WarehouseId == id).FirstOrDefault();
        }

        public bool WarehouseAvailable(int warehouseId)
        {
            return _context.Warehouses.Any(p => p.WarehouseId == warehouseId);
        }

        public async Task<Warehouse> CreateWarehouseAsync(Warehouse warehouse)
        {
            _context.Warehouses.Add(warehouse);
            await _context.SaveChangesAsync();
            return warehouse;
        }

        public async Task<Warehouse> UpdateWarehouseAsync(Warehouse warehouse)
        {
            _context.Entry(warehouse).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return warehouse;
        }

        public async Task DeleteWarehouseAsync(int id)
        {
            var warehouse = await _context.Warehouses.FindAsync(id);
            if (warehouse != null)
            {
                _context.Warehouses.Remove(warehouse);
                await _context.SaveChangesAsync();
            }
        }
    }
}
