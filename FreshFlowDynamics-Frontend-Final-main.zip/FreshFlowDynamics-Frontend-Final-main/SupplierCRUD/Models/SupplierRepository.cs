﻿
using iText.Commons.Actions.Contexts;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace SupplierCRUD.Models
{
    public class SupplierRepository : ISupplierRepository
    {
        private readonly AppDbContext _appDbContext;
        public SupplierRepository(AppDbContext appDbContext) 
        {

            _appDbContext = appDbContext;
        }
        public async Task<Supplier> GetSupplierByEmailAsync(string email)
        {
            return await _appDbContext.Suppliers.FirstOrDefaultAsync(s => s.Email == email);
        }

        public async Task BulkInsertSuppliersAsync(List<Supplier> suppliers)
        {
            foreach (var supplier in suppliers)
            {
                var validationResults = new List<ValidationResult>();
                var context = new ValidationContext(supplier, null, null);
                if (!Validator.TryValidateObject(supplier, context, validationResults, true))
                {
                    foreach (var validationResult in validationResults)
                    {
                        Console.WriteLine($"Validation failed: {validationResult.ErrorMessage}");
                    }
                    return; // Stop the process if validation fails
                }
            }

            await _appDbContext.Suppliers.AddRangeAsync(suppliers);
            await _appDbContext.SaveChangesAsync();
        }

        public async Task<IEnumerable<Supplier>> GetAllSuppliersAsync()
        {
           return await _appDbContext.Suppliers.ToListAsync();
        }
        public async Task<Supplier>GetSuppliersByIdAsync(int id)
        {
            return await _appDbContext.Suppliers.FindAsync(id);
        }
        public async Task <Supplier> CreateSupplierAsync(Supplier supplier)
        {
            _appDbContext.Suppliers.Add(supplier);
            await _appDbContext.SaveChangesAsync();
            return supplier;
        }

        public async Task UpdateSupplierAsync(Supplier supplier)
        {
            // Find the existing supplier in the context (if any)
            var existingSupplier = await _appDbContext.Suppliers.FindAsync(supplier.Id);

            if (existingSupplier != null)
            {
                // Detach the existing entity to avoid tracking conflict
                _appDbContext.Entry(existingSupplier).State = EntityState.Detached;
            }

            // Attach the updated entity and mark it as modified
            _appDbContext.Entry(supplier).State = EntityState.Modified;
            await _appDbContext.SaveChangesAsync();
        }


        public async Task DeleteSupplierAsync(int id)
        {
            var supplier = await _appDbContext.Suppliers.FindAsync(id);
            if(supplier != null)
            {
                _appDbContext.Suppliers.Remove(supplier);
                await _appDbContext.SaveChangesAsync();
            }
        }
    }
}
