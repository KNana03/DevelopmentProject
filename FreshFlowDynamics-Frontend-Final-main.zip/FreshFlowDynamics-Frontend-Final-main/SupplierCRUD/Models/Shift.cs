﻿namespace SupplierCRUD.Models
{
    public class Shift
    {
        public int Id { get; set; }
        public string Name { get; set; }
       /* public int ShiftTypeId { get; set; }
        public ShiftType? ShiftType { get; set; }*/
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public DateTime? CheckInTime { get; set; }
        public DateTime? CheckOutTime { get; set; }
        public DateTime Date { get; set; }

        public int ShiftTypeId { get; set; }
        public ShiftType ShiftType { get; set; }
    }
}
