﻿using SupplierCRUD.Models;

public class CurrencyExchangeRate
{
    public int CurrencyExchangeRateId { get; set; }
    public string CurrencyCode { get; set; }
    public decimal ExchangeRate { get; set; }
    public DateTime Date { get; set; }

    // Allow null values for OrderId if not every exchange rate is associated with an order
    public int? OrderId { get; set; }
    public virtual Order Order { get; set; }
}
