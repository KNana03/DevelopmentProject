﻿namespace SupplierCRUD.Models
{
    public interface IProductRepository
    {
        Task<List<Product>> GetAllProductsAsync();
        Task<Product> GetProductByIdAsync(int id);
        Task<Product> AddProductAsync(Product product);
        Task<Product> UpdateProductAsync(Product product);
        Task DeleteProductAsync(int id);
        void Add<T>(T entity) where T : class;
        Task<List<Product>> GetLowStockProductsAsync(int threshold);
    }
}
