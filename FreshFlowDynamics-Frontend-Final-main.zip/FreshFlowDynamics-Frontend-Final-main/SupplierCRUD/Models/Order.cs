﻿namespace SupplierCRUD.Models
{
    public class Order
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public bool IsPaid { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime? ReceivedDate { get; set; }

        // New property to store the price in Rands
       
        // Navigation property for the related exchange rate
  
    }
}
