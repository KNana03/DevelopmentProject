﻿namespace SupplierCRUD.Models
{ 
    public class CheckOutRequest
    {
        public string qrCodeData { get; set; } // Unique code for check-out
    }
}
