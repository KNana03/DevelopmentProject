﻿using SupplierCRUD.Models;
using System.ComponentModel.DataAnnotations;

public class InventoryType
{
    public int Id { get; set; }

    [Required]
    [StringLength(50)]
    public string TypeName { get; set; }

    [StringLength(500)]
    public string Description { get; set; }

    public bool IsDeleted { get; set; } // Add this property

    public ICollection<Inventory> Inventories { get; set; }
}
