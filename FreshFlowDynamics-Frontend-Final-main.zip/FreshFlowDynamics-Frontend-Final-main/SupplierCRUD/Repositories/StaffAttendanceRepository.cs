﻿using SupplierCRUD.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SupplierCRUD.Models.SupplierCRUD.Models;

namespace SupplierCRUD.Repositories
{
    public class StaffAttendanceRepository : IStaffAttendanceRepository
    {
        private readonly AppDbContext _context;

        public StaffAttendanceRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task AddAttendanceAsync(StaffAttendance attendance)
        {
            await _context.StaffAttendances.AddAsync(attendance);
            await _context.SaveChangesAsync();
        }

        public async Task<StaffAttendance> GetAttendanceByStaffIdAndShiftAssignmentIdAsync(int staffId, int shiftAssignmentId)
        {
            return await _context.StaffAttendances
                .FirstOrDefaultAsync(a => a.StaffId == staffId && a.ShiftAssignmentId == shiftAssignmentId && a.IsCheckedIn && !a.IsCheckedOut);
        }

        public async Task UpdateAttendanceAsync(StaffAttendance attendance)
        {
            _context.StaffAttendances.Update(attendance);
            await _context.SaveChangesAsync();
        }
    }
}
