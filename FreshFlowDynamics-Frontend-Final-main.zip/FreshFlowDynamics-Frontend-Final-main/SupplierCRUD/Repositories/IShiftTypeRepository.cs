﻿using SupplierCRUD.Models;

namespace SupplierCRUD.Repositories
{
    public interface IShiftTypeRepository
    {
        Task<ShiftType> GetShiftTypeByIdAsync(int id);
        Task<List<ShiftType>> GetAllShiftTypesAsync();
        Task AddShiftTypeAsync(ShiftType shiftType);
        Task UpdateShiftTypeAsync(ShiftType shiftType);
        Task DeleteShiftTypeAsync(int id);
        Task SaveChangesAsync();
    }
}
