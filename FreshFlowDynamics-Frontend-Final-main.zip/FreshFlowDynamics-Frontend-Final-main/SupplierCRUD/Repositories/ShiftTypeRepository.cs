﻿using SupplierCRUD.Models;
using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Repositories
{
    public class ShiftTypeRepository : IShiftTypeRepository
    {
        private readonly AppDbContext _context;

        public ShiftTypeRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<ShiftType> GetShiftTypeByIdAsync(int id)
        {
            return await _context.ShiftTypes.FindAsync(id);
        }

        public async Task<List<ShiftType>> GetAllShiftTypesAsync()
        {
            return await _context.ShiftTypes.ToListAsync();
        }

        public async Task AddShiftTypeAsync(ShiftType shiftType)
        {
            await _context.ShiftTypes.AddAsync(shiftType);
        }

        public async Task UpdateShiftTypeAsync(ShiftType shiftType)
        {
            _context.ShiftTypes.Update(shiftType);
        }

        public async Task DeleteShiftTypeAsync(int id)
        {
            var shiftType = await _context.ShiftTypes.FindAsync(id);
            if (shiftType != null)
            {
                _context.ShiftTypes.Remove(shiftType);
            }
        }

        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }
    }

}
