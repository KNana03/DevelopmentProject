﻿using System.Collections.Generic;
using System.Threading.Tasks;
using SupplierCRUD.Repositories;

namespace SupplierCRUD.Models
{
    public interface IStockTakeRepository
    {
        Task<StockTake> CreateStockTakeAsync(StockTake stockTake);
        Task<IEnumerable<StockTake>> GetStockTakesByOrderIdAsync(int orderId);
        Task<StockTake> GetStockTakeByIdAsync(int id); // New method to fetch stock take by its ID
        Task UpdateStockTakeAsync(StockTake stockTake);
        Task DeleteStockTakeAsync(int id); // Optional: if you want to allow deletion of stock takes
    }
}
