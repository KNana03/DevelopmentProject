﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Models
{
    public class StockTakeRepository : IStockTakeRepository
    {
        private readonly AppDbContext _context;

        public StockTakeRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<StockTake> CreateStockTakeAsync(StockTake stockTake)
        {
            _context.StockTakes.Add(stockTake);
            await _context.SaveChangesAsync();
            return stockTake;
        }

        public async Task<IEnumerable<StockTake>> GetStockTakesByOrderIdAsync(int orderId)
        {
            return await _context.StockTakes.Where(st => st.OrderId == orderId).ToListAsync();
        }

        public async Task<StockTake> GetStockTakeByIdAsync(int id)
        {
            return await _context.StockTakes.FindAsync(id);
        }

        public async Task UpdateStockTakeAsync(StockTake stockTake)
        {
            _context.Entry(stockTake).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteStockTakeAsync(int id)
        {
            var stockTake = await _context.StockTakes.FindAsync(id);
            if (stockTake != null)
            {
                _context.StockTakes.Remove(stockTake);
                await _context.SaveChangesAsync();
            }
        }
    }
}
