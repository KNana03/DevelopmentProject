﻿using SupplierCRUD.Models;

namespace SupplierCRUD.Repositories
{
    public interface IShiftRepository
    {

        Task<Shift> GetShiftByIdAsync(int id);
        Task<List<Shift>> GetAllShiftsAsync();
        Task<Shift> AddShiftAsync(Shift shift);
        Task<Shift> GetActiveShiftByStaffIdAsync(int staffId);
        Task UpdateShiftAsync(Shift shift);
        Task DeleteShiftAsync(int id);
        Task SaveChangesAsync();
    }
}
