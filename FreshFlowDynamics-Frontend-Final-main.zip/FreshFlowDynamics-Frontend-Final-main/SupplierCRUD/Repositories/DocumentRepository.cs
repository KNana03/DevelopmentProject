﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Models
{
    public class DocumentRepository : IDocumentRepository
    {
        private readonly AppDbContext _appDbContext;

        public DocumentRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<IEnumerable<Document>> GetDocumentsBySupplierIdAsync(int supplierId)
        {
            return await _appDbContext.Documents
                .Where(d => d.SupplierId == supplierId)
                .ToListAsync();
        }

        public async Task<IEnumerable<Document>> GetDocumentsBySupplierIdAndFileTypeAsync(int supplierId, string fileType)
        {
            return await _appDbContext.Documents
                .Where(d => d.SupplierId == supplierId && d.FileType.ToLower() == fileType.ToLower())
                .ToListAsync();
        }

        public async Task<Document> GetDocumentByIdAsync(int documentId)
        {
            return await _appDbContext.Documents.FindAsync(documentId);
        }

        public async Task<Document> UploadDocumentAsync(Document document)
        {
            _appDbContext.Documents.Add(document);
            await _appDbContext.SaveChangesAsync();
            return document;
        }

        public async Task DeleteDocumentAsync(int documentId)
        {
            var document = await _appDbContext.Documents.FindAsync(documentId);
            if (document != null)
            {
                _appDbContext.Documents.Remove(document);
                await _appDbContext.SaveChangesAsync();
            }
        }
    }
}
