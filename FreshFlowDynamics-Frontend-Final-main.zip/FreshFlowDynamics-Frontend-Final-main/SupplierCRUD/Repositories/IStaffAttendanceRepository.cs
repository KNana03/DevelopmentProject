﻿using Microsoft.AspNetCore.Mvc;
using SupplierCRUD.Models;
using SupplierCRUD.Models.SupplierCRUD.Models;
namespace SupplierCRUD.Repositories
{
    public interface IStaffAttendanceRepository
    {
        Task AddAttendanceAsync(StaffAttendance attendance);
        Task<StaffAttendance> GetAttendanceByStaffIdAndShiftAssignmentIdAsync(int staffId, int shiftAssignmentId);
        Task UpdateAttendanceAsync(StaffAttendance attendance);
    }

}
