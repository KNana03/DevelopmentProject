﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace SupplierCRUD.Models
{
    public interface IDocumentRepository
    {
        Task<IEnumerable<Document>> GetDocumentsBySupplierIdAsync(int supplierId);
        Task<IEnumerable<Document>> GetDocumentsBySupplierIdAndFileTypeAsync(int supplierId, string fileType);
        Task<Document> GetDocumentByIdAsync(int documentId);
        Task<Document> UploadDocumentAsync(Document document);
        Task DeleteDocumentAsync(int documentId);
    }
}
