﻿using SupplierCRUD.Models;
using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Repositories
{
    public class ShiftAssignment_repository : IShiftAssignmentRepository
    {
        private readonly AppDbContext _context;

        public ShiftAssignment_repository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<ShiftAssignment>> GetAllAssignmentsAsync()
        {
            return await _context.ShiftAssignments
                                 .Include(sa => sa.Staff)
                                 .Include(sa => sa.Shift)
                                 .ToListAsync();
        }
        public async Task<ShiftAssignment> GetShiftAssignmentByIdAsync(int id)
        {
            return await _context.ShiftAssignments.FindAsync(id);
        }

        public async Task<IEnumerable<ShiftAssignment>> GetAssignmentsByStaffIdAsync(int staffId)
        {
            return await _context.ShiftAssignments
                          .Include(sa => sa.Staff)
                          .Include(sa => sa.Shift)
                          .Where(sa => sa.StaffId == staffId)
                          .ToListAsync();
        }

        public async Task CreateShiftAssignmentAsync(ShiftAssignment shiftAssignment)
        {
            _context.ShiftAssignments.Add(shiftAssignment);
            await _context.SaveChangesAsync();
        }

        public async Task RemoveShiftAssignmentAsync(int assignmentId)
        {
            var assignment = await GetShiftAssignmentByIdAsync(assignmentId);
            if (assignment != null)
            {
                _context.ShiftAssignments.Remove(assignment);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<ShiftAssignment> GetLatestShiftAssignmentByStaffIdAsync(int staffId)
        {
            return await _context.ShiftAssignments
                .Where(sa => sa.StaffId == staffId)
                .OrderByDescending(sa => sa.Id)
                .FirstOrDefaultAsync();
        }
    }
}