﻿using SupplierCRUD.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SupplierCRUD.Repositories
{
    public interface IShiftAssignmentRepository
    {
        Task<IEnumerable<ShiftAssignment>> GetAllAssignmentsAsync();
        Task<ShiftAssignment> GetShiftAssignmentByIdAsync(int id);
        Task<IEnumerable<ShiftAssignment>> GetAssignmentsByStaffIdAsync(int staffId);
        Task CreateShiftAssignmentAsync(ShiftAssignment shiftAssignment);
        Task<ShiftAssignment> GetLatestShiftAssignmentByStaffIdAsync(int staffId); // New method
        Task RemoveShiftAssignmentAsync(int assignmentId); // Add this line
    }
}
