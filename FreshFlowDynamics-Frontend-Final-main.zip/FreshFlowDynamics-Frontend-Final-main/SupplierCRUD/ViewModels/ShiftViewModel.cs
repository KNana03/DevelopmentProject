﻿namespace SupplierCRUD.ViewModels
{
    public class ShiftViewModel
    {
        public string Name { get; set; }
       
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int ShiftTypeId { get; set; }
        public string TypeName { get; set; } // Optional, if you need to pass the type name
        public DateTime? CheckInTime { get; set; }
        public DateTime? CheckOutTime { get; set; }
        public DateTime Date { get; set; }
    }
}
