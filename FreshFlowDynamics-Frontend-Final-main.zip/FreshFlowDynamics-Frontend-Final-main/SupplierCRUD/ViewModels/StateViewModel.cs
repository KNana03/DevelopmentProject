﻿namespace SupplierCRUD.ViewModels
{
    public class StateViewModel
    {
        public string name { get; set; }
        public int countryId { get; set; }
    }
}
