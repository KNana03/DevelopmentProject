﻿namespace SupplierCRUD.ViewModels
{
    public class CustomerReviewViewModel
    {
        public string Review { get; set; }
        public int Rating { get; set; } // Rating out of 5
    }

}
