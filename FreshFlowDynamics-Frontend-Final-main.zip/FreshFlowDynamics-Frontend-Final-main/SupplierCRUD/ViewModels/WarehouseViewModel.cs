﻿namespace SupplierCRUD.ViewModels
{
    public class WarehouseViewModel
    {
        public string name { get; set; }
        public int countryId { get; set; }
        public int stateId { get; set; }
        public int cityId { get; set; }
    }
}
