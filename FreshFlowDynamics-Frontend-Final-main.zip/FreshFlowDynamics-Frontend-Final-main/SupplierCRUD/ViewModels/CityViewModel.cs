﻿namespace SupplierCRUD.ViewModels
{
    public class CityViewModel
    {
        public string name { get; set; }
        public int countryId { get; set; }
        public int stateId { get; set; }
    }
}
