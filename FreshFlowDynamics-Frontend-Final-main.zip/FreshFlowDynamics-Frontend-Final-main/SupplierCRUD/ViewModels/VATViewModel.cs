﻿namespace SupplierCRUD.ViewModels
{
    public class VATViewModel
    {
        public decimal amount { get; set; }
    }
}