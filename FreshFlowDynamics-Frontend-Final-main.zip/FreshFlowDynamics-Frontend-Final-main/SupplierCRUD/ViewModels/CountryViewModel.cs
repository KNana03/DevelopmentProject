﻿namespace SupplierCRUD.ViewModels
{
    public class CountryViewModel
    {
        public string name { get; set; }
    }
}
