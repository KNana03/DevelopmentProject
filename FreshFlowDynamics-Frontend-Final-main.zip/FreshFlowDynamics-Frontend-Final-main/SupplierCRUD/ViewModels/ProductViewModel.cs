﻿namespace SupplierCRUD.ViewModels
{
    public class ProductViewModel
    {
        public decimal price { get; set; }
        public int category { get; set; }
        public int brand { get; set; }
        public int quantityOnHand { get; set; }
        public string description { get; set; }
        public string name { get; set; }
        public string? image { get; set; }
    }
}
