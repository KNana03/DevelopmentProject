﻿namespace SupplierCRUD.DTOs
{
    public class CheckInOutRequest
    {
        public int StaffId { get; set; }
        public string FiveDigitCode { get; set; }
    }
}
