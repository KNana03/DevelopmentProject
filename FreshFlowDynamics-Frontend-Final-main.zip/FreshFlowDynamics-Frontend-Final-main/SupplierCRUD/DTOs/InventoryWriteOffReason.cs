﻿namespace SupplierCRUD.DTOs
{
    public class InventoryWriteOffReasonDTO
    {
        public int InventoryId { get; set; }
        public string Reason { get; set; }
        public int Quantity { get; set; }  // New field for quantity
    }

}
