﻿using Microsoft.AspNetCore.Mvc;
using SupplierCRUD.Models;
using SupplierCRUD.Services;
using SupplierCRUD.ViewModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository _productRepository;
        private readonly IProductInventoryService _productInventoryService;
        private readonly ICustomerReviewService _customerReviewService;
        private readonly ILogger<ProductController> _logger;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IExcelExportService _excelExportService;

        public ProductController(IProductRepository productRepository,
            IProductInventoryService productInventoryService,
            ICustomerReviewService customerReviewService,
            ILogger<ProductController> logger,
            IAuditTrailService auditTrailService,
             IExcelExportService excelExportService,

            IHttpContextAccessor httpContextAccessor)
        {
            _productRepository = productRepository;
            _productInventoryService = productInventoryService;
            _customerReviewService = customerReviewService;
            _logger = logger;
            _auditTrailService = auditTrailService;
            _httpContextAccessor = httpContextAccessor;
            _excelExportService = excelExportService;

        }

        [HttpGet]
        [Route("GetAllProducts")]
        public async Task<ActionResult<IEnumerable<Product>>> GetProducts()
        {
            var products = await _productRepository.GetAllProductsAsync();
            return Ok(products);
        }

        [HttpGet]
        [Route("GetProductById/{ProductId}")]
        public async Task<ActionResult<Product>> GetProductById(int id)
        {
            var product = await _productRepository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }

        [HttpPost]
        [Route("addProducts")]
        public async Task<IActionResult> AddProduct(ProductViewModel productViewModel)
        {
            var addedProduct = await _productInventoryService.AddProductAsync(productViewModel);

            // Log the product addition in the audit trail
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "AddProduct",
                EntityId = addedProduct.ProductId,
                UserId = User.Identity?.Name ?? "Anonymous",
                Timestamp = DateTime.UtcNow,
                Description = $"Product '{addedProduct.Name}' added",
                NewValue = $"Name: {addedProduct.Name}, Price: {addedProduct.Price}, Quantity: {addedProduct.QuantityOnHand}",
            });

            return Ok(addedProduct);
        }

        [HttpPut]
        [Route("UpdateProduct")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] ProductViewModel productViewModel)
        {
            var existingProduct = await _productRepository.GetProductByIdAsync(id);
            if (existingProduct == null)
            {
                return NotFound(new { Message = "Product not found" });
            }

            try
            {
                var product = new Product
                {
                    ProductId = id,  // Ensure the ProductId is set
                    Name = productViewModel.name,
                    Description = productViewModel.description,
                    Price = productViewModel.price,
                    QuantityOnHand = productViewModel.quantityOnHand,
                    Image = productViewModel.image,
                    BrandId = productViewModel.brand,
                    CategoryId = productViewModel.category
                };

                var updatedProduct = await _productRepository.UpdateProductAsync(product);

                // Log the product update in the audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "UpdateProduct",
                    EntityId = updatedProduct.ProductId,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    Description = $"Product '{updatedProduct.Name}' updated",
                    OldValue = $"Name: {existingProduct.Name}, Price: {existingProduct.Price}, Quantity: {existingProduct.QuantityOnHand}",
                    NewValue = $"Name: {updatedProduct.Name}, Price: {updatedProduct.Price}, Quantity: {updatedProduct.QuantityOnHand}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString()
                });

                return Ok(updatedProduct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the product with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete]
        [Route("DeleteProduct/{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _productRepository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound(new { Message = "Product not found" });
            }

            try
            {
                await _productRepository.DeleteProductAsync(id);

                // Log the product deletion in the audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "DeleteProduct",
                    EntityId = id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    Description = $"Product '{product.Name}' deleted",
                    OldValue = $"Name: {product.Name}, Price: {product.Price}, Quantity: {product.QuantityOnHand}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString()
                });

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the product with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        [Route("GetLowStockProducts")]
        public async Task<ActionResult<IEnumerable<Product>>> GetLowStockProducts([FromQuery] int threshold = 50)
        {
            var products = await _productRepository.GetLowStockProductsAsync(threshold);
            return Ok(products);
        }
       

        [HttpGet]
        [Route("GetReviewsByProductId/{ProductId}")]
        public async Task<ActionResult<IEnumerable<CustomerReview>>> GetReviewsByProductId(int productId)
        {
            var reviews = await _customerReviewService.GetReviewsByProductIdAsync(productId);
            return Ok(reviews);
        }

        // NEW: Method to add a review for a product
        [HttpPost]
        [Route("AddReviewToProduct/{ProductId}")]
        public async Task<IActionResult> AddReviewToProduct(int ProductId, [FromBody] CustomerReviewViewModel reviewViewModel)
        {
            _logger.LogInformation($"Received ProductId: {ProductId}"); // Move logger before returning the response

            var review = new CustomerReview
            {
                ProductId = ProductId,
                Review = reviewViewModel.Review,
                Rating = reviewViewModel.Rating,
                DateCreated = DateTime.Now
            };

            var addedReview = await _customerReviewService.AddReviewAsync(review);
            return Ok(addedReview);
        }

        // NEW: Method to delete a review
        [HttpDelete]
        [Route("DeleteReview/{ReviewId}")]
        public async Task<IActionResult> DeleteReview(int reviewId)
        {
            try
            {
                await _customerReviewService.DeleteReviewAsync(reviewId);
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the review with id {reviewId}.");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
