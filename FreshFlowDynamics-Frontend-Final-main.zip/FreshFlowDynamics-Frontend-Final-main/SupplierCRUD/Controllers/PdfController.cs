﻿using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Parser;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SupplierCRUD.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class PdfController : ControllerBase
    {
        [HttpPost("extract-info")]
        public async Task<IActionResult> ExtractInfo(IFormFile pdfFile)
        {
            if (pdfFile == null || pdfFile.Length == 0)
            {
                return BadRequest("Please upload a valid PDF file.");
            }

            try
            {
                var extractedInfo = await ExtractInfoFromPdfAsync(pdfFile);
                return Ok(extractedInfo);
            }
            catch
            {
                return StatusCode(500, "Failed to extract information from PDF.");
            }
        }

        private async Task<object> ExtractInfoFromPdfAsync(IFormFile pdfFile)
        {
            using var ms = new MemoryStream();
            await pdfFile.CopyToAsync(ms);

            ms.Position = 0;
            using var pdfReader = new PdfReader(ms);
            using var pdfDoc = new PdfDocument(pdfReader);

            var textBuilder = new System.Text.StringBuilder();
            for (int i = 1; i <= pdfDoc.GetNumberOfPages(); i++)
            {
                var page = pdfDoc.GetPage(i);
                var text = PdfTextExtractor.GetTextFromPage(page);
                textBuilder.Append(text);
            }

            string fullText = textBuilder.ToString();

            // Adjust regex patterns based on actual text
            var invoiceNumber = ExtractValue(fullText, @"Invoice Number:\s*(\S+)");
            var supplierName = ExtractValue(fullText, @"Supplier:\s*(.+)");
            var totalAmount = ExtractValue(fullText, @"Total Amount:\s*\$?(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)");

            return new
            {
                InvoiceNumber = invoiceNumber ?? "Not found",
                Supplier = supplierName ?? "Not found",
                TotalAmount = totalAmount ?? "Not found"
            };
        }

        private string ExtractValue(string text, string pattern)
        {
            var match = Regex.Match(text, pattern);
            return match.Success ? match.Groups[1].Value : null;
        }


    }
}
