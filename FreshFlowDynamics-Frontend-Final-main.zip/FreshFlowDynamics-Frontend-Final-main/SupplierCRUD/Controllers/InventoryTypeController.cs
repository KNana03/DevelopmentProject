﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SupplierCRUD.Models;
using SupplierCRUD.Services;

namespace SupplierCRUD.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InventoryTypeController : ControllerBase
    {
        private readonly IInventoryTypeService _inventoryTypeService;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public InventoryTypeController(IInventoryTypeService inventoryTypeService, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor)
        {
            _inventoryTypeService = inventoryTypeService;
            _auditTrailService = auditTrailService;
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpPost]
        [Route("addInventoryType")]
        public async Task<ActionResult<InventoryType>> CreateInventoryType([FromBody] InventoryType inventoryType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createdInventoryType = await _inventoryTypeService.CreateInventoryTypeAsync(inventoryType);

            // Create audit trail
            var auditTrail = new AuditTrail
            {
                Event = "CreateInventoryType",
                EntityId = createdInventoryType.Id,
                UserId = httpContextAccessor.HttpContext?.User?.Identity?.Name,
                Description = $"Created new inventory type: {createdInventoryType.TypeName}.",
                NewValue = JsonConvert.SerializeObject(createdInventoryType),
                //IPAddress = httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
            };
            await _auditTrailService.LogEventAsync(auditTrail);
            return CreatedAtAction(nameof(GetInventoryType), new { id = createdInventoryType.Id }, createdInventoryType);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<InventoryType>> GetInventoryType(int id)
        {
            var inventoryType = await _inventoryTypeService.GetInventoryTypeAsync(id);

            if (inventoryType == null)
            {
                return NotFound(new { Message = "InventoryType not found" });
            }

            return inventoryType;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<InventoryType>>> GetInventoryTypes()
        {
            var inventoryTypes = await _inventoryTypeService.GetInventoryTypesAsync();

            // Create audit trail for viewing all inventory types
            var auditTrail = new AuditTrail
            {
                Event = "ViewInventoryTypes",
                UserId = httpContextAccessor.HttpContext?.User?.Identity?.Name,
                Description = "Viewed all inventory types.",
                IPAddress = httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
            };
            await _auditTrailService.LogEventAsync(auditTrail);

            return Ok(inventoryTypes);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateInventoryType(int id, [FromBody] InventoryType inventoryType)
        {
            if (id != inventoryType.Id)
            {
                return BadRequest();
            }

            try
            {

                var oldInventoryType = await _inventoryTypeService.GetInventoryTypeAsync(id);
                await _inventoryTypeService.UpdateInventoryTypeAsync(id, inventoryType);

                // Create audit trail for updating inventory type
                var auditTrail = new AuditTrail
                {
                    Event = "UpdateInventoryType",
                    EntityId = inventoryType.Id,
                    UserId = httpContextAccessor.HttpContext?.User?.Identity?.Name,
                    Description = $"Updated inventory type: {inventoryType.TypeName}.",
                    OldValue = JsonConvert.SerializeObject(oldInventoryType),
                    NewValue = JsonConvert.SerializeObject(inventoryType),
                    //IPAddress = httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
                };
                await _auditTrailService.LogEventAsync(auditTrail);
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteInventoryType(int id)
        {

            var inventoryType = await _inventoryTypeService.GetInventoryTypeAsync(id);
            var result = await _inventoryTypeService.DeleteInventoryTypeAsync(id);
            if (!result)
            {
                return NotFound(new { Message = "InventoryType not found" });
            }

            // Create audit trail for deleting inventory type
            var auditTrail = new AuditTrail
            {
                Event = "DeleteInventoryType",
                EntityId = id,
                UserId = httpContextAccessor.HttpContext?.User?.Identity?.Name,
                Description = $"Deleted inventory type: {inventoryType.TypeName}.",
                OldValue = JsonConvert.SerializeObject(inventoryType),
                //IPAddress = httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
            };
            await _auditTrailService.LogEventAsync(auditTrail);


            return NoContent();
        }
    }
}
