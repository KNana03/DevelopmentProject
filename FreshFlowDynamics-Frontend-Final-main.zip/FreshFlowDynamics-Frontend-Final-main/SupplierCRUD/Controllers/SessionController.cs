﻿using Microsoft.AspNetCore.Mvc;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SessionController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _env;

        public SessionController(IConfiguration configuration, IWebHostEnvironment env)
        {
            _configuration = configuration;
            _env = env;
        }

        [HttpPost("set-timeout")]
        public IActionResult SetSessionTimeout([FromBody] int timeout)
        {
            if (timeout <= 0)
            {
                return BadRequest(new { message = "Invalid timeout value" });
            }

            // Update the configuration (in a real application, this would likely update a database or a file)
            var filePath = Path.Combine(_env.ContentRootPath, "appsettings.json");
            var json = System.IO.File.ReadAllText(filePath);
            dynamic jsonObj = Newtonsoft.Json.JsonConvert.DeserializeObject(json);
            jsonObj["SessionTimeout"] = timeout;
            string output = Newtonsoft.Json.JsonConvert.SerializeObject(jsonObj, Newtonsoft.Json.Formatting.Indented);
            System.IO.File.WriteAllText(filePath, output);

            return Ok(new { message = "Session timeout updated successfully" });
        }
    }
}
