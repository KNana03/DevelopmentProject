﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SupplierCRUD.Models;
using SupplierCRUD.ViewModels;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WarehouseController : ControllerBase
    {
        private readonly IWarehouseRepository _warehouseRepository;
        private readonly ILogger<WarehouseController> _logger;

        public WarehouseController(IWarehouseRepository warehouseRepository, ILogger<WarehouseController> logger)
        {
            _warehouseRepository = warehouseRepository;
            _logger = logger;
        }

        [HttpGet]
        [Route("GetWarehouses")]
        public async Task<ActionResult<IEnumerable<Warehouse>>> GetWarehouses()
        {
            try
            {
                var results = await _warehouseRepository.GetAllWarehousesAsync();
                return Ok(results);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching warehouses.");
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetWarehouseById/{warehouseId}")]
        [ProducesResponseType(200, Type = typeof(Warehouse))]
        [ProducesResponseType(404)]
        public IActionResult GetWarehouse(int warehouseId)
        {
            if (!_warehouseRepository.WarehouseAvailable(warehouseId))
                return NotFound();

            var warehouse = _warehouseRepository.GetWarehouse(warehouseId);

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            return Ok(warehouse);
        }

        [HttpPost]
        [Route("AddWarehouse")]
        public async Task<IActionResult> AddWarehouse(WarehouseViewModel warehouseViewModel)
        {
            try
            {
                var warehouse = new Warehouse
                {
                    Name = warehouseViewModel.name,
                    CountryId = warehouseViewModel.countryId,
                    StateId = warehouseViewModel.stateId,
                    CityId = warehouseViewModel.cityId,
                };

                var addedWarehouse = await _warehouseRepository.CreateWarehouseAsync(warehouse);
                return Ok(addedWarehouse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding the warehouse.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut]
        [Route("UpdateWarehouse/{id}")]
        public async Task<IActionResult> UpdateWarehouseAsync(int id, [FromBody] WarehouseViewModel warehouseViewModel)
        {
            try
            {
                var warehouse = _warehouseRepository.GetWarehouse(id);
                if (warehouse == null)
                {
                    return NotFound();
                }

                warehouse.Name = warehouseViewModel.name;
                warehouse.CountryId = warehouseViewModel.countryId;
                warehouse.StateId = warehouseViewModel.stateId;
                warehouse.CityId = warehouseViewModel.cityId;

                var updatedWarehouse = await _warehouseRepository.UpdateWarehouseAsync(warehouse);

                return Ok(updatedWarehouse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the warehouse with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete]
        [Route("DeleteWarehouse/{id}")]
        public async Task<IActionResult> DeleteWarehouseAsync(int id)
        {
            try
            {
                if (!_warehouseRepository.WarehouseAvailable(id))
                {
                    return NotFound();
                }

                await _warehouseRepository.DeleteWarehouseAsync(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the warehouse with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
