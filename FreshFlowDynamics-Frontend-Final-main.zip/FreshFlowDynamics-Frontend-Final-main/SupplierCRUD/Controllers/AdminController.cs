﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SupplierCRUD.Models;
using SupplierCRUD.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SupplierCRUD.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IAdminRepository _adminRepository;
        private readonly ILogger<AdminController> _logger;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly UserManager<IdentityUser> _userManager;

        public AdminController(IAdminRepository adminRepository, ILogger<AdminController> logger, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor, UserManager<IdentityUser> userManager)
        {
            _adminRepository = adminRepository;
            _logger = logger;
            _auditTrailService = auditTrailService;
            _httpContextAccessor = httpContextAccessor;
            _userManager = userManager;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Admin>>> GetAdmins()
        {
            var admins = await _adminRepository.GetAllAdminsAsync();

            // Get the logged-in user's username from local storage or session
            var userName = _httpContextAccessor.HttpContext?.User.Identity?.Name ?? "Unknown";

            // Log the audit trail
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "GetAdmins",
                EntityId = 0, // No specific entity involved
                UserId = userName, // Store the username directly
                Timestamp = DateTime.UtcNow,
                Description = $"{userName} fetched all admins",
                IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString()
            });

            return Ok(admins);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Admin>> GetAdmin(int id)
        {
            var admin = await _adminRepository.GetAdminByIdAsync(id);

            // Get the logged-in user's username from local storage or session
            var userName = _httpContextAccessor.HttpContext?.User.Identity?.Name ?? "Unknown";

            if (admin == null)
            {
                // Log the not found event
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "GetAdmin",
                    EntityId = id,
                    UserId = userName, // Store the username directly
                    Timestamp = DateTime.UtcNow,
                    Description = $"{userName} attempted to fetch admin with id {id}, but it was not found",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString()
                });

                return NotFound();
            }

            // Log the successful retrieval
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "GetAdmin",
                EntityId = id,
                UserId = userName, // Store the username directly
                Timestamp = DateTime.UtcNow,
                Description = $"{userName} fetched admin with id {id}",
                IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString()
            });

            return Ok(admin);
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Admin admin)
        {
            // Get the logged-in user's username from local storage or session
            var userName = _httpContextAccessor.HttpContext?.User.Identity?.Name ?? "Unknown";

            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Invalid admin data received.");

                // Log the invalid data attempt
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "RegisterAdmin",
                    EntityId = 0, // Admin is not yet registered
                    UserId = userName, // Store the username directly
                    Timestamp = DateTime.UtcNow,
                    Description = $"{userName} attempted to register an admin with invalid data",
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                    NewValue = admin.Username
                });

                return BadRequest(ModelState);
            }

            try
            {
                // Check if email already exists in the system
                var existingAdmin = await _adminRepository.GetAdminByEmailAsync(admin.Email);
                if (existingAdmin != null)
                {
                    _logger.LogWarning($"Attempt to register with existing email: {admin.Email}");

                    // Log the attempt with an already existing email
                    await _auditTrailService.LogEventAsync(new AuditTrail
                    {
                        Event = "RegisterAdmin",
                        EntityId = 0, // No entity since registration didn't happen
                        UserId = userName, // Store the username directly
                        Timestamp = DateTime.UtcNow,
                        Description = $"{userName} attempted to register an admin with an existing email: {admin.Email}",
                        IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                        NewValue = admin.Email
                    });

                    return StatusCode(409, "Email already exists");
                }

                var createdAdmin = await _adminRepository.CreateAdminAsync(admin);
                _logger.LogInformation($"Admin registered: {createdAdmin.Username}");

                // Log the successful registration
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "RegisterAdmin",
                    EntityId = createdAdmin.Id,
                    UserId = userName, // Store the username directly
                    Timestamp = DateTime.UtcNow,
                    Description = $"{userName} successfully registered an admin",
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                    NewValue = createdAdmin.Username
                });

                return Ok(new { Message = "Admin registered successfully!", Admin = createdAdmin });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while registering the admin.");

                // Log the error event
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "RegisterAdmin",
                    EntityId = 0, // No specific entity
                    UserId = userName, // Store the username directly
                    Timestamp = DateTime.UtcNow,
                    Description = $"{userName} encountered an error while trying to register an admin",
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                    NewValue = admin.Username
                });

                return StatusCode(500, "Internal server error");
            }
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAdmin(int id, [FromBody] Admin admin)
        {
            // Get the logged-in user's username from local storage or session
            var userName = _httpContextAccessor.HttpContext?.User.Identity?.Name ?? "Unknown";

            if (id != admin.Id)
            {
                // Log the ID mismatch event
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "UpdateAdmin",
                    EntityId = id,
                    UserId = userName, // Store the username directly
                    Timestamp = DateTime.UtcNow,
                    Description = $"{userName} attempted to update admin with mismatching ID",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = admin.Username
                });

                return BadRequest();
            }

            // Fetch the current admin before update
            var existingAdmin = await _adminRepository.GetAdminByIdAsync(id);
            if (existingAdmin == null)
            {
                return NotFound(new Response { Status = "Error", Message = "Admin not found" });
            }

            try
            {
                await _adminRepository.UpdateAdminAsync(admin);

                // Log the successful update with old and new values
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "UpdateAdmin",
                    EntityId = admin.Id,
                    UserId = userName, // Store the username directly
                    Timestamp = DateTime.UtcNow,
                    Description = $"{userName} successfully updated admin with id {id}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    OldValue = $"Username: {existingAdmin.Username}, Email: {existingAdmin.Email}",
                    NewValue = $"Username: {admin.Username}, Email: {admin.Email}"
                });

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the admin with id {id}.");

                // Log the error event
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "UpdateAdmin",
                    EntityId = id,
                    UserId = userName, // Store the username directly
                    Timestamp = DateTime.UtcNow,
                    Description = $"{userName} encountered an error while trying to update admin with id {id}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    OldValue = $"Username: {existingAdmin.Username}, Email: {existingAdmin.Email}",
                    NewValue = $"Username: {admin.Username}, Email: {admin.Email}"
                });

                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAdmin(int id)
        {
            // Get the logged-in user's username from local storage or session
            var userName = _httpContextAccessor.HttpContext?.User.Identity?.Name ?? "Unknown";

            try
            {
                await _adminRepository.DeleteAdminAsync(id);

                // Log the successful deletion
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "DeleteAdmin",
                    EntityId = id,
                    UserId = userName, // Store the username directly
                    Timestamp = DateTime.UtcNow,
                    Description = $"{userName} successfully deleted admin with id {id}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString()
                });

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the admin with id {id}.");

                // Log the error event
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "DeleteAdmin",
                    EntityId = id,
                    UserId = userName, // Store the username directly
                    Timestamp = DateTime.UtcNow,
                    Description = $"{userName} encountered an error while trying to delete admin with id {id}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString()
                });

                return StatusCode(500, "Internal server error");
            }
        }
    }
}
