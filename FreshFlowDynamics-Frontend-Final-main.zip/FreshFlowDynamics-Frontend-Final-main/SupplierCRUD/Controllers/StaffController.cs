﻿using SupplierCRUD.Repositories;
using Microsoft.AspNetCore.Mvc;
using SupplierCRUD.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using SupplierCRUD.Services;
using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaffController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IStaffRepository _staffRepository;
        private readonly ILogger<StaffController> _logger;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public StaffController(AppDbContext context, IStaffRepository staffRepository, ILogger<StaffController> logger, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _staffRepository = staffRepository;
            _logger = logger;
            _auditTrailService = auditTrailService;
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Staff>>> GetStaffs()
        {
            var staffs = await _context.Staffs
                                       .FromSqlRaw("EXEC GetAllStaffs")
                                       .ToListAsync();
            return Ok(staffs);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<Staff>> GetStaff(int id)
        {
            try
            {
                var staff = await _context.Staffs
                                          .FromSqlRaw("EXEC GetStaffById @StaffId = {0}", id)
                                          .FirstOrDefaultAsync();

                if (staff == null)
                {
                    return NotFound();
                }

                return Ok(staff);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching the staff member with ID {id}", id);
                return StatusCode(500, "Internal server error while fetching staff");
            }
        }



        [HttpPost]
        [Route("Register")]
        public async Task<IActionResult> Register([FromBody] Staff staff)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Invalid user data received.");
                return BadRequest(ModelState);
            }

            try
            {
                // Generate a unique code for the staff if not provided
                if (string.IsNullOrEmpty(staff.FiveDigitCode))
                {
                    staff.FiveDigitCode = GenerateUniqueCode();
                }

                // Save user to the database
                var createdStaff = await _staffRepository.CreateStaffAsync(staff);
                _logger.LogInformation($"User registered: {createdStaff.Username}");

                // Log the successful registration in the audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "RegisterStaff",
                    EntityId = createdStaff.Id,
                   UserId = User.Identity?.Name ?? "Anonymous", // Assuming this is set, otherwise replace with appropriate user ID
                    Timestamp = DateTime.UtcNow,
                    Description = "Staff registered successfully",
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Username: {createdStaff.Username}, Email: {createdStaff.Email}, FiveDigitCode: {createdStaff.FiveDigitCode}"
                });


                // Return the created staff including the FiveDigitCode
                return Ok(new { Message = "User registered successfully!", Staff = createdStaff });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while registering the user.");
                return StatusCode(500, "Internal server error");
            }
        }

        private string GenerateUniqueCode()
        {
            var random = new Random();
            int code = random.Next(10000, 99999); // Generates a random five-digit number
            return code.ToString();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateStaff(int id, [FromBody] Staff staff)
        {
            if (id != staff.Id)
            {
                return BadRequest();
            }

            // Fetch the existing staff details before updating
            var existingStaff = await _staffRepository.GetStaffsByIdAsync(id);
            if (existingStaff == null)
            {
                return NotFound(new { Message = "Staff not found" });
            }


            try
            {
                await _staffRepository.UpdateStaffAsync(staff);

                // Update the staff details
                await _staffRepository.UpdateStaffAsync(staff);

                // Log the update operation in the audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "UpdateStaff",
                    EntityId = staff.Id,
                   UserId = User.Identity?.Name ?? "Anonymous", // Replace with actual user ID if available
                    Timestamp = DateTime.UtcNow,
                    Description = "Staff updated successfully",
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                    OldValue = $"Username: {existingStaff.Username}, Email: {existingStaff.Email}, FiveDigitCode: {existingStaff.FiveDigitCode}",
                    NewValue = $"Username: {staff.Username}, Email: {staff.Email}, FiveDigitCode: {staff.FiveDigitCode}"
                });


                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the user with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStaff(int id)
        {
            try
            {
                var staff = await _staffRepository.GetStaffsByIdAsync(id);
                if (staff == null)
                {
                    return NotFound(new { Message = "Staff not found" });
                }

                await _staffRepository.DeleteStaffAsync(id);

                // Log the delete operation in the audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "DeleteStaff",
                    EntityId = staff.Id,
                   UserId = User.Identity?.Name ?? "Anonymous", // Replace with actual user ID if available
                    Timestamp = DateTime.UtcNow,
                    Description = "Staff deleted successfully",
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                    OldValue = $"Username: {staff.Username}, Email: {staff.Email}, FiveDigitCode: {staff.FiveDigitCode}",
                    NewValue = null // Since the staff record is deleted
                });



                _logger.LogInformation($"User with id {id} deleted.");
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the user with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
