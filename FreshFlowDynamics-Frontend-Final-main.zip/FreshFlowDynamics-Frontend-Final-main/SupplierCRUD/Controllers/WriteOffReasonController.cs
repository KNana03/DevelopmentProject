﻿using SupplierCRUD.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SupplierCRUD.DTOs;
using SupplierCRUD.Services;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;

namespace SupplierCRUD.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WriteOffReasonController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public WriteOffReasonController(AppDbContext context, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _auditTrailService = auditTrailService;
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpPost("CreateInventoryWriteOffReason")]
        public async Task<ActionResult<WriteOffReason>> CreateInventoryWriteOffReason([FromBody] InventoryWriteOffReasonDTO dto)
        {
            // Fetch the inventory
            var inventory = await _context.Inventories.FindAsync(dto.InventoryId);
            if (inventory == null)
            {
                return NotFound(new { Message = "Inventory item not found." });
            }

            // Check if quantity to write off exceeds available inventory
            if (dto.Quantity > inventory.Quantity)
            {
                return BadRequest(new { Message = "Write-off quantity exceeds available inventory." });
            }

            // Create a new WriteOffReason
            var writeOffReason = new WriteOffReason
            {
                Reason = dto.Reason
            };

            // Add WriteOffReason to the database
            _context.WriteOffReasons.Add(writeOffReason);
            await _context.SaveChangesAsync();

            // Create an InventoryWriteOff record with the quantity
            var inventoryWriteOff = new InventoryWriteOff
            {
                InventoryId = dto.InventoryId,
                WriteOffReasonId = writeOffReason.Id,
                Quantity = dto.Quantity // Store the quantity being written off
            };

            _context.InventoryWriteOffs.Add(inventoryWriteOff);

            // Subtract the write-off quantity from inventory
            inventory.Quantity -= dto.Quantity;
            _context.Entry(inventory).State = EntityState.Modified;  // Mark the inventory as modified

            // Save changes to the database
            await _context.SaveChangesAsync();

            // Create audit trail for creating a write-off reason
            /*var auditTrail = new AuditTrail
            {
                Event = "CreateInventoryWriteOffReason",
                EntityId = writeOffReason.Id,
                UserId = httpContextAccessor.HttpContext?.User?.Identity?.Name,
                Description = $"Created a new inventory write-off reason: {writeOffReason.Reason}.",
                NewValue = JsonConvert.SerializeObject(writeOffReason),
            };
            await _auditTrailService.LogEventAsync(auditTrail);*/

            // Return the write-off reason with the associated inventory write-off
            return CreatedAtAction(nameof(GetWriteOffReason), new { id = writeOffReason.Id }, writeOffReason);
        }




        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateWriteOffReason(int id, [FromBody] WriteOffReason writeOffReason)
        {
            if (id != writeOffReason.Id)
            {
                return BadRequest();
            }

            var oldWriteOffReason = await _context.WriteOffReasons.FindAsync(id);
            _context.Entry(writeOffReason).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            // Create audit trail for updating a write-off reason
            var auditTrail = new AuditTrail
            {
                Event = "UpdateWriteOffReason",
                EntityId = writeOffReason.Id,
                UserId = httpContextAccessor.HttpContext?.User?.Identity?.Name,
                Description = $"Updated inventory write-off reason: {writeOffReason.Reason}.",
                OldValue = JsonConvert.SerializeObject(oldWriteOffReason),
                NewValue = JsonConvert.SerializeObject(writeOffReason),
                // IPAddress = httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
            };
            await _auditTrailService.LogEventAsync(auditTrail);


            return NoContent();
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<WriteOffReason>>> GetWriteOffReasons()
        {
            // Create audit trail for viewing all write-off reasons
            var auditTrail = new AuditTrail
            {
                Event = "ViewWriteOffReasons",
                UserId = httpContextAccessor.HttpContext?.User?.Identity?.Name,
                Description = "Viewed all inventory write-off reasons.",
                // IPAddress = httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
            };
            await _auditTrailService.LogEventAsync(auditTrail);

            return await _context.WriteOffReasons.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WriteOffReason>> GetWriteOffReason(int id)
        {
            var writeOffReason = await _context.WriteOffReasons.FindAsync(id);
            if (writeOffReason == null)
            {
                return NotFound();
            }

            // Create audit trail for viewing a specific write-off reason
            var auditTrail = new AuditTrail
            {
                Event = "ViewWriteOffReason",
                EntityId = writeOffReason.Id,
                UserId = httpContextAccessor.HttpContext?.User?.Identity?.Name,
                Description = $"Viewed inventory write-off reason: {writeOffReason.Reason}.",
                //IPAddress = httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
            };
            await _auditTrailService.LogEventAsync(auditTrail);

            return writeOffReason;
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteWriteOffReason(int id)
        {
            var writeOffReason = await _context.WriteOffReasons.FindAsync(id);
            if (writeOffReason == null)
            {
                return NotFound();
            }

            _context.WriteOffReasons.Remove(writeOffReason);
            await _context.SaveChangesAsync();

            // Create audit trail for deleting a write-off reason
            var auditTrail = new AuditTrail
            {
                Event = "DeleteWriteOffReason",
                EntityId = writeOffReason.Id,
                UserId = httpContextAccessor.HttpContext?.User?.Identity?.Name,
                Description = $"Deleted inventory write-off reason: {writeOffReason.Reason}.",
                OldValue = JsonConvert.SerializeObject(writeOffReason),
                //IPAddress = httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
            };
            await _auditTrailService.LogEventAsync(auditTrail);

            return NoContent();
        }
    }
}
