﻿using SupplierCRUD.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using SupplierCRUD.Services;
using Newtonsoft.Json;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalesController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public SalesController(AppDbContext context, IHttpContextAccessor httpContextAccessor, IAuditTrailService auditTrailService)
        {
            _context = context;
            TwilioClient.Init("AC4956d0b02f05fdd0aa7455821bf4e83c", "f581af282f3c22ab3f2d6f71dfdde9f9");
            _httpContextAccessor = httpContextAccessor;
            _auditTrailService = auditTrailService;
        }

        [HttpGet]
        public async Task<IActionResult> GetSales()
        {
            // Calling the stored procedure to get all sales
            var result = await _context.Sales
                .FromSqlRaw("EXEC GetAllSales")
                .ToListAsync();

            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetSale(int id)
        {
            var sale = await _context.Sales.FindAsync(id);
            if (sale == null) return NotFound();
            return Ok(sale);
        }

        [HttpPost]
        public async Task<IActionResult> CreateSale([FromBody] Sales sale)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var inventoryItem = await _context.Inventories.FindAsync(sale.InventoryId);

            if (inventoryItem == null)
            {
                return NotFound(new { Message = "Inventory not found." });
            }

            if (inventoryItem.Quantity < sale.Quantity)
            {
                return BadRequest(new { Message = "Not enough inventory." });
            }

            inventoryItem.Quantity -= sale.Quantity;
            _context.Sales.Add(sale);
            await _context.SaveChangesAsync();

            // Log the sale in the audit trail
            var userId = _httpContextAccessor.HttpContext?.User?.Identity?.Name;
            var ipAddress = _httpContextAccessor.HttpContext.Connection.RemoteIpAddress.ToString();
            var auditTrail = new AuditTrail
            {
                Event = "Sale",
                EntityId = sale.Id,
                UserId = User.Identity?.Name ?? "Anonymous",
                NewValue = JsonConvert.SerializeObject(sale),
                Description = $"Sale recorded for Inventory ID {sale.InventoryId}, Quantity: {sale.Quantity}.",
                IPAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
            };
            await _auditTrailService.LogEventAsync(auditTrail);


            if (inventoryItem.Quantity < 50)
            {
                SendLowStockSms(inventoryItem);
            }


            return Ok(sale);
        }

        private void SendLowStockSms(Inventory inventory)
        {
            var message = MessageResource.Create(
                body: $"Warning: The stock for {inventory.Name} is low. Current quantity: {inventory.Quantity}.",
                from: new Twilio.Types.PhoneNumber("+14787394227"),
                to: new Twilio.Types.PhoneNumber("+27729652274")
            );
        }

        // New method to handle bulk sales creation
        [HttpPost("bulk")]
        public async Task<IActionResult> CreateMultipleSales([FromBody] List<Sales> sales)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            foreach (var sale in sales)
            {
                var inventoryItem = await _context.Inventories.FindAsync(sale.InventoryId);

                if (inventoryItem == null)
                {
                    return NotFound(new { Message = $"Inventory not found for InventoryId: {sale.InventoryId}" });
                }

                if (inventoryItem.Quantity < sale.Quantity)
                {
                    return BadRequest(new { Message = $"Not enough inventory for InventoryId: {sale.InventoryId}" });
                }

                inventoryItem.Quantity -= sale.Quantity;
                _context.Sales.Add(sale);

                // Log each sale in the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "Sale",
                    EntityId = sale.Id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    NewValue = JsonConvert.SerializeObject(sale),
                    Description = $"Sale recorded for Inventory ID {sale.InventoryId}, Quantity: {sale.Quantity}.",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                if (inventoryItem.Quantity < 50)
                {
                    SendLowStockSms(inventoryItem);
                }
            }

            await _context.SaveChangesAsync();
            return Ok(sales);
        }

        [HttpGet("inventory-quantity/{id}")]
        public async Task<IActionResult> GetInventoryQuantity(int id)
        {
            var inventoryItem = await _context.Inventories.FindAsync(id);

            if (inventoryItem == null)
            {
                return NotFound(new { Message = "Inventory not found." });
            }

            return Ok(new { inventoryItem.Quantity });
        }
        // Add a new returned stock
        [HttpPost("return-stock")]
        public async Task<IActionResult> ReturnStock([FromBody] ReturnedStock returnedStock)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var sale = await _context.Sales.FindAsync(returnedStock.SaleId);
            if (sale == null)
            {
                return NotFound(new { Message = "Sale not found." });
            }

            var inventoryItem = await _context.Inventories.FindAsync(returnedStock.InventoryId);
            if (inventoryItem == null)
            {
                return NotFound(new { Message = "Inventory not found." });
            }

            // Ensure the return quantity does not exceed sold quantity
            if (returnedStock.Quantity > sale.Quantity)
            {
                return BadRequest(new { Message = "Returned quantity cannot exceed sold quantity." });
            }

            // Add the returned stock record to the database
            _context.ReturnedStocks.Add(returnedStock);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Stock returned successfully." });
        }

        // Get all returned stock
        [HttpGet("returned-stock")]
        public async Task<IActionResult> GetReturnedStock()
        {
            var returnedStocks = await _context.ReturnedStocks.ToListAsync();
            return Ok(returnedStocks);
        }


    }
}
