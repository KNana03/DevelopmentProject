﻿using SupplierCRUD.Models;
using SupplierCRUD.Repositories;
using SupplierCRUD.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShiftAssignmentController : ControllerBase
    {
        private readonly IStaffRepository _staffRepository;
        private readonly ILogger<ShiftAssignmentController> _logger;
        private readonly IShiftRepository _shiftRepository;
        private readonly IShiftAssignmentRepository _shiftAssignmentRepository;
        private readonly IStaffAttendanceService _staffAttendanceService;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public ShiftAssignmentController(
            IStaffRepository staffRepository,
            IShiftRepository shiftRepository,
            ILogger<ShiftAssignmentController> logger,
            IShiftAssignmentRepository shiftAssignmentRepository,
            IStaffAttendanceService staffAttendanceService,
            IAuditTrailService auditTrailService,
            IHttpContextAccessor httpContextAccessor)
        {
            _staffRepository = staffRepository ?? throw new ArgumentNullException(nameof(staffRepository));
            _shiftRepository = shiftRepository ?? throw new ArgumentNullException(nameof(shiftRepository));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _shiftAssignmentRepository = shiftAssignmentRepository ?? throw new ArgumentNullException(nameof(shiftAssignmentRepository));
            _staffAttendanceService = staffAttendanceService;
            _auditTrailService = auditTrailService ?? throw new ArgumentNullException();
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpPost("AssignShift/{StaffId}/{shiftId}")]
        public async Task<IActionResult> AssignShiftToStaff(int StaffId, int shiftId)
        {
            try
            {
                // Retrieve the staff and shift entities
                var staff = await _staffRepository.GetStaffByIdAsync(StaffId);
                var shift = await _shiftRepository.GetShiftByIdAsync(shiftId);

                // Check if staff exists
                if (staff == null)
                {
                    _logger.LogWarning("Staff not found for ID {StaffId}", StaffId);
                    return NotFound(new { Message = $"Staff with ID {StaffId} not found." });
                }

                // Check if shift exists
                if (shift == null)
                {
                    _logger.LogWarning("Shift not found for ID {shiftId}", shiftId);
                    return NotFound(new { Message = $"Shift with ID {shiftId} not found." });
                }

                // Create a new shift assignment
                var shiftAssignment = new ShiftAssignment
                {
                    StaffId = StaffId,
                    ShiftId = shiftId,
                    ScanCount = 0 // Initialize scan count
                };

                // Persist the new shift assignment to the database
                await _shiftAssignmentRepository.CreateShiftAssignmentAsync(shiftAssignment);

                // Generate a new random five-digit code for the staff
                var newFiveDigitCode = GenerateRandomFiveDigitCode();
                staff.FiveDigitCode = newFiveDigitCode;

                // Update the staff with the new five-digit code
                await _staffRepository.UpdateStaffAsync(staff);

                // Log audit trail for the shift assignment
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "Assign",
                    EntityId = shiftAssignment.Id,  // Store shiftAssignment ID as the EntityId
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    OldValue = string.Empty, // No previous value since this is a new assignment
                    NewValue = JsonConvert.SerializeObject(shiftAssignment),
                    Description = $"Assigned shift ID {shiftId} to staff ID {StaffId}."
                });

                // Return a success response with the new five-digit code
                return Ok(new { Message = "Shift assigned successfully!", NewFiveDigitCode = newFiveDigitCode });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while assigning shift.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("GetAssignedShifts/{StaffId}")]
        public async Task<IActionResult> GetAssignedShifts(int StaffId)
        {
            try
            {
                var assignedShifts = await _shiftAssignmentRepository.GetAssignmentsByStaffIdAsync(StaffId);
                if (assignedShifts == null || !assignedShifts.Any())
                {
                    return NotFound("No shifts assigned to the staff member.");
                }

                // Log audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "ViewAssignedShifts",
                    EntityId = StaffId,
                    UserId = User.Identity.Name,
                    Timestamp = DateTime.UtcNow,
                    Description = $"Viewed assigned shifts for staff ID {StaffId}"
                });

                return Ok(assignedShifts);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving assigned shifts.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("GetAllAssignedShifts")]
        public async Task<IActionResult> GetAllAssignedShifts()
        {
            try
            {
                var allAssignedShifts = await _shiftAssignmentRepository.GetAllAssignmentsAsync();
                if (allAssignedShifts == null || !allAssignedShifts.Any())
                {
                    return NotFound("No shifts assigned.");
                }



                return Ok(allAssignedShifts);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving all assigned shifts.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete("RemoveAssignedShift/{assignmentId}")]
        public async Task<IActionResult> RemoveAssignedShift(int assignmentId)
        {
            try
            {
                var assignment = await _shiftAssignmentRepository.GetShiftAssignmentByIdAsync(assignmentId);
                if (assignment == null)
                {
                    return NotFound("Shift assignment not found.");
                }

                await _shiftAssignmentRepository.RemoveShiftAssignmentAsync(assignmentId);

                // Log audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "RemoveAssignment",
                    EntityId = assignmentId,
                    UserId = User.Identity.Name,
                    Timestamp = DateTime.UtcNow,
                    OldValue = JsonConvert.SerializeObject(assignment),
                    Description = $"Removed shift assignment ID {assignmentId}"
                });

                return Ok(new { Message = "Shift assignment removed successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while removing shift assignment.");
                return StatusCode(500, "Internal server error");
            }
        }

        private string GenerateRandomFiveDigitCode()
        {
            Random random = new Random();
            return random.Next(10000, 99999).ToString();
        }
    }
}
