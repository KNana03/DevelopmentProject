﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupplierCRUD.Models;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuditTrailController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AuditTrailController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("get-audit-trails")]
        public async Task<IActionResult> GetAuditTrails()
        {
            var auditTrails = await _context.AuditTrails.ToListAsync();
            return Ok(auditTrails);
        }
    }
}
