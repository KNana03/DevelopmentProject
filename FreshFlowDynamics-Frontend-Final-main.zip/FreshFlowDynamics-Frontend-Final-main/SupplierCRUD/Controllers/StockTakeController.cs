﻿using Microsoft.AspNetCore.Mvc;
using SupplierCRUD.Models;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using SupplierCRUD.Services;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StockTakeController : ControllerBase
    {
        private readonly IStockTakeRepository _stockTakeRepository;
        private readonly IOrderRepository _orderRepository; // Inject IOrderRepository to get order details
        private readonly ILogger<StockTakeController> _logger;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public StockTakeController(IStockTakeRepository stockTakeRepository, IOrderRepository orderRepository, ILogger<StockTakeController> logger, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor)
        {
            _stockTakeRepository = stockTakeRepository;
            _orderRepository = orderRepository;
            _logger = logger;
            _auditTrailService = auditTrailService;
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpPost("create")]
        public async Task<IActionResult> CreateStockTake([FromBody] StockTake stockTake)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Invalid stock take data received.");
                return BadRequest(ModelState);
            }

            try
            {
                _logger.LogInformation("Creating new stock take entry...");
                var createdStockTake = await _stockTakeRepository.CreateStockTakeAsync(stockTake);

                // Log the creation in the audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "CreateStockTake",
                    EntityId = createdStockTake.Id,
                   UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    Description = "New stock take entry created",
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"OrderId: {createdStockTake.OrderId}, Quantity: {createdStockTake.Quantity}, Price: {createdStockTake.Price}, Date: {createdStockTake.Date}"
                });



                _logger.LogInformation($"Stock take entry created with ID: {createdStockTake.Id}");
                return Ok(createdStockTake);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating stock take");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("byOrder/{orderId}")]
        public async Task<ActionResult<StockTake>> GetStockTakeByOrderId(int orderId)
        {
            try
            {
                var stockTake = await _stockTakeRepository.GetStockTakesByOrderIdAsync(orderId);
                if (stockTake == null || !stockTake.Any())
                {
                    var order = await _orderRepository.GetOrderByIdAsync(orderId);
                    if (order == null)
                    {
                        return NotFound(); // Return 404 if no order or stock take is found
                    }


                    // Log retrieval in the audit trail
                    await _auditTrailService.LogEventAsync(new AuditTrail
                    {
                        Event = "GetStockTakeByOrderId",
                        EntityId = order.Id,
                       UserId = User.Identity?.Name ?? "Anonymous",
                        Timestamp = DateTime.UtcNow,
                        Description = "Stock take not found, returning order details",
                        IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                        OldValue = $"OrderId: {order.Id}",
                        NewValue = $"OrderId: {order.Id}, Quantity: {order.Quantity}, Price: {order.Price}, Date: {order.OrderDate}"
                    });




                    // Return a default StockTake object with the order's details
                    return Ok(new StockTake
                    {
                        OrderId = order.Id,
                        Quantity = order.Quantity,
                        Price = order.Price,
                        Date = order.OrderDate
                    });
                }
                // Log successful retrieval
                var firstStockTake = stockTake.First();
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "GetStockTakeByOrderId",
                    EntityId = firstStockTake.Id,
                   UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    Description = "Stock take entry retrieved",
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"OrderId: {firstStockTake.OrderId}, Quantity: {firstStockTake.Quantity}, Price: {firstStockTake.Price}, Date: {firstStockTake.Date}"
                });


                return Ok(stockTake.First()); // Return the first matching stock take
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting stock takes for order {orderId}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateStockTake(int id, [FromBody] StockTake stockTake)
        {
            if (id != stockTake.Id)
            {
                // Log ID mismatch
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "UpdateStockTake",
                    EntityId = id,
                   UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    Description = "StockTake ID mismatch",
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString()
                });


                return BadRequest("StockTake ID mismatch.");
            }

            // Fetch the existing stock take before the update
            var existingStockTake = await _stockTakeRepository.GetStockTakeByIdAsync(id);
            if (existingStockTake == null)
            {
                return NotFound(new { Message = "StockTake not found" });
            }

            await _stockTakeRepository.UpdateStockTakeAsync(stockTake);

            // Log the update with old and new values
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "UpdateStockTake",
                EntityId = stockTake.Id,
               UserId = User.Identity?.Name ?? "Anonymous",
                Timestamp = DateTime.UtcNow,
                Description = "Stock take entry updated",
                IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString(),
                OldValue = $"OrderId: {existingStockTake.OrderId}, Quantity: {existingStockTake.Quantity}, Price: {existingStockTake.Price}, Date: {existingStockTake.Date}",
                NewValue = $"OrderId: {stockTake.OrderId}, Quantity: {stockTake.Quantity}, Price: {stockTake.Price}, Date: {stockTake.Date}"
            });


            return NoContent();
        }
    }
}
