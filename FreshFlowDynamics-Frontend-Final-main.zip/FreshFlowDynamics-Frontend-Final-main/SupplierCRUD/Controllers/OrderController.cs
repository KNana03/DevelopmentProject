﻿using Microsoft.AspNetCore.Mvc;
using SupplierCRUD.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SupplierCRUD.Services;
using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IStockTakeRepository _stockTakeRepository;
        private readonly ILogger<OrderController> _logger;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly AppDbContext _context;
        public OrderController(AppDbContext context, IOrderRepository orderRepository, IStockTakeRepository stockTakeRepository, ILogger<OrderController> logger, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _orderRepository = orderRepository;
            _stockTakeRepository = stockTakeRepository;
            _logger = logger;
            _auditTrailService = auditTrailService;
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Order>>> GetOrders()
        {
            var result = await _context.Orders
                .FromSqlRaw("SELECT * FROM Orders")
                .ToListAsync();

            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Order>> GetOrder(int id)
        {
            var order = await _orderRepository.GetOrderByIdAsync(id);
            if (order == null)
            {
                return NotFound();
            }
            return Ok(order);
        }

        [HttpPost("capture")]
        public async Task<IActionResult> CaptureOrder([FromBody] Order order)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Invalid order data received.");
                return BadRequest(ModelState);
            }

            try
            {
                order.OrderDate = DateTime.UtcNow; // Automatically set the order date
                var createdOrder = await _orderRepository.CreateOrderAsync(order);
                _logger.LogInformation($"Order captured: {createdOrder.Id}");

                // Log the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "CreateOrder",
                    EntityId = createdOrder.Id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Description = $"Order {createdOrder.Id} was created with quantity {createdOrder.Quantity}."
                };
                await _auditTrailService.LogEventAsync(auditTrail);


                // Return the created order directly
                return Ok(createdOrder);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while capturing the order.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut("receive/{id}")]
        public async Task<IActionResult> ReceiveOrder(int id)
        {
            try
            {
                var order = await _orderRepository.GetOrderByIdAsync(id);
                if (order == null)
                {
                    return NotFound();
                }

                // Create a new StockTake based on the order
                var stockTake = new StockTake
                {
                    OrderId = order.Id,
                    Quantity = order.Quantity,
                    Price = order.Price,
                    Date = DateTime.UtcNow
                };

                await _stockTakeRepository.CreateStockTakeAsync(stockTake);

                // Update the order's received date
                order.ReceivedDate = DateTime.UtcNow;
                await _orderRepository.UpdateOrderAsync(order);


                // Log the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "ReceiveOrder",
                    EntityId = order.Id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Description = $"Order {order.Id} was received.",

                };
                await _auditTrailService.LogEventAsync(auditTrail);

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while receiving the order with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateOrder(int id, [FromBody] Order order)
        {
            if (id != order.Id)
            {
                return BadRequest();
            }

            try
            {
                await _orderRepository.UpdateOrderAsync(order);

                // Log the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "UpdateOrder",
                    EntityId = order.Id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Description = $"Order {order.Id} was updated with quantity {order.Quantity} and price {order.Price}."
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the order with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut("pay/{id}")]
        public async Task<IActionResult> PaySupplier(int id)
        {
            try
            {
                await _orderRepository.PaySupplierAsync(id);

                // Log the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "PayOrder",
                    EntityId = id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Description = $"Order {id} was marked as paid."
                };
                await _auditTrailService.LogEventAsync(auditTrail);


                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while paying for the order with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOrder(int id)
        {
            try
            {
                await _orderRepository.DeleteOrderAsync(id);

                // Log the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "DeleteOrder",
                    EntityId = id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Description = $"Order {id} was deleted."
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the order with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut("updateStatus/{id}")]
        public async Task<IActionResult> UpdateOrderStatus(int id, [FromBody] UpdateOrderStatusRequest request)
        {
            if (id != request.OrderId)
            {
                return BadRequest("Order ID mismatch.");
            }

            try
            {
                var order = await _orderRepository.GetOrderByIdAsync(id);
                if (order == null)
                {
                    return NotFound();
                }

                order.IsPaid = request.IsPaid;
                await _orderRepository.UpdateOrderAsync(order);

                // Log the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "UpdateOrderStatus",
                    EntityId = order.Id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Description = $"Order {order.Id} status was updated. IsPaid: {order.IsPaid}."
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the order status for order with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("paymenttypes")]
        public async Task<ActionResult<IEnumerable<PaymentType>>> GetPaymentTypes()
        {
            var paymentTypes = await _orderRepository.GetPaymentTypesAsync();
            return Ok(paymentTypes);
        }

    }

    public class UpdateOrderStatusRequest
    {
        public int OrderId { get; set; }
        public bool IsPaid { get; set; }
    }
}
