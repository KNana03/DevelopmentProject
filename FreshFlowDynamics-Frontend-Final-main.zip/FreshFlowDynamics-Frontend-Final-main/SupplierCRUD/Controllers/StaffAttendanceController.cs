﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SupplierCRUD.Models;
using SupplierCRUD.Repositories;
using SupplierCRUD.Services;
using SupplierCRUD.DTOs;
using System;
using System.Threading.Tasks;
using SupplierCRUD.Models.SupplierCRUD.Models;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaffAttendanceController : ControllerBase
    {
        private readonly ILogger<StaffAttendanceController> _logger;
        private readonly IStaffAttendanceRepository _staffAttendanceRepository;
        private readonly IStaffRepository _staffRepository;
        private readonly IShiftAssignmentRepository _shiftAssignmentRepository;
        private readonly IStaffAttendanceService _staffAttendanceService;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public StaffAttendanceController(
            ILogger<StaffAttendanceController> logger,
            IStaffAttendanceRepository staffAttendanceRepository,
            IStaffRepository staffRepository,
            IShiftAssignmentRepository shiftAssignmentRepository,
            IStaffAttendanceService staffAttendanceService,
            IAuditTrailService auditTrailService,
            IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            _staffAttendanceRepository = staffAttendanceRepository;
            _staffRepository = staffRepository;
            _shiftAssignmentRepository = shiftAssignmentRepository;
            _staffAttendanceService = staffAttendanceService;
            _auditTrailService = auditTrailService;
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpPost("check-in")]
        public async Task<IActionResult> CheckIn([FromBody] CheckInOutRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.FiveDigitCode))
            {
                _logger.LogWarning("Invalid check-in data received.");
                return BadRequest("Invalid check-in data.");
            }

            try
            {
                var staff = await _staffRepository.GetStaffByIdAsync(request.StaffId);
                if (staff == null)
                {
                    _logger.LogWarning("Staff not found for ID {StaffId}", request.StaffId);
                    return NotFound("Staff not found.");
                }

                if (staff.FiveDigitCode != request.FiveDigitCode)
                {
                    _logger.LogWarning("Invalid five-digit code for staff ID {StaffId}", request.StaffId);
                    return BadRequest("Invalid five-digit code.");
                }

                var shiftAssignment = await _shiftAssignmentRepository.GetLatestShiftAssignmentByStaffIdAsync(request.StaffId);
                if (shiftAssignment == null)
                {
                    _logger.LogWarning("No shift assignment found for staff ID {StaffId}", request.StaffId);
                    return BadRequest("No shift assignment found for staff.");
                }

                var attendance = new StaffAttendance
                {
                    StaffId = request.StaffId,
                    ShiftAssignmentId = shiftAssignment.Id,
                    CheckInTime = DateTime.UtcNow,
                    IsCheckedIn = true
                };

                await _staffAttendanceRepository.AddAttendanceAsync(attendance);

                // Log the check-in action in the audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "CheckIn",
                    EntityId = attendance.Id,
                   UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    Description = $"Staff '{staff.Username}' checked in",
                    NewValue = $"CheckInTime: {attendance.CheckInTime}, ShiftAssignmentId: {shiftAssignment.Id}",
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString()
                });


                return Ok(new { Message = "Check-in successful." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during check-in.");
                return StatusCode(500, "Internal server error.");
            }
        }

        [HttpPost("check-out")]
        public async Task<IActionResult> CheckOut([FromBody] CheckInOutRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.FiveDigitCode))
            {
                _logger.LogWarning("Invalid check-out data received.");
                return BadRequest("Invalid check-out data.");
            }

            try
            {
                var staff = await _staffRepository.GetStaffByIdAsync(request.StaffId);
                if (staff == null)
                {
                    _logger.LogWarning("Staff not found for ID {StaffId}", request.StaffId);
                    return NotFound("Staff not found.");
                }

                if (staff.FiveDigitCode != request.FiveDigitCode)
                {
                    _logger.LogWarning("Invalid five-digit code for staff ID {StaffId}", request.StaffId);
                    return BadRequest("Invalid five-digit code.");
                }

                var shiftAssignment = await _shiftAssignmentRepository.GetLatestShiftAssignmentByStaffIdAsync(request.StaffId);
                if (shiftAssignment == null)
                {
                    _logger.LogWarning("No shift assignment found for staff ID {StaffId}", request.StaffId);
                    return BadRequest("No shift assignment found for staff.");
                }

                var attendance = await _staffAttendanceRepository.GetAttendanceByStaffIdAndShiftAssignmentIdAsync(request.StaffId, shiftAssignment.Id);
                if (attendance == null || !attendance.IsCheckedIn)
                {
                    _logger.LogWarning("Staff has not checked in for staff ID {StaffId}", request.StaffId);
                    return BadRequest("Staff has not checked in.");
                }

                attendance.CheckOutTime = DateTime.UtcNow;
                attendance.IsCheckedOut = true;

                await _staffAttendanceRepository.UpdateAttendanceAsync(attendance);

                // Log the check-out action in the audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "CheckOut",
                    EntityId = attendance.Id,
                   UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    Description = $"Staff '{staff.Username}' checked out",
                    OldValue = $"CheckInTime: {attendance.CheckInTime}",
                    NewValue = $"CheckOutTime: {attendance.CheckOutTime}",
                    IPAddress = HttpContext.Connection.RemoteIpAddress?.ToString()
                });



                return Ok(new { Message = "Check-out successful." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during check-out.");
                return StatusCode(500, "Internal server error.");
            }
        }
    }
}
