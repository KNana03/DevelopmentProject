﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Threading;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChatbotController : ControllerBase
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly OpenAIConfig _openAIConfig;
        private readonly ILogger<ChatbotController> _logger;
        private readonly string _chatGptUrl = "https://api.openai.com/v1/completions";
        private const int MaxRetries = 5;

        public ChatbotController(IHttpClientFactory clientFactory, IOptions<OpenAIConfig> openAIConfig, ILogger<ChatbotController> logger)
        {
            _clientFactory = clientFactory;
            _openAIConfig = openAIConfig.Value;
            _logger = logger;
        }

        [HttpPost("chat")]
        public async Task<IActionResult> Chat([FromBody] ChatRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.Prompt))
            {
                return BadRequest(new { error = "Prompt is required" });
            }

            var client = _clientFactory.CreateClient();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _openAIConfig.ApiKey);

            var body = new
            {
                model = "gpt-4o-mini",
                messages = new[]
                {
                    new { role = "system", content = "You are a helpful assistant." },
                    new { role = "user", content = request.Prompt }
                }
            };

            var content = new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json");

            int retryCount = 0;
            while (retryCount < MaxRetries)
            {
                var response = await client.PostAsync(_chatGptUrl, content);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Ok(responseContent);
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                {
                    retryCount++;
                    int delay = (int)Math.Pow(2, retryCount) * 1000; // Exponential backoff
                    _logger.LogWarning($"Rate limit exceeded. Retrying in {delay} ms... (Attempt {retryCount})");
                    Thread.Sleep(delay);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError($"Failed to fetch ChatGPT response: {response.StatusCode}, {errorContent}");
                    return StatusCode((int)response.StatusCode, new { error = "Failed to fetch ChatGPT response" });
                }
            }

            _logger.LogError("Too many requests. Please try again later.");
            return StatusCode(429, new { error = "Too many requests. Please try again later." });
        }

        public class ChatRequest
        {
            public string Prompt { get; set; }
        }
    }
}
