﻿using SupplierCRUD.Models;
using SupplierCRUD.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Web;
using System.Diagnostics;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IConfiguration _configuration;
        private readonly IEmailService _emailService;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AuthenticationController(UserManager<IdentityUser> userManager,
            RoleManager<IdentityRole> roleManager, IConfiguration configuration, IEmailService emailService, SignInManager<IdentityUser> signInManager, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _configuration = configuration;
            _emailService = emailService;
            _signInManager = signInManager;
            _auditTrailService = auditTrailService;
            _httpContextAccessor = httpContextAccessor;
        }

        // Register Method
        [HttpPost("Register")]
        public async Task<IActionResult> Register([FromBody] RegisterUser registerUser)
        {
            try
            {
                var userExist = await _userManager.FindByEmailAsync(registerUser.Email);
                if (userExist != null)
                {
                    return StatusCode(StatusCodes.Status403Forbidden,
                        new Response { Status = "Error", Message = "User Already exists!" });
                }

                IdentityUser user = new()
                {
                    Email = registerUser.Email,
                    SecurityStamp = Guid.NewGuid().ToString(),
                    UserName = registerUser.UserName,
                    TwoFactorEnabled = true
                };

                var result = await _userManager.CreateAsync(user, registerUser.Password);
                if (!result.Succeeded)
                {
                    var errors = string.Join(", ", result.Errors.Select(e => e.Description));
                    return StatusCode(StatusCodes.Status500InternalServerError,
                        new Response { Status = "Error", Message = $"User failed to create! Errors: {errors}" });
                }

                // Generate the email confirmation token and encode it
                var token = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                var encodedToken = HttpUtility.UrlEncode(token); // Encode the token

                // Create the confirmation link
                var confirmationLink = Url.Action(nameof(ConfirmEmail), "Authentication", new { token = encodedToken, email = user.Email }, Request.Scheme);

                // Create the email message
                var message = new Message(new string[] { user.Email }, "Confirmation email link", $"Please confirm your account by clicking this link: {confirmationLink}");

                // Send the email
                _emailService.SendEmail(message);

                // Log the registration event
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "Register",
                    EntityId = 0, // Use 0 or skip assignment since user ID cannot be converted to int
                    UserId = user.Id,
                    Timestamp = DateTime.UtcNow,
                    Description = $"User '{user.UserName}' registered",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"UserName: {user.UserName}, Email: {user.Email}"
                });

                return StatusCode(StatusCodes.Status200OK,
                    new Response { Status = "Success", Message = $"User created & Email Sent to {user.Email} successfully" });
            }
            catch (Exception ex)
            {
                // Log the exception
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "Register",
                    EntityId = 0,
                    UserId = "Unknown",
                    Timestamp = DateTime.UtcNow,
                    Description = $"Exception occurred: {ex.Message}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Email: {registerUser.Email}"
                });

                return StatusCode(StatusCodes.Status500InternalServerError,
                    new Response { Status = "Error", Message = $"An error occurred: {ex.Message}" });
            }
        }

        // ConfirmEmail Method
        [HttpGet("ConfirmEmail")]
        public async Task<IActionResult> ConfirmEmail(string token, string email)
        {
            try
            {
                // Decode the token
                var decodedToken = HttpUtility.UrlDecode(token);
                var user = await _userManager.FindByEmailAsync(email);

                if (user != null)
                {
                    // Confirm the email
                    var result = await _userManager.ConfirmEmailAsync(user, decodedToken);
                    if (result.Succeeded)
                    {
                        // Log the email confirmation
                        await _auditTrailService.LogEventAsync(new AuditTrail
                        {
                            Event = "ConfirmEmail",
                            EntityId = 0, // Use 0 or skip assignment
                            UserId = user.Id,
                            Timestamp = DateTime.UtcNow,
                            Description = $"Email confirmed for user '{user.UserName}'",
                            IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                            NewValue = $"UserName: {user.UserName}, Email: {user.Email}"
                        });

                        // Automatically sign in the user after email confirmation
                        await _signInManager.SignInAsync(user, isPersistent: false);
                        return StatusCode(StatusCodes.Status200OK,
                            new Response { Status = "Success", Message = "Email Verified Successfully. You are now logged in." });
                    }
                    else
                    {
                        var errors = string.Join(", ", result.Errors.Select(e => e.Description));
                        return StatusCode(StatusCodes.Status500InternalServerError,
                            new Response { Status = "Error", Message = $"Email verification failed! Errors: {errors}" });
                    }
                }
                return StatusCode(StatusCodes.Status404NotFound,
                    new Response { Status = "Error", Message = "This user does not exist" });
            }
            catch (Exception ex)
            {
                // Log the exception
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "ConfirmEmail",
                    EntityId = 0,
                    UserId = "Unknown",
                    Timestamp = DateTime.UtcNow,
                    Description = $"Exception occurred: {ex.Message}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Email: {email}"
                });

                return StatusCode(StatusCodes.Status500InternalServerError,
                    new Response { Status = "Error", Message = $"An error occurred: {ex.Message}" });
            }
        }

        // Login Method
        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel loginModel)
        {
            var user = await _userManager.FindByNameAsync(loginModel.Username);
            if (user == null)
            {
                // Log the failed login attempt due to user not found
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "Login",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = "Unknown",
                    Timestamp = DateTime.UtcNow,
                    Description = "Failed login attempt - User not found",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Username: {loginModel.Username}"
                });

                return Unauthorized(new Response { Status = "Error", Message = "User not found" });
            }

            if (!await _userManager.CheckPasswordAsync(user, loginModel.Password))
            {
                // Log the failed login attempt due to invalid password
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "Login",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = user.Id,
                    Timestamp = DateTime.UtcNow,
                    Description = "Failed login attempt - Invalid password",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Username: {loginModel.Username}"
                });

                return Unauthorized(new Response { Status = "Error", Message = "Invalid password" });
            }

            var authClaims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.UserName),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var userRole = await _userManager.GetRolesAsync(user);
            foreach (var role in userRole)
            {
                authClaims.Add(new Claim(ClaimTypes.Role, role));
            }

            var jwtToken = GetToken(authClaims);

            // Log the successful login attempt
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "Login",
                EntityId = 0, // Use 0 or skip assignment
                UserId = user.Id,
                Timestamp = DateTime.UtcNow,
                Description = "Successful login",
                IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                NewValue = $"Username: {user.UserName}"
            });

            return Ok(new
            {
                token = new JwtSecurityTokenHandler().WriteToken(jwtToken),
                expiration = jwtToken.ValidTo,
                username = user.UserName // Include username in response
            });
        }

        // VerifyOTP Method
        [HttpPost]
        [AllowAnonymous]
        [Route("verify-otp")]
        public async Task<IActionResult> VerifyOTP([FromBody] VerifyOTPRequest request)
        {
            var user = await _userManager.FindByEmailAsync(request.Email);
            if (user != null)
            {
                var isValid = await _userManager.VerifyTwoFactorTokenAsync(user, "Email", request.Otp);
                if (isValid)
                {
                    // Log the OTP verification
                    await _auditTrailService.LogEventAsync(new AuditTrail
                    {
                        Event = "VerifyOTP",
                        EntityId = 0, // Use 0 or skip assignment
                        UserId = user.Id,
                        Timestamp = DateTime.UtcNow,
                        Description = "OTP verified successfully",
                        IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                        NewValue = $"UserName: {user.UserName}, Email: {user.Email}"
                    });

                    // Automatically sign in the user after OTP verification
                    await _signInManager.SignInAsync(user, isPersistent: false);
                    return Ok(new { Status = "Success", Message = "OTP verified successfully. You are now logged in.", Email = user.Email });
                }
            }

            return StatusCode(StatusCodes.Status400BadRequest,
                new Response { Status = "Error", Message = "Invalid OTP" });
        }

        // ForgotPassword Method
        [HttpPost]
        [AllowAnonymous]
        [Route("forgot-password")]
        public async Task<IActionResult> ForgotPassword([Required] EmailRequest request)
        {
            try
            {
                var user = await _userManager.FindByEmailAsync(request.Email);
                if (user != null)
                {
                    var token = await _userManager.GenerateTwoFactorTokenAsync(user, "Email");
                    var encodedToken = HttpUtility.UrlEncode(token); // Encode the token

                    var message = new Message(new string[] { user.Email }, "OTP Confirmation", $"Your OTP is: {token}. Please confirm your account by clicking this link: {Url.Action(nameof(ConfirmEmail), "Authentication", new { token = encodedToken, email = user.Email }, Request.Scheme)}");
                    _emailService.SendEmail(message);

                    // Log the password reset request
                    await _auditTrailService.LogEventAsync(new AuditTrail
                    {
                        Event = "ForgotPassword",
                        EntityId = 0, // Use 0 or skip assignment
                        UserId = user.Id,
                        Timestamp = DateTime.UtcNow,
                        Description = "Password reset requested",
                        IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                        NewValue = $"Email: {request.Email}"
                    });

                    return Ok(new Response { Status = "Success", Message = $"OTP sent to email {user.Email}" });
                }

                // Log the failed attempt
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "ForgotPassword",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = "Unknown",
                    Timestamp = DateTime.UtcNow,
                    Description = "Failed password reset request - Email not found",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Email: {request.Email}"
                });

                return StatusCode(StatusCodes.Status400BadRequest,
                    new Response { Status = "Error", Message = "Could not send OTP to email, please try again" });
            }
            catch (Exception ex)
            {
                // Log the exception
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "ForgotPassword",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = "Unknown",
                    Timestamp = DateTime.UtcNow,
                    Description = $"Exception occurred: {ex.Message}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Email: {request.Email}"
                });

                return StatusCode(StatusCodes.Status500InternalServerError,
                    new Response { Status = "Error", Message = $"An error occurred: {ex.Message}" });
            }
        }

        // CreateRole Method
        [HttpPost]
        [Route("CreateRole")]
        public async Task<IActionResult> CreateRole(string roleName)
        {
            var role = await _roleManager.FindByNameAsync(roleName);
            if (role == null)
            {
                role = new IdentityRole
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = roleName
                };

                var result = await _roleManager.CreateAsync(role);

                // Log the role creation attempt
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "CreateRole",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    Description = result.Succeeded ? "Role created successfully" : "Failed to create role",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"RoleName: {roleName}"
                });

                if (result.Errors.Count() > 0) return BadRequest(result.Errors);
            }
            else
            {
                // Log the role already exists attempt
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "CreateRole",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    Description = "Role already exists",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"RoleName: {roleName}"
                });

                return Forbid("Role already exists.");
            }

            return Ok();
        }

        [HttpPost]
        [Route("UpdateUserRole")]
        public async Task<IActionResult> UpdateUserRole(string emailAddress, string oldRoleName, string newRoleName)
        {
            var user = await _userManager.FindByEmailAsync(emailAddress);
            if (user == null)
            {
                // Log the failed user lookup
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "UpdateUserRole",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = "Unknown",
                    Timestamp = DateTime.UtcNow,
                    Description = "User not found",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"OldRoleName: {oldRoleName}, NewRoleName: {newRoleName}"
                });

                return NotFound(new Response { Status = "Error", Message = "User not found" });
            }

            var removeResult = await _userManager.RemoveFromRoleAsync(user, oldRoleName);
            if (!removeResult.Succeeded)
            {
                var errors = string.Join(", ", removeResult.Errors.Select(e => e.Description));

                // Log the failed role removal
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "UpdateUserRole",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = user.Id,
                    Timestamp = DateTime.UtcNow,
                    Description = $"Failed to remove old role! Errors: {errors}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"OldRoleName: {oldRoleName}, NewRoleName: {newRoleName}"
                });

                return BadRequest(new Response { Status = "Error", Message = $"Failed to remove old role! Errors: {errors}" });
            }

            var addResult = await _userManager.AddToRoleAsync(user, newRoleName);
            if (!addResult.Succeeded)
            {
                var errors = string.Join(", ", addResult.Errors.Select(e => e.Description));

                // Log the failed role addition
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "UpdateUserRole",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = user.Id,
                    Timestamp = DateTime.UtcNow,
                    Description = $"Failed to add new role! Errors: {errors}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"OldRoleName: {oldRoleName}, NewRoleName: {newRoleName}"
                });

                return BadRequest(new Response { Status = "Error", Message = $"Failed to add new role! Errors: {errors}" });
            }

            // Log the successful role update
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "UpdateUserRole",
                EntityId = 0, // Use 0 or skip assignment
                UserId = user.Id,
                Timestamp = DateTime.UtcNow,
                Description = "User role updated successfully",
                IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                NewValue = $"OldRoleName: {oldRoleName}, NewRoleName: {newRoleName}"
            });

            return Ok(new Response { Status = "Success", Message = "User role updated successfully" });
        }

        [HttpGet]
        [Route("GetUserRoles")]
        public async Task<IActionResult> GetUserRoles(string emailAddress)
        {
            var user = await _userManager.FindByEmailAsync(emailAddress);
            if (user == null)
            {
                return NotFound(new Response { Status = "Error", Message = "User not found" });
            }

            var roles = await _userManager.GetRolesAsync(user);
            return Ok(new { User = emailAddress, Roles = roles });
        }

        [HttpPost]
        [Route("DeleteUserRole")]
        public async Task<IActionResult> DeleteUserRole(string emailAddress, string roleName)
        {
            var user = await _userManager.FindByEmailAsync(emailAddress);
            if (user == null)
            {
                // Log the failed user lookup
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "DeleteUserRole",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = "Unknown",
                    Timestamp = DateTime.UtcNow,
                    Description = "User not found",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"RoleName: {roleName}"
                });

                return NotFound(new Response { Status = "Error", Message = "User not found" });
            }

            var result = await _userManager.RemoveFromRoleAsync(user, roleName);
            if (!result.Succeeded)
            {
                var errors = string.Join(", ", result.Errors.Select(e => e.Description));

                // Log the failed role removal
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "DeleteUserRole",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = user.Id,
                    Timestamp = DateTime.UtcNow,
                    Description = $"Failed to remove role! Errors: {errors}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"RoleName: {roleName}"
                });

                return BadRequest(new Response { Status = "Error", Message = $"Failed to remove role! Errors: {errors}" });
            }

            // Log the successful role removal
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "DeleteUserRole",
                EntityId = 0, // Use 0 or skip assignment
                UserId = user.Id,
                Timestamp = DateTime.UtcNow,
                Description = "User role removed successfully",
                IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                NewValue = $"RoleName: {roleName}"
            });

            return Ok(new Response { Status = "Success", Message = "User role removed successfully" });
        }

        // AssignRole Method
        [HttpPost]
        [Route("AssignRole")]
        public async Task<IActionResult> AssignRole(string emailAddress, string roleName)
        {
            var user = await _userManager.FindByEmailAsync(emailAddress);
            if (user == null)
            {
                // Log the failed user lookup
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "AssignRole",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = "Unknown",
                    Timestamp = DateTime.UtcNow,
                    Description = "User not found",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"RoleName: {roleName}"
                });

                return NotFound();
            }

            if (!IsRoleAllowed(roleName))
            {
                // Log the unauthorized role assignment attempt
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "AssignRole",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = user.Id,
                    Timestamp = DateTime.UtcNow,
                    Description = "Unauthorized role assignment attempt",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"RoleName: {roleName}"
                });

                return Forbid("You do not have permission to assign this role.");
            }

            var result = await _userManager.AddToRoleAsync(user, roleName);

            // Log the successful role assignment
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "AssignRole",
                EntityId = 0, // Use 0 or skip assignment
                UserId = user.Id,
                Timestamp = DateTime.UtcNow,
                Description = "Role assigned successfully",
                IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                NewValue = $"RoleName: {roleName}"
            });

            if (result.Succeeded) return Ok();

            return BadRequest(result.Errors);
        }

        // IsRoleAllowed Method
        private bool IsRoleAllowed(string roleName)
        {
            // Define your business logic here
            // Example: Only allow 'Admin' role to assign 'SalesStaff' role
            if (roleName == "Staff")
            {
                var currentUserRoles = User.Claims.Where(c => c.Type == ClaimTypes.Role).Select(c => c.Value);
                if (!currentUserRoles.Contains("Admin"))
                {
                    return false;
                }
            }

            // Add more business logic as needed

            return true;
        }

        // RoleTest Method
        [HttpGet]
        [Authorize(AuthenticationSchemes = "Bearer")]
        [Authorize(Roles = "Admin, Staff, WarehouseManager, Cashier")]
        [Route("RoleTest")]
        public IActionResult RoleTest()
        {
            return Ok("You are an admin or manager!!!");
        }

        // GetToken Method
        private JwtSecurityToken GetToken(List<Claim> authClaims)
        {
            var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));
            var token = new JwtSecurityToken(
                issuer: _configuration["JWT:ValidIssuer"],
                audience: _configuration["JWT:ValidAudience"],
                expires: DateTime.Now.AddHours(3),
                claims: authClaims,
                signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
            );
            return token;
        }

        // Delete User Endpoint without Authorization
        [HttpDelete("{email}")]
        public async Task<IActionResult> DeleteUser(string email)
        {
            try
            {
                var user = await _userManager.FindByEmailAsync(email);
                if (user == null)
                {
                    return NotFound(new Response { Status = "Error", Message = "User not found" });
                }

                var result = await _userManager.DeleteAsync(user);
                if (!result.Succeeded)
                {
                    var errors = string.Join(", ", result.Errors.Select(e => e.Description));
                    return StatusCode(StatusCodes.Status500InternalServerError,
                        new Response { Status = "Error", Message = $"User deletion failed! Errors: {errors}" });
                }

                // Log the successful user deletion
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "DeleteUser",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = user.Id,
                    Timestamp = DateTime.UtcNow,
                    Description = $"User '{user.UserName}' deleted",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Email: {user.Email}"
                });

                return Ok(new Response { Status = "Success", Message = "User deleted successfully" });
            }
            catch (Exception ex)
            {
                // Log the exception
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "DeleteUser",
                    EntityId = 0,
                    UserId = "Unknown",
                    Timestamp = DateTime.UtcNow,
                    Description = $"Exception occurred: {ex.Message}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Email: {email}"
                });

                return StatusCode(StatusCodes.Status500InternalServerError,
                    new Response { Status = "Error", Message = $"An error occurred: {ex.Message}" });
            }
        }

        [HttpPost("UpdatePassword")]
        public async Task<IActionResult> UpdatePassword([FromBody] UpdatePasswordModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = await _userManager.FindByNameAsync(model.Username);
            if (user == null || user.Email != model.Email)
            {
                // Log the invalid username or email attempt
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "UpdatePassword",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = "Unknown",
                    Timestamp = DateTime.UtcNow,
                    Description = "Invalid username or email",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Email: {model.Email}"
                });

                return BadRequest(new Response { Status = "Error", Message = "Invalid username or email" });
            }

            var result = await _userManager.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword);
            if (result.Succeeded)
            {
                // Generate the email confirmation token and encode it
                var token = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                var encodedToken = HttpUtility.UrlEncode(token); // Encode the token

                // Create the confirmation link
                var confirmationLink = Url.Action(nameof(ConfirmEmail), "Authentication", new { token = encodedToken, email = user.Email }, Request.Scheme);

                // Create the email message
                var message = new Message(new string[] { user.Email }, "Password Change Confirmation", $"Your password has been changed. Please confirm your account by clicking this link: {confirmationLink}");

                // Send the email
                _emailService.SendEmail(message);

                // Log the successful password update
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "UpdatePassword",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = user.Id,
                    Timestamp = DateTime.UtcNow,
                    Description = "Password updated successfully",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Email: {user.Email}"
                });

                return Ok(new Response { Status = "Success", Message = "Password updated successfully. A confirmation email has been sent." });
            }

            var errors = string.Join(", ", result.Errors.Select(e => e.Description));

            // Log the password update failure
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "UpdatePassword",
                EntityId = 0, // Use 0 or skip assignment
                UserId = user.Id,
                Timestamp = DateTime.UtcNow,
                Description = $"Password update failed! Errors: {errors}",
                IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                NewValue = $"Email: {model.Email}"
            });

            return StatusCode(StatusCodes.Status500InternalServerError,
                new Response { Status = "Error", Message = $"Password update failed! Errors: {errors}" });
        }

        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPassword model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user == null)
            {
                // Log the failed user lookup
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "ResetPassword",
                    EntityId = 0, // Use 0 or skip assignment
                    UserId = "Unknown",
                    Timestamp = DateTime.UtcNow,
                    Description = "User not found",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                    NewValue = $"Password: [REDACTED]"
                });

                return BadRequest(new Response { Status = "Error", Message = "User not found" });
            }

            var resetPassResult = await _userManager.RemovePasswordAsync(user);
            if (resetPassResult.Succeeded)
            {
                var addPassResult = await _userManager.AddPasswordAsync(user, model.Password);
                if (addPassResult.Succeeded)
                {
                    // Log the successful password reset
                    await _auditTrailService.LogEventAsync(new AuditTrail
                    {
                        Event = "ResetPassword",
                        EntityId = 0, // Use 0 or skip assignment
                        UserId = user.Id,
                        Timestamp = DateTime.UtcNow,
                        Description = "Password has been changed",
                        IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                        NewValue = $"Email: {user.Email}"
                    });

                    return Ok(new Response { Status = "Success", Message = "Password has been changed" });
                }

                foreach (var error in addPassResult.Errors)
                {
                    // Log the failed password addition
                    await _auditTrailService.LogEventAsync(new AuditTrail
                    {
                        Event = "ResetPassword",
                        EntityId = 0, // Use 0 or skip assignment
                        UserId = user.Id,
                        Timestamp = DateTime.UtcNow,
                        Description = $"Failed to add new password! Errors: {error}",
                        IPAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress?.ToString(),
                        NewValue = $"Email: {user.Email}"
                    });

                    ModelState.AddModelError(error.Code, error.Description);
                }
            }
            else
            {
                foreach (var error in resetPassResult.Errors)
                {
                    ModelState.AddModelError(error.Code, error.Description);
                }
            }

            return BadRequest(ModelState);
        }

        [HttpGet("GetUserById/{id}")]
        public async Task<IActionResult> GetUserById(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(new { user.UserName, user.Email });
        }

    }
}
