﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupplierCRUD.Models;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnalyticsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AnalyticsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("order-metrics")]
        public async Task<IActionResult> GetOrderMetrics()
        {
            var totalOrders = await _context.Orders.CountAsync();
            var totalRevenue = await _context.Orders.SumAsync(o => o.Price * o.Quantity);
            var mostOrderedProduct = await _context.Orders
                .GroupBy(o => o.Type)
                .OrderByDescending(g => g.Sum(o => o.Quantity))
                .Select(g => new { Type = g.Key, Quantity = g.Sum(o => o.Quantity) })
                .FirstOrDefaultAsync();

            var result = new
            {
                TotalOrders = totalOrders,
                TotalRevenue = totalRevenue,
                MostOrderedProduct = mostOrderedProduct?.Type ?? "N/A"
            };

            return Ok(result);
        }

        [HttpPost("log-page-request")]
        public async Task<IActionResult> LogPageRequest([FromBody] PageRequestData data)
        {
            if (data == null || string.IsNullOrEmpty(data.PageName) || string.IsNullOrEmpty(data.UserName))
            {
                return BadRequest("Page name and username are required.");
            }

            var pageRequest = await _context.PageRequests
                .FirstOrDefaultAsync(pr => pr.PageName == data.PageName && pr.UserName == data.UserName);

            if (pageRequest == null)
            {
                pageRequest = new PageRequest { PageName = data.PageName, UserName = data.UserName, RequestCount = 1 };
                _context.PageRequests.Add(pageRequest);
            }
            else
            {
                pageRequest.RequestCount++;
                _context.PageRequests.Update(pageRequest);
            }

            await _context.SaveChangesAsync();
            return Ok();
        }

        public class PageRequestData
        {
            public string PageName { get; set; }
            public string UserName { get; set; }  // Add this property
        }


        [HttpGet("page-requests")]
        public async Task<IActionResult> GetPageRequests()
        {
            var pageRequests = await _context.PageRequests.ToListAsync();
            return Ok(pageRequests);
        }

        [HttpPost("reset-page-requests")]
        public async Task<IActionResult> ResetPageRequests()
        {
            _context.PageRequests.RemoveRange(_context.PageRequests);
            await _context.SaveChangesAsync();
            return Ok(new { Message = "Page requests have been reset." });
        }
    }

 
}


