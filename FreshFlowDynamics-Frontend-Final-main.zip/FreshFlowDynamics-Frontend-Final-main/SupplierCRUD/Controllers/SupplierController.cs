﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SupplierCRUD.Models;
using SupplierCRUD.Services;
using System.Net.Mime;
using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ISupplierRepository _supplierRepository;
        private readonly IDocumentRepository _documentRepository;
        private readonly ILogger<SupplierController> _logger;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IExcelExportService _excelExportService;
        private readonly IExcelImportService _excelImportService;

        public SupplierController(AppDbContext context,ISupplierRepository supplierRepository, IDocumentRepository documentRepository, ILogger<SupplierController> logger, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor, IExcelExportService excelExportService, IExcelImportService excelImportService)
        {
            _context = context;
            
            _supplierRepository = supplierRepository;
            _documentRepository = documentRepository;
            _logger = logger;
            _auditTrailService = auditTrailService;
            _httpContextAccessor = httpContextAccessor;
            _excelExportService = excelExportService;
            _excelImportService = excelImportService;

        }

       [HttpGet]
public async Task<ActionResult<List<Supplier>>> GetAllSuppliersSP()
{
    var result = await _context.Suppliers
        .FromSqlRaw("SELECT * FROM Suppliers")
        .ToListAsync();

    return Ok(result);
}


        [HttpGet("{id}")]
        public async Task<ActionResult<Supplier>> GetSupplier(int id)
        {
            var supplier = await _supplierRepository.GetSuppliersByIdAsync(id);
            if (supplier == null)
            {
                return NotFound();
            }
            return Ok(supplier);
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register([FromBody] Supplier supplier)
        {
            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Invalid supplier data received.");
                return BadRequest(ModelState);
            }
            try
            {
                var createdSupplier = await _supplierRepository.CreateSupplierAsync(supplier);
                _logger.LogInformation($"Supplier registered: {createdSupplier.Name}");

                // Check for null identity and set a fallback value if necessary
                var userId = User?.Identity?.Name ?? "Anonymous"; // Fallback to "Anonymous" or another default value

                // Log the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "Create Supplier",
                    EntityId = createdSupplier.Id,
                    UserId = userId,
                    NewValue = $"Supplier: {createdSupplier.Name}",
                    Description = "Supplier registered",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                return Ok(new { Message = "Supplier registered successfully!" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while registering the Supplier.");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateSupplier(int id, [FromBody] Supplier supplier)
        {
            if (id != supplier.Id)
            {
                return BadRequest();
            }
            try
            {
                var existingSupplier = await _supplierRepository.GetSuppliersByIdAsync(id);
                if (existingSupplier == null)
                {
                    return NotFound();
                }

                await _supplierRepository.UpdateSupplierAsync(supplier);

                var userId = User?.Identity?.Name ?? "Anonymous";
                var ipAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString() ?? "Unknown IP";

                var auditTrail = new AuditTrail
                {
                    Event = "Update Supplier",
                    EntityId = supplier.Id,
                    UserId = userId,
                    OldValue = $"Supplier: {existingSupplier.Name}",
                    NewValue = $"Supplier: {supplier.Name}",
                    Description = "Supplier updated",
                    IPAddress = ipAddress
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                return NoContent();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the supplier with id {id}: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the supplier with id {id}");
                return StatusCode(500, "Internal server error");
            }
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSupplier(int id)
        {
            try
            {
                var existingSupplier = await _supplierRepository.GetSuppliersByIdAsync(id);
                if (existingSupplier == null)
                {
                    return NotFound();
                }

                await _supplierRepository.DeleteSupplierAsync(id);

                // Check for null identity and set a fallback value if necessary
                var userId = User?.Identity?.Name ?? "Anonymous"; // Fallback to "Anonymous" or another default value

                // Log the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "Delete Supplier",
                    EntityId = id,
                    UserId = userId,
                    OldValue = $"Supplier: {existingSupplier.Name}",
                    Description = "Supplier deleted",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the supplier with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("{supplierId}/documents")]
        public async Task<ActionResult<IEnumerable<Document>>> GetDocuments(int supplierId, [FromQuery] string fileType = "all")
        {
            try
            {
                var documents = await _context.Documents
                                              .FromSqlRaw("EXEC GetDocumentsBySupplier @SupplierId = {0}, @FileType = {1}", supplierId, fileType)
                                              .ToListAsync();

                return Ok(documents);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching documents.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost("{supplierId}/documents")]
        public async Task<IActionResult> UploadDocument(int supplierId, [FromForm] IFormFile file, [FromForm] string fileType)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("No file uploaded.");
            }

            var uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "Uploads");
            Directory.CreateDirectory(uploadPath);

            var filePath = Path.Combine(uploadPath, file.FileName);

            try
            {
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                var document = new Document
                {
                    SupplierId = supplierId,
                    FileName = file.FileName,
                    FileType = fileType,  // Ensure fileType is correctly set
                    FilePath = filePath
                };

                await _documentRepository.UploadDocumentAsync(document);

                // Check for null identity and set a fallback value if necessary
                var userId = User?.Identity?.Name ?? "Anonymous"; // Fallback to "Anonymous" or another default value

                // Log the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "Upload Document",
                    EntityId = supplierId,
                    UserId = userId,
                    NewValue = $"Document: {file.FileName}, FileType: {fileType}",
                    Description = $"Document uploaded for Supplier ID {supplierId}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                return Ok(new { Message = "File uploaded successfully!" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while uploading the document.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("documents/download/{documentId}")]
        public async Task<IActionResult> DownloadDocument(int documentId)
        {
            try
            {
                var document = await _documentRepository.GetDocumentByIdAsync(documentId);
                if (document == null || !System.IO.File.Exists(document.FilePath))
                {
                    return NotFound();
                }

                var memory = new MemoryStream();
                using (var stream = new FileStream(document.FilePath, FileMode.Open))
                {
                    await stream.CopyToAsync(memory);
                }
                memory.Position = 0;

                // Check for null identity and set a fallback value if necessary
                var userId = User?.Identity?.Name ?? "Anonymous"; // Fallback to "Anonymous" or another default value

                // Log the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "Download Document",
                    EntityId = document.SupplierId,
                    UserId = userId,
                    Description = $"Document downloaded: {document.FileName}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                // Return the PDF file with the correct MIME type
                return File(memory, MediaTypeNames.Application.Pdf, Path.GetFileName(document.FilePath));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while downloading the document.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete("documents/{documentId}")]
        public async Task<IActionResult> DeleteDocument(int documentId)
        {
            try
            {
                var document = await _documentRepository.GetDocumentByIdAsync(documentId);
                if (document == null)
                {
                    return NotFound();
                }

                await _documentRepository.DeleteDocumentAsync(documentId);

                // Check for null identity and set a fallback value if necessary
                var userId = User?.Identity?.Name ?? "Anonymous"; // Fallback to "Anonymous" or another default value

                // Log the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "Delete Document",
                    EntityId = document.SupplierId,
                    UserId = userId,
                    OldValue = $"Document: {document.FileName}, FileType: {document.FileType}",
                    Description = $"Document deleted: {document.FileName}",
                    IPAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString()
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the document with ID {documentId}.");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpGet]
        [Route("ExportSupplierToExcel")]
        public async Task<IActionResult> ExportSupplierToExcel()
        {
            var suppliers = await _supplierRepository.GetAllSuppliersAsync();

            // Check if the suppliers list is null or empty
            if (suppliers == null || !suppliers.Any())
            {
                return NotFound("No suppliers found to export.");
            }

            // Convert IEnumerable<Supplier> to List<Supplier>
            var suppliersList = suppliers.ToList();

            // Call the export service and pass the suppliers list
            var fileContents = await _excelExportService.ExportSuppliersToExcelAsync(suppliersList);

            // Return the Excel file
            return File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Suppliers.xlsx");
        }

        [HttpPost]
        [Route("ImportSuppliersFromExcel")]
        public async Task<IActionResult> ImportSuppliersFromExcel(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded.");

            try
            {
                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    stream.Position = 0; // Reset stream position

                    // Import and update suppliers from Excel
                    var result = await _excelImportService.ImportSuppliersFromExcelAsync(stream);
                    if (result)
                        return Ok("Suppliers imported and updated successfully.");
                    else
                        return StatusCode(500, "Error occurred while importing suppliers.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while importing suppliers.");
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
