﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SupplierCRUD.Models;
using SupplierCRUD.Services;
using SupplierCRUD.ViewModels;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VATController : ControllerBase
    {
        private readonly IVATRepository _vatRepository;
        private readonly AppDbContext context;
        private readonly ILogger<VATController> _logger;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public VATController(IVATRepository vatRepository, AppDbContext context, ILogger<VATController> logger, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor)
        {
            _vatRepository = vatRepository;
            this.context = context;
            _auditTrailService = auditTrailService;
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [Route("GetVAT")]
        public async Task<ActionResult<IEnumerable<VAT>>> GetVAT()
        {
            try
            {
                var results = await _vatRepository.GetVAT();
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "View",
                    EntityId = 0,
                   UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    Description = "Viewed VAT details"

                });

                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpPut]
        [Route("UpdateVAT")]
        public async Task<IActionResult> UpdateVATAsync(int id, [FromBody] VATViewModel vatViewModel)
        {
            try
            {
                var vat = new VAT
                {
                    VATId = id,  // Ensure the ProductId is set
                    Amount = vatViewModel.amount,
                    Date = DateTime.Now
                };

                var updatedVAT = await _vatRepository.UpdateVATAsync(vat);

                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "Update",
                    EntityId = id,
                   UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    OldValue = "Old value details here", // Set this to actual old value if available
                    NewValue = $"{vatViewModel.amount}", // Include the new value
                    Description = $"Updated VAT with ID {id}"
                });

                return Ok(updatedVAT);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the VATS with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }


    }

}