﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SupplierCRUD.Models;
using SupplierCRUD.ViewModels;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BrandController : ControllerBase
    {
        private readonly IBrandRepository _brandRepository;
        private readonly AppDbContext context;
        private readonly ILogger<BrandController> _logger;

        public BrandController(IBrandRepository brandRepository, AppDbContext context, ILogger<BrandController> logger)
        {
            _brandRepository = brandRepository;
            this.context = context;
        }

        [HttpGet]
        [Route("GetBrands")]
        public async Task<ActionResult<IEnumerable<Brand>>> GetBrands()
        {
            try
            {
                var results = await _brandRepository.GetAllBrands();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetBrandById/{BrandId}")]
        [ProducesResponseType(200, Type = typeof(Brand))]
        [ProducesResponseType(400)]
        public IActionResult GetBrand(int brandId)
        {
            if (!_brandRepository.BrandAvailable(brandId))
                return NotFound();

            var brand = _brandRepository.GetBrand(brandId);

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            return Ok(brand);
        }

        [HttpPost]
        [Route("AddBrand")]
        public async Task<IActionResult> AddBrand(BrandViewModel brandViewModel)
        {
            var brand = new Brand
            {
                Name = brandViewModel.name,
                Description = brandViewModel.description,
                CategoryId = brandViewModel.CategoryId
            };

            var addedBrand = await _brandRepository.CreateBrandAsync(brand);
            return Ok(addedBrand);
        }

        [HttpPut]
        [Route("UpdateBrand")]
        public async Task<IActionResult> UpdateBrandAsync(int id, [FromBody] BrandViewModel brandViewModel)
        {
            try
            {
                var brand = new Brand
                {
                    BrandId = id,  // Ensure the ProductId is set
                    Name = brandViewModel.name,
                    Description = brandViewModel.description,
                };

                var updatedBrand = await _brandRepository.UpdateBrandAsync(brand);

                return Ok(updatedBrand);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the brand with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete]
        [Route("DeleteBrand/{BrandId}")]
        public async Task<IActionResult> DeleteBrandAsync(int id)
        {
            try
            {
                await _brandRepository.DeleteBrandAsync(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the brand with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}