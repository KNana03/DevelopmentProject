﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SupplierCRUD.Models;
using SupplierCRUD.Repositories;
using SupplierCRUD.Services;
using SupplierCRUD.ViewModels;
using System;
using System.Threading.Tasks;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShiftController : ControllerBase
    {
        private readonly IShiftRepository _shiftRepository;
        private readonly AppDbContext _context;
        private readonly ILogger<ShiftController> _logger;
        private readonly IShiftService _shiftService;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor httpContextAccessor;
        public ShiftController(AppDbContext context, IShiftRepository shiftRepository, ILogger<ShiftController> logger, IShiftService shiftService, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _shiftRepository = shiftRepository;
            _shiftService = shiftService;
            _auditTrailService = auditTrailService;
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        public async Task<IActionResult> GetShifts()
        {
            return Ok(await _context.Shifts
                .Include(s => s.ShiftType) // Include related ShiftType data
                .ToListAsync());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetShift(int id)
        {
            var shift = await _context.Shifts
                .Include(s => s.ShiftType) // Include related ShiftType data
                .FirstOrDefaultAsync(s => s.Id == id);

            if (shift == null) return NotFound();

            // Log the view event
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "View Shift",
                EntityId = id,
                UserId = User.Identity.Name,
                Description = $"Shift {shift.Name} viewed."
            });


            return Ok(shift);
        }

        [HttpPost]
        public async Task<IActionResult> CreateShift([FromBody] ShiftViewModel shiftViewModel)
        {
            if (shiftViewModel == null)
            {
                return BadRequest("ShiftViewModel cannot be null.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                // Convert ViewModel to Entity if necessary, assuming your _shiftService handles this
                var shift = await _shiftService.AddShiftAsync(shiftViewModel);

                // Log the creation event
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "Create Shift",
                    EntityId = shift.Id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    NewValue = JsonConvert.SerializeObject(shift), // Serialize the shift object
                    Description = $"Shift {shift.Name} created."
                });

                // Return the created shift with the correct route
                return CreatedAtAction(nameof(CreateShift), new { id = shift.Id }, shift);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while creating the shift.");
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the shift. Please try again later.");
            }
        }


        private async Task<IActionResult> GetShiftByIdAsync(int id)
        {
            var shift = await _context.Shifts
        .Include(s => s.ShiftType)
        .FirstOrDefaultAsync(s => s.Id == id);

            if (shift == null) return NotFound();
            return Ok(shift);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateShift(int id, [FromBody] Shift shift)
        {
            if (id != shift.Id)
            {
                return BadRequest("The shift ID in the URL does not match the shift ID in the body.");
            }

            try
            {
                var existingShift = await _shiftService.GetShiftByIdAsync(id);
                if (existingShift == null)
                {
                    return NotFound($"Shift with ID {id} not found.");
                }

                var oldValue = JsonConvert.SerializeObject(existingShift);

                // Update the shift in the context
                _context.Entry(shift).State = EntityState.Modified;
                await _context.SaveChangesAsync();

                // Log the update event in the audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "Update Shift",
                    EntityId = shift.Id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    OldValue = oldValue,
                    NewValue = JsonConvert.SerializeObject(shift),
                    Description = $"Shift {shift.Name} updated."
                });

                return NoContent();
            }
            catch (DbUpdateException dbEx)
            {
                _logger.LogError(dbEx, "A database error occurred while updating the shift with ID {ShiftId}", id);
                return StatusCode(StatusCodes.Status500InternalServerError, "A database error occurred while updating the shift. Please try again later.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while updating the shift with ID {ShiftId}", id);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while updating the shift. Please try again later.");
            }
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteShift(int id)
        {
            var shift = await _context.Shifts.FindAsync(id);
            if (shift == null) return NotFound();

            _context.Shifts.Remove(shift);
            await _context.SaveChangesAsync();
            // Log the deletion event
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "Delete Shift",
                EntityId = id,
                UserId = User.Identity.Name,
                OldValue = shift.ToString(),
                Description = $"Shift {shift.Name} deleted."
            });

            return NoContent();
        }


        [HttpGet("shifts")]
        public async Task<IActionResult> GetShiftsByDateRange(DateTime startDate, DateTime endDate)
        {
            try
            {
                var shifts = await _shiftService.GetShiftsByDateRange(startDate, endDate);
                return Ok(shifts);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpGet("shifts/{date}")]
        public async Task<IActionResult> GetShiftsByDate(DateTime date)
        {
            try
            {
                var shifts = await _shiftService.GetShiftsByDate(date);
                return Ok(shifts);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }



        [HttpGet("report")]
        public async Task<IActionResult> GetShiftReport()
        {
            var shifts = await _context.Shifts
                .Include(s => s.ShiftType)
                .ToListAsync();

            var reportData = shifts.Select(shift => new
            {
                shift.Id,
                shift.Name,
                StartTime = shift.StartTime.ToString("HH:mm:ss"),
                EndTime = shift.EndTime.ToString("HH:mm:ss"),
                Date = shift.Date.ToString("yyyy-MM-dd"),
                CheckInTime = shift.CheckInTime.HasValue ? shift.CheckInTime.Value.ToString("HH:mm:ss") : "N/A",
                CheckOutTime = shift.CheckOutTime.HasValue ? shift.CheckOutTime.Value.ToString("HH:mm:ss") : "N/A",
                ShiftType = new
                {
                    shift.ShiftType.Name,
                    shift.ShiftType.Description
                }
            });

            return Ok(reportData);
        }

    }
}
