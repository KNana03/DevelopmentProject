﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SupplierCRUD.Models;
using SupplierCRUD.ViewModels;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {

        private readonly ICategoryRepository _categoryRepository;
        private readonly AppDbContext context;
        private readonly ILogger<ProductController> _logger;

        public CategoryController(ICategoryRepository categoryRepository, AppDbContext context, ILogger<CategoryController> logger)
        {
            _categoryRepository = categoryRepository;
            this.context = context;
        }

        [HttpGet]
        [Route("GetCategories")]
        public async Task<ActionResult<IEnumerable<Category>>> GetCategories()
        {
            try
            {
                var results = await _categoryRepository.GetAllCategories();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetCategoryById/{CategoryId}")]
        [ProducesResponseType(200, Type = typeof(Category))]
        [ProducesResponseType(400)]
        public IActionResult GetCategory(int catId)
        {
            if (!_categoryRepository.CategoryAvailable(catId))
                return NotFound();

            var category = _categoryRepository.GetCategory(catId);

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            return Ok(category);
        }

        [HttpPost]
        [Route("AddCategory")]
        public async Task<IActionResult> AddCategory(CategoryViewModel categoryViewModel)
        {
            var category = new Category
            {
                Name = categoryViewModel.name,
                Description = categoryViewModel.description
            };

            var addedProduct = await _categoryRepository.CreateCategoryAsync(category);
            return Ok(addedProduct);
        }

        [HttpPut]
        [Route("UpdateCategory")]
        public async Task<IActionResult> UpdateCategoryAsync(int id, [FromBody] CategoryViewModel categoryViewModel)
        {
            try
            {
                var category = new Category
                {
                    CategoryId = id,  // Ensure the ProductId is set
                    Name = categoryViewModel.name,
                    Description = categoryViewModel.description,
                };

                var updatedCategory = await _categoryRepository.UpdateCategoryAsync(category);

                return Ok(updatedCategory);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the category with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete]
        [Route("DeleteCategory/{CategoryId}")]
        public async Task<IActionResult> DeleteCategoryAsync(int id)
        {
            try
            {
                await _categoryRepository.DeleteCategoryAsync(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the product with id {id}.");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}