﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using SupplierCRUD.Models;
using SupplierCRUD.Services;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InventoryController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public InventoryController(AppDbContext context, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            TwilioClient.Init("AC4956d0b02f05fdd0aa7455821bf4e83c", "f581af282f3c22ab3f2d6f71dfdde9f9");
            _auditTrailService = auditTrailService;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpPost]
        [Route("addInventory")]
        public async Task<ActionResult<Inventory>> CreateInventory([FromBody] Inventory inventory)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors.Select(e => e.ErrorMessage));
                return BadRequest(new { Message = "Model state is invalid", Errors = errors });
            }

            // Ensure the inventory being created is only for non-sellable items
            inventory.TypeId = 1; // Assuming 1 represents Non-Sellable Items
            inventory.InventoryType = "Non-Sellable"; // Ensure inventory type is set correctly
            inventory.ProductId = GenerateUniqueProductId(); // Automatically assign a ProductId

            _context.Inventories.Add(inventory);
            await _context.SaveChangesAsync();

            // Create the audit trail entry
            var auditTrail = new AuditTrail
            {
                Event = "CreateInventory",
                EntityId = inventory.Id,
                UserId = User.Identity?.Name ?? "Anonymous",
                Description = $"New inventory item {inventory.Name} was created with quantity {inventory.Quantity}.",
                NewValue = JsonConvert.SerializeObject(inventory),
            };
            await _auditTrailService.LogEventAsync(auditTrail);

            if (inventory.Quantity < 50)
            {
                SendLowStockSms(inventory);
            }

            return CreatedAtAction(nameof(GetInventory), new { id = inventory.Id }, inventory);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateInventory(int id, [FromBody] Inventory inventory)
        {
            if (id != inventory.Id)
            {
                return BadRequest();
            }

            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors.Select(e => e.ErrorMessage));
                return BadRequest(new { Message = "Model state is invalid", Errors = errors });
            }

            var existingInventory = await _context.Inventories.FindAsync(id);
            if (existingInventory == null)
            {
                return NotFound();
            }

            // Detach the existing entity to avoid tracking conflict
            if (existingInventory != null)
            {
                _context.Entry(existingInventory).State = EntityState.Detached;
            }

            var oldValue = JsonConvert.SerializeObject(existingInventory);
            _context.Entry(inventory).State = EntityState.Modified;

            try
            {
                // Create the audit trail entry
                var auditTrail = new AuditTrail
                {
                    Event = "UpdateInventory",
                    EntityId = inventory.Id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Description = $"Inventory item {inventory.Name} was updated.",
                    OldValue = oldValue,
                    NewValue = JsonConvert.SerializeObject(inventory),
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                await _context.SaveChangesAsync();

                if (inventory.Quantity < 50)
                {
                    SendLowStockSms(inventory);
                }
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!InventoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteInventory(int id)
        {
            var inventory = await _context.Inventories.FindAsync(id);
            if (inventory == null)
            {
                return NotFound();
            }

            _context.Inventories.Remove(inventory);
            await _context.SaveChangesAsync();

            // Create the audit trail entry
            var auditTrail = new AuditTrail
            {
                Event = "DeleteInventory",
                EntityId = inventory.Id,
                UserId = User.Identity?.Name ?? "Anonymous",
                Description = $"Inventory item {inventory.Name} was deleted.",
                OldValue = JsonConvert.SerializeObject(inventory),
            };
            await _auditTrailService.LogEventAsync(auditTrail);

            return NoContent();
        }

        [HttpPost("return")]
        public async Task<ActionResult> ReturnInventory(int id, int quantity)
        {
            var inventory = await _context.Inventories.FindAsync(id);
            if (inventory == null)
            {
                return NotFound();
            }

            var oldValue = JsonConvert.SerializeObject(inventory);

            inventory.Quantity += quantity;
            await _context.SaveChangesAsync();

            // Create the audit trail entry
            var auditTrail = new AuditTrail
            {
                Event = "ReturnInventory",
                EntityId = inventory.Id,
                UserId = User.Identity?.Name ?? "Anonymous",
                Description = $"{quantity} units were returned to inventory item {inventory.Name}.",
                OldValue = oldValue,
                NewValue = JsonConvert.SerializeObject(inventory),
            };
            await _auditTrailService.LogEventAsync(auditTrail);

            return NoContent();
        }

        private int GenerateUniqueProductId()
        {
            // Example logic to generate a unique Product ID
            var lastInventory = _context.Inventories.OrderByDescending(i => i.ProductId).FirstOrDefault();
            return lastInventory != null ? lastInventory.ProductId + 1 : 1;
        }

        private void SendLowStockSms(Inventory inventory)
        {
            var message = MessageResource.Create(
                body: $"Warning: The stock for {inventory.Name} is low. Current quantity: {inventory.Quantity}.",
                from: new Twilio.Types.PhoneNumber("+14787394227"),
                to: new Twilio.Types.PhoneNumber("+27729652274")
            );
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Inventory>>> GetInventories()
        {
            var result = await _context.Inventories
                .FromSqlRaw("EXEC GetAllInventories")
                .ToListAsync();

            return Ok(result);
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<Inventory>> GetInventory(int id)
        {
            var inventory = await _context.Inventories.FindAsync(id);

            if (inventory == null)
            {
                return NotFound();
            }

            return inventory;
        }

        [HttpGet("inventory-report")]
        public async Task<IActionResult> GetInventoryReport()
        {
            var report = await (from inventory in _context.Inventories
                                join product in _context.Products
                                on inventory.ProductId equals product.ProductId into productGroup // Grouping for left join
                                from product in productGroup.DefaultIfEmpty() // Perform left join
                                select new
                                {
                                    InventoryId = inventory.Id,
                                    inventory.Name,
                                    inventory.ProductId,
                                    inventory.WarehouseId,
                                    inventory.TypeId,
                                    inventory.Quantity,
                                    inventory.InventoryType,
                                    ProductName = product != null ? product.Name : "N/A", // Handle null case
                                    ProductDescription = product != null ? product.Description : "N/A", // Handle null case
                                    WriteOffReasons = _context.InventoryWriteOffs
                                        .Where(iw => iw.InventoryId == inventory.Id)
                                        .Select(iw => iw.WriteOffReason.Reason)
                                        .ToList()
                                }).ToListAsync();

            var mostStockedItem = report
                .OrderByDescending(i => i.Quantity)
                .FirstOrDefault();

            var result = new
            {
                MostStockedItem = mostStockedItem?.ProductName ?? "N/A",
                Inventories = report
            };

            return Ok(result);
        }


        [HttpGet("inventory-turnover-report")]
        public async Task<IActionResult> GetInventoryTurnoverReport()
        {
            var inventories = await _context.Inventories
                .Where(i => i.InventoryType == "Sellable") // Only include sellable items
                .ToListAsync();

            var sales = await _context.Sales.ToListAsync();

            var turnoverData = sales
                .GroupBy(s => s.InventoryId)
                .Select(g =>
                {
                    var inventory = inventories.FirstOrDefault(i => i.Id == g.Key);
                    var totalSalesQuantity = g.Sum(s => s.Quantity);
                    var averageInventory = inventory != null ? inventory.Quantity : 0;
                    var turnoverRatio = averageInventory > 0 ? (double)totalSalesQuantity / averageInventory : 0;

                    return new
                    {
                        InventoryId = inventory?.Id ?? 0,
                        InventoryName = inventory?.Name ?? "Unknown",
                        TotalSales = totalSalesQuantity,
                        AverageInventory = averageInventory,
                        TurnoverRatio = turnoverRatio
                    };
                })
                .Where(t => t.InventoryId != 0 && t.TotalSales > 0) // Ensure valid inventories with sales
                .ToList();

            // Define dummy data with the same anonymous type
            var dummyData = new[]
            {
                new { InventoryId = 101, InventoryName = "Dummy Product A", TotalSales = 80, AverageInventory = 40, TurnoverRatio = 2.0 },
                new { InventoryId = 102, InventoryName = "Dummy Product B", TotalSales = 120, AverageInventory = 60, TurnoverRatio = 2.0 }
            };

            // Combine database and dummy data
            turnoverData.AddRange(dummyData);

            return Ok(turnoverData);
        }

        [HttpPost]
        [Route("importInventory")]
        public async Task<ActionResult> ImportInventory([FromBody] List<Inventory> inventories)
        {
            if (inventories == null || !inventories.Any())
            {
                return BadRequest(new { Message = "No inventories provided for import." });
            }

            var errors = new List<string>();
            var successfullyImported = new List<Inventory>();

            using (var transaction = await _context.Database.BeginTransactionAsync())
            {
                foreach (var inventory in inventories)
                {
                    if (!TryValidateModel(inventory))
                    {
                        var inventoryErrors = ModelState.Values
                            .SelectMany(v => v.Errors.Select(e => e.ErrorMessage))
                            .ToList();
                        errors.AddRange(inventoryErrors);
                        ModelState.Clear(); // Clear model state for the next item
                        continue;
                    }

                    // Set default values for inventory if necessary
                    inventory.TypeId = inventory.TypeId == 0 ? 1 : inventory.TypeId; // Assuming 1 represents Non-Sellable Items
                    inventory.ProductId = GenerateUniqueProductId(); // Automatically assign a unique ProductId
                    inventory.InventoryType = inventory.InventoryType ?? "Non-Sellable";

                    try
                    {
                        _context.Inventories.Add(inventory);
                        await _context.SaveChangesAsync();

                        // Log successful imports
                        successfullyImported.Add(inventory);

                        // Create the audit trail entry for the import
                        var auditTrail = new AuditTrail
                        {
                            Event = "ImportInventory",
                            EntityId = inventory.Id,
                            UserId = User.Identity?.Name ?? "Anonymous",
                            Description = $"Inventory item {inventory.Name} was imported with quantity {inventory.Quantity}.",
                            NewValue = JsonConvert.SerializeObject(inventory),
                        };
                        await _auditTrailService.LogEventAsync(auditTrail);

                        // Check for low stock and send notification
                        if (inventory.Quantity < 50)
                        {
                            SendLowStockSms(inventory);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Log any exceptions related to the database operation
                        errors.Add($"Error importing inventory item {inventory.Name}: {ex.Message}");
                    }
                }

                if (successfullyImported.Count > 0)
                {
                    await transaction.CommitAsync();
                }
                else
                {
                    await transaction.RollbackAsync();
                    return BadRequest(new { Message = "No inventory items were successfully imported.", Errors = errors });
                }
            }

            if (errors.Any())
            {
                return Ok(new
                {
                    Message = $"{successfullyImported.Count} inventory items imported successfully.",
                    Errors = errors
                });
            }

            return Ok(new { Message = "All inventory items imported successfully." });
        }


        private bool InventoryExists(int id)
        {
            return _context.Inventories.Any(e => e.Id == id);
        }
    }
}
