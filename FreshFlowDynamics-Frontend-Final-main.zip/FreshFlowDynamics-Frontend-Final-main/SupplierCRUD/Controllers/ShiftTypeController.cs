﻿using SupplierCRUD.Models;
using SupplierCRUD.Repositories;
using SupplierCRUD.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShiftTypeController : ControllerBase
    {


        // private readonly IShiftTypeService _shiftTypeService;
        private readonly IShiftTypeRepository _shiftTypeRepository;
        private readonly ILogger<ShiftTypeController> _logger;
        private readonly AppDbContext _context;
        private readonly IAuditTrailService _auditTrailService;
        private readonly IHttpContextAccessor httpContextAccessor;

        public ShiftTypeController(IShiftTypeRepository shiftTypeRepository, ILogger<ShiftTypeController> logger, AppDbContext context, IAuditTrailService auditTrailService, IHttpContextAccessor httpContextAccessor)
        {
            _shiftTypeRepository = shiftTypeRepository;
            _logger = logger;
            _context = context;
            _auditTrailService = auditTrailService;
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        public async Task<IActionResult> GetShiftTypes()
        {
            return Ok(await _context.ShiftTypes.ToListAsync());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetShiftType(int id)
        {
            var shiftType = await _context.ShiftTypes.FindAsync(id);
            if (shiftType == null) return NotFound();
            return Ok(shiftType);
        }

        [HttpPost]
        public async Task<IActionResult> CreateShiftType([FromBody] ShiftType shiftType)
        {
            if (shiftType == null)
            {
                return BadRequest("ShiftType cannot be null.");
            }

            try
            {
                // Add the shift type to the context and save changes
                _context.ShiftTypes.Add(shiftType);
                await _context.SaveChangesAsync();

                // Log audit trail
                await _auditTrailService.LogEventAsync(new AuditTrail
                {
                    Event = "Create",
                    EntityId = shiftType.Id,
                    UserId = User.Identity?.Name ?? "Anonymous",
                    Timestamp = DateTime.UtcNow,
                    OldValue = string.Empty, // No previous value since this is a creation
                    NewValue = JsonConvert.SerializeObject(shiftType),
                    Description = $"Created new shift type {shiftType.Name}"
                });

                // Return the created shift type with the correct route
                return CreatedAtAction(nameof(GetShiftType), new { id = shiftType.Id }, shiftType);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while creating the shift type.");
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while creating the shift type. Please try again later.");
            }
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateShiftType(int id, [FromBody] ShiftType shiftType)
        {
            if (id != shiftType.Id) return BadRequest();

            var oldShiftType = await _context.ShiftTypes.AsNoTracking().FirstOrDefaultAsync(st => st.Id == id);
            if (oldShiftType == null) return NotFound();

            _context.Entry(shiftType).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            // Log audit trail
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "Update",
                EntityId = id,
                UserId = User.Identity.Name,
                Timestamp = DateTime.UtcNow,
                OldValue = JsonConvert.SerializeObject(oldShiftType),
                NewValue = JsonConvert.SerializeObject(shiftType),
                Description = $"Updated shift type with ID {id}"
            });


            return NoContent();



        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteShiftType(int id)
        {
            var shiftType = await _context.ShiftTypes.FindAsync(id);
            if (shiftType == null) return NotFound();
            _context.ShiftTypes.Remove(shiftType);
            await _context.SaveChangesAsync();

            // Log audit trail
            await _auditTrailService.LogEventAsync(new AuditTrail
            {
                Event = "Delete",
                EntityId = id,
                UserId = User.Identity.Name,
                Timestamp = DateTime.UtcNow,
                OldValue = JsonConvert.SerializeObject(shiftType),
                Description = $"Deleted shift type with ID {id}"
            });

            return NoContent();
        }

    }
}




