﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SupplierCRUD.Models;
using SupplierCRUD.Repositories;
using SupplierCRUD.ViewModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SupplierCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        private readonly ICountryRepository _countryRepository;
        private readonly ILogger<CountryController> _logger;

        public CountryController(ICountryRepository countryRepository, ILogger<CountryController> logger)
        {
            _countryRepository = countryRepository;
            _logger = logger;
        }

        // Country Endpoints
        [HttpGet]
        [Route("GetCountries")]
        public async Task<ActionResult<IEnumerable<Country>>> GetCountries()
        {
            try
            {
                var results = await _countryRepository.GetAllCountries();
                return Ok(results);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching countries.");
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetCountryById/{countryId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Country))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult GetCountry(int countryId)
        {
            try
            {
                if (!_countryRepository.CountryAvailable(countryId))
                    return NotFound();

                var country = _countryRepository.GetCountry(countryId);

                if (country == null)
                    return NotFound();

                return Ok(country);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while fetching the country with id {countryId}.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }

        // Add Country Endpoint
        [HttpPost]
        [Route("AddCountry")]
        public async Task<IActionResult> AddCountry([FromBody] CountryViewModel countryViewModel)
        {
            try
            {
                var country = new Country
                {
                    Name = countryViewModel.name
                };

                var addedCountry = await _countryRepository.CreateCountryAsync(country);
                return CreatedAtAction(nameof(GetCountry), new { countryId = addedCountry.CountryId }, addedCountry);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding the country.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error");
            }
        }

        // Update Country Endpoint
        [HttpPut]
        [Route("UpdateCountry/{id}")]
        public async Task<IActionResult> UpdateCountryAsync(int id, [FromBody] CountryViewModel countryViewModel)
        {
            try
            {
                var country = new Country
                {
                    CountryId = id,
                    Name = countryViewModel.name
                };

                var updatedCountry = await _countryRepository.UpdateCountryAsync(country);

                if (updatedCountry == null)
                    return NotFound();

                return Ok(updatedCountry);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the country with id {id}.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error");
            }
        }

        // Delete Country Endpoint
        [HttpDelete]
        [Route("DeleteCountry/{id}")]
        public async Task<IActionResult> DeleteCountryAsync(int id)
        {
            try
            {
                if (!_countryRepository.CountryAvailable(id))
                    return NotFound();

                await _countryRepository.DeleteCountryAsync(id);
                return NoContent();
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the country with id {id}.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error");
            }
        }

        // State Endpoints
        [HttpGet]
        [Route("GetStates")]
        public async Task<ActionResult<IEnumerable<State>>> GetStates()
        {
            try
            {
                var results = await _countryRepository.GetAllStatesAsync();
                return Ok(results);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching states.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetStatesByCountryId/{countryId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<State>))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetStatesByCountryId(int countryId)
        {
            try
            {
                if (!_countryRepository.CountryAvailable(countryId))
                    return NotFound();

                var states = await _countryRepository.GetAllStatesAsync();
                var filteredStates = states.Where(s => s.CountryId == countryId);

                return Ok(filteredStates);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while fetching the states for country id {countryId}.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetStateById/{stateId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(State))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetState(int stateId)
        {
            try
            {
                if (!_countryRepository.StateAvailable(stateId))
                    return NotFound();

                var state = await _countryRepository.GetStateAsync(stateId);

                if (state == null)
                    return NotFound();

                return Ok(state);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while fetching the state with id {stateId}.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }

        // Add State Endpoint
        [HttpPost]
        [Route("AddState")]
        public async Task<IActionResult> AddState([FromBody] StateViewModel stateViewModel)
        {
            try
            {
                var state = new State
                {
                    Name = stateViewModel.name,
                    CountryId = stateViewModel.countryId
                };

                var addedState = await _countryRepository.CreateStateAsync(state);
                return CreatedAtAction(nameof(GetState), new { stateId = addedState.StateId }, addedState);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding the state.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error");
            }
        }

        // Update State Endpoint
        [HttpPut]
        [Route("UpdateState/{id}")]
        public async Task<IActionResult> UpdateStateAsync(int id, [FromBody] StateViewModel stateViewModel)
        {
            try
            {
                var state = new State
                {
                    StateId = id,
                    Name = stateViewModel.name,
                    CountryId = stateViewModel.countryId
                };

                var updatedState = await _countryRepository.UpdateStateAsync(state);

                if (updatedState == null)
                    return NotFound();

                return Ok(updatedState);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the state with id {id}.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error");
            }
        }

        // Delete State Endpoint
        [HttpDelete]
        [Route("DeleteState/{id}")]
        public async Task<IActionResult> DeleteStateAsync(int id)
        {
            try
            {
                if (!_countryRepository.StateAvailable(id))
                    return NotFound();

                await _countryRepository.DeleteStateAsync(id);
                return NoContent();
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the state with id {id}.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error");
            }
        }

        // City Endpoints
        [HttpGet]
        [Route("GetCities")]
        public async Task<ActionResult<IEnumerable<City>>> GetCities()
        {
            try
            {
                var results = await _countryRepository.GetAllCitiesAsync();
                return Ok(results);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching cities.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetCitiesByStateId/{stateId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<City>))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetCitiesByStateId(int stateId)
        {
            try
            {
                if (!_countryRepository.StateAvailable(stateId))
                    return NotFound();

                var cities = await _countryRepository.GetAllCitiesAsync();
                var filteredCities = cities.Where(c => c.StateId == stateId);

                return Ok(filteredCities);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while fetching the cities for state id {stateId}.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetCityById/{cityId}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(City))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetCity(int cityId)
        {
            try
            {
                if (!_countryRepository.CityAvailable(cityId))
                    return NotFound();

                var city = await _countryRepository.GetCityAsync(cityId);

                if (city == null)
                    return NotFound();

                return Ok(city);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while fetching the city with id {cityId}.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }

        // Add City Endpoint
        [HttpPost]
        [Route("AddCity")]
        public async Task<IActionResult> AddCity([FromBody] CityViewModel cityViewModel)
        {
            try
            {
                var city = new City
                {
                    Name = cityViewModel.name,
                    CountryId = cityViewModel.countryId,
                    StateId = cityViewModel.stateId
                };

                var addedCity = await _countryRepository.CreateCityAsync(city);
                return CreatedAtAction(nameof(GetCity), new { cityId = addedCity.CityId }, addedCity);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding the city.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error");
            }
        }

        // Update City Endpoint
        [HttpPut]
        [Route("UpdateCity/{id}")]
        public async Task<IActionResult> UpdateCityAsync(int id, [FromBody] CityViewModel cityViewModel)
        {
            try
            {
                var city = new City
                {
                    CityId = id,
                    Name = cityViewModel.name,
                    CountryId = cityViewModel.countryId,
                    StateId = cityViewModel.stateId
                };

                var updatedCity = await _countryRepository.UpdateCityAsync(city);

                if (updatedCity == null)
                    return NotFound();

                return Ok(updatedCity);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while updating the city with id {id}.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error");
            }
        }

        // Delete City Endpoint
        [HttpDelete]
        [Route("DeleteCity/{id}")]
        public async Task<IActionResult> DeleteCityAsync(int id)
        {
            try
            {
                if (!_countryRepository.CityAvailable(id))
                    return NotFound();

                await _countryRepository.DeleteCityAsync(id);
                return NoContent();
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the city with id {id}.");
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error");
            }
        }
    }
}
