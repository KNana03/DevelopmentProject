﻿using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using SupplierCRUD.Models;

namespace SupplierCRUD.Services
{
    public class EmailService : IEmailService
    {
        private readonly EmailConfiguration _emailConfig;

        public EmailService(EmailConfiguration emailConfig)
        {
            _emailConfig = emailConfig;
        }

        public void SendEmail(Message message)
        {
            var emailMessage = CreateEmailMessage(message);
            Send(emailMessage);
        }

        private MimeMessage CreateEmailMessage(Message message)
        {
            var emailMessage = new MimeMessage();
            emailMessage.From.Add(new MailboxAddress("email", _emailConfig.From));
            emailMessage.To.AddRange(message.To);
            emailMessage.Subject = message.Subject;
            emailMessage.Body = new TextPart(MimeKit.Text.TextFormat.Text) { Text = message.Content };
            return emailMessage;
        }

        private void Send(MimeMessage mailMessage)
        {
            using var client = new SmtpClient();
            try
            {
                // Ensure the server certificate validation callback is set properly
                client.ServerCertificateValidationCallback = (s, c, h, e) => true; // Bypass SSL certificate validation for development

                // Connect to the SMTP server
                client.Connect(_emailConfig.SmtpServer, _emailConfig.Port, SecureSocketOptions.StartTls);

                // Remove XOAUTH2 authentication mechanism
                client.AuthenticationMechanisms.Remove("XOAUTH2");

                // Authenticate with the SMTP server
                client.Authenticate(_emailConfig.Username, _emailConfig.Password);

                // Send the email message
                client.Send(mailMessage);
            }
            catch (Exception ex)
            {
                // Return a detailed error message
                throw new Exception($"An error occurred while sending the email: {ex.Message}");
            }
            finally
            {
                // Disconnect and dispose of the SMTP client
                client.Disconnect(true);
                client.Dispose();
            }
        }
    }
}
