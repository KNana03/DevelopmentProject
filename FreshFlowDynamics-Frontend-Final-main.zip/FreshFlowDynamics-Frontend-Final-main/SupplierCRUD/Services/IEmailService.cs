﻿using SupplierCRUD.Models;

namespace SupplierCRUD.Services
{
    public interface IEmailService
    {
        
        void SendEmail(Message message);
    }
}
