﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace SupplierCRUD.Services
{
    public interface IStaffAttendanceService
    {
        Task<IActionResult> CheckInAsync(int staffId, int shiftAssignmentId);
        Task<IActionResult> CheckOutAsync(int staffId, int shiftAssignmentId);
    }
}
