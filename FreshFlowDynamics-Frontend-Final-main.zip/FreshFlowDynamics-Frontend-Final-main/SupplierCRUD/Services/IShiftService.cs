﻿using SupplierCRUD.Models;
using SupplierCRUD.ViewModels;

namespace SupplierCRUD.Services
{
    public interface IShiftService
    {
        Task<Shift> GetShiftByIdAsync(int id);
        Task<List<Shift>> GetAllShiftsAsync();
        Task CreateShiftAsync(Shift shift); // Adjusted to return Task
        Task UpdateShiftAsync(Shift shift);
        Task DeleteShiftAsync(int id);

        Task<Shift> AddShiftAsync(ShiftViewModel shiftViewModel);

        Task<IEnumerable<Shift>> GetShiftsByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<IEnumerable<Shift>> GetShiftsByDateRange(DateTime startDate, DateTime endDate);
        Task<IEnumerable<Shift>> GetShiftsByDate(DateTime date);  // Add this method
    }
}
