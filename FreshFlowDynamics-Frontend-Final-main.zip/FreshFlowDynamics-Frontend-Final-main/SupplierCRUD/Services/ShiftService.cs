﻿using Microsoft.EntityFrameworkCore;
using SupplierCRUD.Models;
using SupplierCRUD.Repositories;
using SupplierCRUD.ViewModels;

namespace SupplierCRUD.Services
{
    public class ShiftService : IShiftService
    {
        private readonly IShiftRepository _shiftRepository;
        private readonly AppDbContext _context;

        public ShiftService(IShiftRepository shiftRepository, AppDbContext context)
        {
            _shiftRepository = shiftRepository;
            _context = context;
        }
        public async Task<Shift> GetShiftByIdAsync(int id)
        {
            return await _context.Shifts
                        .Include(s => s.ShiftType)
                        .FirstOrDefaultAsync(s => s.Id == id);
            // return await _shiftRepository.GetShiftByIdAsync(id);
        }

        public async Task<List<Shift>> GetAllShiftsAsync()
        {
            return await _shiftRepository.GetAllShiftsAsync();
        }

        public async Task CreateShiftAsync(Shift shift)
        {
            _context.Shifts.Add(shift);

            await _context.SaveChangesAsync();
            // await _shiftRepository.AddShiftAsync(shift);
            // await _shiftRepository.SaveChangesAsync();
        }

        public async Task UpdateShiftAsync(Shift shift)
        {
            await _shiftRepository.UpdateShiftAsync(shift);
            await _shiftRepository.SaveChangesAsync();
        }

        public async Task DeleteShiftAsync(int id)
        {
            await _shiftRepository.DeleteShiftAsync(id);
            await _shiftRepository.SaveChangesAsync();
        }

        public async Task<Shift> AddShiftAsync(ShiftViewModel shiftViewModel)
        {
            // Map the ViewModel to the entity
            var shift = new Shift
            {
                Name = shiftViewModel.Name,

                ShiftTypeId = shiftViewModel.ShiftTypeId,
                StartTime = shiftViewModel.StartTime,
                EndTime = shiftViewModel.EndTime,
                CheckInTime = shiftViewModel.CheckInTime,
                CheckOutTime = shiftViewModel.CheckOutTime,
                Date = shiftViewModel.Date
            };

            // Check if the ShiftType already exists
            var existingShiftType = await _context.ShiftTypes.FindAsync(shiftViewModel.ShiftTypeId);

            if (existingShiftType != null)
            {
                // Attach the existing ShiftType entity to the context
                _context.Entry(existingShiftType).State = EntityState.Unchanged;
                shift.ShiftType = existingShiftType;
            }
            else if (!string.IsNullOrEmpty(shiftViewModel.TypeName))
            {
                // Add the new ShiftType entity if it is provided in the ViewModel
                var newShiftType = new ShiftType
                {
                    Id = shiftViewModel.ShiftTypeId, // This should be provided by the client
                    Name = shiftViewModel.TypeName   // Make sure this field is in the ViewModel
                };

                _context.ShiftTypes.Add(newShiftType);
                shift.ShiftType = newShiftType;
            }

            // Add the Shift entity
            _context.Shifts.Add(shift);
            await _context.SaveChangesAsync();

            return shift;
        }



        public async Task<IEnumerable<Shift>> GetShiftsByDateRangeAsync(DateTime startDate, DateTime endDate)
        {
            return await _context.Shifts
                .Include(s => s.ShiftType)
                .Where(s => s.Date >= startDate && s.Date <= endDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<Shift>> GetShiftsByDate(DateTime date)
        {
            return await _context.Shifts
                .Include(s => s.ShiftType)
                .Where(s => s.Date.Date == date.Date)
                .ToListAsync();
        }

        public async Task<IEnumerable<Shift>> GetShiftsByDateRange(DateTime startDate, DateTime endDate)
        {
            return await _context.Shifts
                .Include(s => s.ShiftType)
                .Where(s => s.Date >= startDate && s.Date <= endDate)
                .ToListAsync();
        }

    
}
}
