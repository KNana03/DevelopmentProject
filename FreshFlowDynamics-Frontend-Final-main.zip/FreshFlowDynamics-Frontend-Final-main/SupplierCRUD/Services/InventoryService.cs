﻿
using SupplierCRUD.Models;
using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Services
{
    public class InventoryService : IInventoryService
    {
        private readonly AppDbContext _context;

        public InventoryService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Inventory> CreateInventoryAsync(Inventory inventory)
        {
            _context.Inventories.Add(inventory);
            await _context.SaveChangesAsync();
            return inventory;
        }

        public async Task<Inventory> UpdateInventoryAsync(int id, Inventory inventory)
        {
            if (id != inventory.Id)
            {
                throw new KeyNotFoundException("Inventory not found");
            }

            var existingInventory = await _context.Inventories.FindAsync(inventory.Id);
            if (existingInventory != null)
            {
                _context.Entry(existingInventory).State = EntityState.Detached;
            }

            _context.Entry(inventory).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return inventory;
        }



        public async Task<IEnumerable<Inventory>> GetInventoriesAsync()
        {
            return await _context.Inventories.ToListAsync();
        }

        public async Task<Inventory> GetInventoryAsync(int id)
        {
            var inventory = await _context.Inventories.FindAsync(id);
            if (inventory == null)
            {
                throw new KeyNotFoundException("Inventory not found");
            }
            return inventory;
        }

        public async Task<bool> DeleteInventoryAsync(int id)
        {
            var inventory = await _context.Inventories.FindAsync(id);
            if (inventory == null)
            {
                return false;
            }

            _context.Inventories.Remove(inventory);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> ReturnInventoryAsync(int id, int quantity)
        {
            var inventory = await _context.Inventories.FindAsync(id);
            if (inventory == null)
            {
                return false;
            }

            inventory.Quantity += quantity;
            await _context.SaveChangesAsync();
            return true;
        }
    }
}