﻿using SupplierCRUD.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SupplierCRUD.Services
{
    public interface IInventoryTypeService
    {
        Task<InventoryType> CreateInventoryTypeAsync(InventoryType inventoryType);
        Task<InventoryType> UpdateInventoryTypeAsync(int id, InventoryType inventoryType);
        Task<IEnumerable<InventoryType>> GetInventoryTypesAsync();
        Task<InventoryType> GetInventoryTypeAsync(int id);
        Task<bool> DeleteInventoryTypeAsync(int id);
    }
}
