﻿using SupplierCRUD.Models;
using SupplierCRUD.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using SupplierCRUD.Models.SupplierCRUD.Models;
using Newtonsoft.Json;

namespace SupplierCRUD.Services
{
    public class StaffAttendanceService : IStaffAttendanceService
    {
        private readonly ILogger<StaffAttendanceService> _logger;
        private readonly IStaffAttendanceRepository _staffAttendanceRepository;
        private readonly IAuditTrailService _auditTrailService;
        private readonly AppDbContext _context;
        private readonly IHttpContextAccessor httpContextAccessor;

        public StaffAttendanceService(
            ILogger<StaffAttendanceService> logger,
            IStaffAttendanceRepository staffAttendanceRepository,
            IAuditTrailService auditTrailService,
            AppDbContext context,
            IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            _staffAttendanceRepository = staffAttendanceRepository;
            _auditTrailService = auditTrailService;
            _context = context;
            this.httpContextAccessor = httpContextAccessor;
        }

        public async Task<IActionResult> CheckInAsync(int staffId, int shiftAssignmentId)
        {
            try
            {
                var attendance = new StaffAttendance
                {
                    StaffId = staffId,
                    ShiftAssignmentId = shiftAssignmentId,
                    CheckInTime = DateTime.UtcNow,
                    IsCheckedIn = true
                };

                var userId = httpContextAccessor.HttpContext?.User?.Identity?.Name; // Get the current user's username
                var staff = await _context.Staffs.FindAsync(staffId);  // Retrieve the staff object from the database
                var ipAddress = httpContextAccessor.HttpContext.Connection.RemoteIpAddress.ToString();  // Get the IP address
                // Log the check-in in the audit trail
                var auditTrail = new AuditTrail
                {
                    Event = "CheckIn",
                    EntityId = staffId,
                    UserId = userId,  // Use the logged-in user's name or ID ,
                    NewValue = JsonConvert.SerializeObject(staff),
                    Description = $"Staff {staffId} checked in.",
                    IPAddress = ipAddress
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                await _staffAttendanceRepository.AddAttendanceAsync(attendance);

                return new OkObjectResult(new { Message = "Check-in successful." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during check-in.");
                return new StatusCodeResult(500);
            }
        }

        public async Task<IActionResult> CheckOutAsync(int staffId, int shiftAssignmentId)
        {
            try
            {
                var attendance = await _staffAttendanceRepository.GetAttendanceByStaffIdAndShiftAssignmentIdAsync(staffId, shiftAssignmentId);
                if (attendance == null || !attendance.IsCheckedIn)
                {
                    return new BadRequestObjectResult("Staff has not checked in.");
                }

                attendance.CheckOutTime = DateTime.UtcNow;
                attendance.IsCheckedOut = true;
                var userId = httpContextAccessor.HttpContext?.User?.Identity?.Name;
                var ipAddress = httpContextAccessor.HttpContext.Connection.RemoteIpAddress.ToString();
                await _staffAttendanceRepository.UpdateAttendanceAsync(attendance);
                var staff = await _context.Staffs.FindAsync(staffId);
                var auditTrail = new AuditTrail
                {
                    Event = "CheckOut",
                    EntityId = staffId,
                    UserId = userId,  // Use the logged-in user's name or ID ,
                    NewValue = JsonConvert.SerializeObject(staff),
                    Description = $"Staff {staffId} checked out.",
                    IPAddress = ipAddress
                };
                await _auditTrailService.LogEventAsync(auditTrail);

                return new OkObjectResult(new { Message = "Check-out successful." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during check-out.");
                return new StatusCodeResult(500);
            }
        }
    }
}
