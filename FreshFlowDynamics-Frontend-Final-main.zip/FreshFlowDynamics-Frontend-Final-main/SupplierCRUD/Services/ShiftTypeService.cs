﻿using SupplierCRUD.Models;
using SupplierCRUD.Repositories;

namespace SupplierCRUD.Services
{
    public class ShiftTypeService : IShiftTypeService
    {
        private readonly IShiftTypeRepository _shiftTypeRepository;

        public ShiftTypeService(IShiftTypeRepository shiftTypeRepository)
        {
            _shiftTypeRepository = shiftTypeRepository;
        }

        public async Task<ShiftType> GetShiftTypeByIdAsync(int id)
        {
            return await _shiftTypeRepository.GetShiftTypeByIdAsync(id);
        }

        public async Task<List<ShiftType>> GetAllShiftTypesAsync()
        {
            return await _shiftTypeRepository.GetAllShiftTypesAsync();
        }

        public async Task CreateShiftTypeAsync(ShiftType shiftType)
        {
            await _shiftTypeRepository.AddShiftTypeAsync(shiftType);
            await _shiftTypeRepository.SaveChangesAsync();
        }

        public async Task UpdateShiftTypeAsync(ShiftType shiftType)
        {
            await _shiftTypeRepository.UpdateShiftTypeAsync(shiftType);
            await _shiftTypeRepository.SaveChangesAsync();
        }

        public async Task DeleteShiftTypeAsync(int id)
        {
            await _shiftTypeRepository.DeleteShiftTypeAsync(id);
            await _shiftTypeRepository.SaveChangesAsync();
        }
    }
}
