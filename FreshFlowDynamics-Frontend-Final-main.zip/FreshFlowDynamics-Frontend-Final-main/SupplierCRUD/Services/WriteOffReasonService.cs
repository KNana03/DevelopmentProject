﻿
using SupplierCRUD.Models;
using Microsoft.EntityFrameworkCore;

namespace SupplierCRUD.Services
{
    public class WriteOffReasonService : IWriteOffReasonService
    {
        private readonly AppDbContext _context;

        public WriteOffReasonService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<WriteOffReason> CreateWriteOffReasonAsync(WriteOffReason writeOffReason)
        {
            _context.WriteOffReasons.Add(writeOffReason);
            await _context.SaveChangesAsync();
            return writeOffReason;
        }

        public async Task<WriteOffReason> UpdateWriteOffReasonAsync(int id, WriteOffReason writeOffReason)
        {
            if (id != writeOffReason.Id)
            {
                throw new KeyNotFoundException("WriteOffReason not found");
            }

            _context.Entry(writeOffReason).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return writeOffReason;
        }

        public async Task<IEnumerable<WriteOffReason>> GetWriteOffReasonsAsync()
        {
            return await _context.WriteOffReasons.ToListAsync();
        }

        public async Task<WriteOffReason> GetWriteOffReasonAsync(int id)
        {
            var writeOffReason = await _context.WriteOffReasons.FindAsync(id);
            if (writeOffReason == null)
            {
                throw new KeyNotFoundException("WriteOffReason not found");
            }
            return writeOffReason;
        }

        public async Task<bool> DeleteWriteOffReasonAsync(int id)
        {
            var writeOffReason = await _context.WriteOffReasons.FindAsync(id);
            if (writeOffReason == null)
            {
                return false;
            }

            _context.WriteOffReasons.Remove(writeOffReason);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
