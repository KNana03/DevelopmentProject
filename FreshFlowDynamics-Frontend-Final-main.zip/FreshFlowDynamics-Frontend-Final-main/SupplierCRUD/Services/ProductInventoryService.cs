﻿using SupplierCRUD.Models;
using SupplierCRUD.ViewModels;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace SupplierCRUD.Services
{
    public class ProductInventoryService : IProductInventoryService
    {
        private readonly IProductRepository _productRepository;
        private readonly AppDbContext _context;
        private readonly ILogger<ProductInventoryService> _logger;

        public ProductInventoryService(IProductRepository productRepository, AppDbContext context, ILogger<ProductInventoryService> logger)
        {
            _productRepository = productRepository;
            _context = context;
            _logger = logger;
        }

        public async Task<Product> AddProductAsync(ProductViewModel productViewModel)
        {
            // Map ViewModel to Product
            var product = new Product
            {
                Name = productViewModel.name,
                Description = productViewModel.description,
                Price = productViewModel.price,  // Price is set in the Product model
                QuantityOnHand = productViewModel.quantityOnHand,
                Image = productViewModel.image,
                BrandId = productViewModel.brand,
                CategoryId = productViewModel.category
            };

            // Save Product to Repository
            var addedProduct = await _productRepository.AddProductAsync(product);

            // Map Product to Inventory without Price
            var inventory = new Inventory
            {
                ProductId = addedProduct.ProductId,
                WarehouseId = 1,  // Ensure the correct WarehouseId is set
                TypeId = 2,       // Ensure the correct TypeId is set
                Name = product.Name,
                Quantity = product.QuantityOnHand,
                InventoryType = "Sellable"  // InventoryType is set as needed
            };

            _context.Inventories.Add(inventory);
            await _context.SaveChangesAsync();

            return addedProduct;
        }
    }
}
