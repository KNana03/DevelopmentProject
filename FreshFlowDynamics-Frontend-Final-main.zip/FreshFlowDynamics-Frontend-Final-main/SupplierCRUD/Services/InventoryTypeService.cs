﻿using SupplierCRUD.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SupplierCRUD.Services
{
    public class InventoryTypeService : IInventoryTypeService
    {
        private readonly AppDbContext _context;

        public InventoryTypeService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<InventoryType> CreateInventoryTypeAsync(InventoryType inventoryType)
        {
            _context.InventoryTypes.Add(inventoryType);
            await _context.SaveChangesAsync();
            return inventoryType;
        }

        public async Task<InventoryType> UpdateInventoryTypeAsync(int id, InventoryType inventoryType)
        {
            if (id != inventoryType.Id)
            {
                throw new KeyNotFoundException("InventoryType not found");
            }

            _context.Entry(inventoryType).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return inventoryType;
        }

        public async Task<IEnumerable<InventoryType>> GetInventoryTypesAsync()
        {
            return await _context.InventoryTypes.ToListAsync();
        }

        public async Task<InventoryType> GetInventoryTypeAsync(int id)
        {
            var inventoryType = await _context.InventoryTypes.FindAsync(id);
            return inventoryType;
        }

        public async Task<bool> DeleteInventoryTypeAsync(int id)
        {
            var inventoryType = await _context.InventoryTypes.Include(it => it.Inventories).FirstOrDefaultAsync(it => it.Id == id);
            if (inventoryType == null)
            {
                return false;
            }

            // Remove related inventories
            var relatedInventories = await _context.Inventories.Where(i => i.TypeId == id).ToListAsync();
            _context.Inventories.RemoveRange(relatedInventories);

            _context.InventoryTypes.Remove(inventoryType);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
