﻿using OfficeOpenXml;
using SupplierCRUD.Models;
using SupplierCRUD.ViewModels;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

public interface IExcelExportService
{
    
    Task<byte[]> ExportSuppliersToExcelAsync(List<Supplier> suppliers); // Add supplier export method here
}

public class ExcelExportService : IExcelExportService
{
    

    // New method to export suppliers
    public async Task<byte[]> ExportSuppliersToExcelAsync(List<Supplier> suppliers)
    {
        OfficeOpenXml.ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;

        using (var package = new ExcelPackage())
        {
            var worksheet = package.Workbook.Worksheets.Add("Suppliers");

            // Define header row
            // worksheet.Cells[1, 1].Value = "SupplierId";
            worksheet.Cells[1, 1].Value = "Name";
            worksheet.Cells[1, 2].Value = "Location";
            worksheet.Cells[1, 3].Value = "Email";

            // Populate supplier data
            for (int i = 0; i < suppliers.Count; i++)
            {
                var supplier = suppliers[i];
                //worksheet.Cells[i + 2, 1].Value = supplier.Id;
                worksheet.Cells[i + 2, 1].Value = supplier.Name;
                worksheet.Cells[i + 2, 2].Value = supplier.Location;
                worksheet.Cells[i + 2, 3].Value = supplier.Email;
            }

            // Convert to byte array
            return await Task.FromResult(package.GetAsByteArray());
        }
    }
}
