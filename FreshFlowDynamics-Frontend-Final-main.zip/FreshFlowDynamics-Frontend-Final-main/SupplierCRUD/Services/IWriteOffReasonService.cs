﻿using SupplierCRUD.Models;

namespace SupplierCRUD.Services
{
    public interface IWriteOffReasonService
    {
        Task<WriteOffReason> CreateWriteOffReasonAsync(WriteOffReason writeOffReason);
        Task<WriteOffReason> UpdateWriteOffReasonAsync(int id, WriteOffReason writeOffReason);
        Task<IEnumerable<WriteOffReason>> GetWriteOffReasonsAsync();
        Task<WriteOffReason> GetWriteOffReasonAsync(int id);
        Task<bool> DeleteWriteOffReasonAsync(int id);
    }
}
