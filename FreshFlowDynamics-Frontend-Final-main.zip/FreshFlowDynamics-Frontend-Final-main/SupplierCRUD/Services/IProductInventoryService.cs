﻿using SupplierCRUD.Models;
using SupplierCRUD.ViewModels;
using System.Threading.Tasks;

namespace SupplierCRUD.Services
{
    public interface IProductInventoryService
    {
        Task<Product> AddProductAsync(ProductViewModel productViewModel);
    }
}
