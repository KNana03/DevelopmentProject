﻿using OfficeOpenXml;
using SupplierCRUD.Models;
using SupplierCRUD.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

public interface IExcelImportService
{
    Task<bool> ImportProductsFromExcelAsync(Stream stream); // Accepts a Stream
    Task<bool> ImportSuppliersFromExcelAsync(Stream stream);

}

public class ExcelImportService : IExcelImportService
{
    private readonly IProductRepository _productRepository;
    private readonly ISupplierRepository _supplierRepository; // Add supplier repository

    public ExcelImportService(IProductRepository productRepository, ISupplierRepository supplierRepository)
    {
        _productRepository = productRepository;
        _supplierRepository = supplierRepository; // Initialize supplier repository
    }

    public async Task<bool> ImportProductsFromExcelAsync(Stream stream)
    {
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        var products = new List<Product>();

        using (var package = new ExcelPackage(stream))
        {
            var worksheet = package.Workbook.Worksheets[0];
            var rowCount = worksheet.Dimension.Rows;

            for (int row = 2; row <= rowCount; row++)
            {
                var product = new Product
                {
                    ProductId = int.Parse(worksheet.Cells[row, 1].Text),
                    QuantityOnHand = int.Parse(worksheet.Cells[row, 2].Text),
                    Price = decimal.Parse(worksheet.Cells[row, 3].Text),
                    Image = worksheet.Cells[row, 4].Text,
                    BrandId = int.Parse(worksheet.Cells[row, 5].Text),
                    CategoryId = int.Parse(worksheet.Cells[row, 6].Text),
                    Name = worksheet.Cells[row, 7].Text,
                    Description = worksheet.Cells[row, 8].Text,
                    DateCreated = DateTime.Parse(worksheet.Cells[row, 9].Text),
                    DateModified = DateTime.Parse(worksheet.Cells[row, 10].Text),
                    IsActive = worksheet.Cells[row, 11].Text.ToLower() == "true" || worksheet.Cells[row, 11].Text.ToLower() == "active",
                    IsDeleted = worksheet.Cells[row, 12].Text.ToLower() == "true" || worksheet.Cells[row, 12].Text.ToLower() == "deleted"
                };

                products.Add(product);
            }
        }

        // Here, save products to the database
        // Assume you have logic here to save products to the database
        return true; // or false if there was an error
    }

    public async Task<bool> ImportSuppliersFromExcelAsync(Stream stream)
    {
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        var suppliers = new List<Supplier>();

        using (var package = new ExcelPackage(stream))
        {
            var worksheet = package.Workbook.Worksheets[0];
            var rowCount = worksheet.Dimension.Rows;

            for (int row = 2; row <= rowCount; row++) // Skip the header row
            {
                // Extract supplier data from the Excel row
                var name = worksheet.Cells[row, 1].Text;
                var location = worksheet.Cells[row, 2].Text;
                var email = worksheet.Cells[row, 3].Text;

                // Check if a supplier with the same email already exists in the database
                var existingSupplier = await _supplierRepository.GetSupplierByEmailAsync(email);

                if (existingSupplier != null)
                {
                    // Update existing supplier's details
                    existingSupplier.Name = name;
                    existingSupplier.Location = location;

                    // Update the supplier in the database
                    await _supplierRepository.UpdateSupplierAsync(existingSupplier);
                }
                else
                {
                    // Add a new supplier
                    var supplier = new Supplier
                    {
                        Name = name,
                        Location = location,
                        Email = email
                    };
                    suppliers.Add(supplier);
                }
            }
        }

        // Bulk insert new suppliers (if any) into the database
        if (suppliers.Any())
        {
            await _supplierRepository.BulkInsertSuppliersAsync(suppliers);
        }

        return true;
    }
}

