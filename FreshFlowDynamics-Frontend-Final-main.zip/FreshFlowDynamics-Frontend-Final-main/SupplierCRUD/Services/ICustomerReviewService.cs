﻿using SupplierCRUD.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SupplierCRUD.Services
{
    public interface ICustomerReviewService
    {
        Task<IEnumerable<CustomerReview>> GetReviewsByProductIdAsync(int productId);
        Task<CustomerReview> AddReviewAsync(CustomerReview review);
        Task DeleteReviewAsync(int reviewId);
    }
}
