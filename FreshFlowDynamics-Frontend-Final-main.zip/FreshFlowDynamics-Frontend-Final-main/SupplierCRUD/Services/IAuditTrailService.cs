﻿using SupplierCRUD.Models;

namespace SupplierCRUD.Services
{
    public interface IAuditTrailService
    {
        Task LogEventAsync(AuditTrail auditTrail);
    }
}
