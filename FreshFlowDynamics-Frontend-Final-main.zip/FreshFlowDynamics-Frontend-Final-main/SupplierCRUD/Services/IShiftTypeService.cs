﻿using SupplierCRUD.Models;

namespace SupplierCRUD.Services
{
    public interface IShiftTypeService
    {
        Task<ShiftType> GetShiftTypeByIdAsync(int id);
        Task<List<ShiftType>> GetAllShiftTypesAsync();
        Task CreateShiftTypeAsync(ShiftType shiftType);
        Task UpdateShiftTypeAsync(ShiftType shiftType);
        Task DeleteShiftTypeAsync(int id);
    }
}
