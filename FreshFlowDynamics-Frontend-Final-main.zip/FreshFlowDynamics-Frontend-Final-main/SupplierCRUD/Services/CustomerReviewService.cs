﻿using Microsoft.EntityFrameworkCore;
using SupplierCRUD.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SupplierCRUD.Services
{
    public class CustomerReviewService : ICustomerReviewService
    {
        private readonly AppDbContext _context;

        public CustomerReviewService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<CustomerReview>> GetReviewsByProductIdAsync(int productId)
        {
            return await _context.CustomerReviews
                                 .Where(cr => cr.ProductId == productId)
                                 .Include(cr => cr.Product) // Ensure the Product is included
                                 .ToListAsync();
        }

        public async Task<CustomerReview> AddReviewAsync(CustomerReview review)
        {
            _context.CustomerReviews.Add(review);
            await _context.SaveChangesAsync();

            // Load the Product explicitly if it's needed in the returned object
            await _context.Entry(review).Reference(r => r.Product).LoadAsync();
            return review;
        }

        public async Task DeleteReviewAsync(int reviewId)
        {
            var review = await _context.CustomerReviews.FindAsync(reviewId);
            if (review != null)
            {
                _context.CustomerReviews.Remove(review);
                await _context.SaveChangesAsync();
            }
        }
    }
}
