﻿using SupplierCRUD.Models;

namespace SupplierCRUD.Services
{
    public class AuditTrailService : IAuditTrailService
    {
        private readonly AppDbContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AuditTrailService(AppDbContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task LogEventAsync(AuditTrail auditTrail)
        {
            auditTrail.Timestamp = DateTime.UtcNow;
            auditTrail.IPAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();
            await _context.AuditTrails.AddAsync(auditTrail);
            await _context.SaveChangesAsync();
        }
    }
}
