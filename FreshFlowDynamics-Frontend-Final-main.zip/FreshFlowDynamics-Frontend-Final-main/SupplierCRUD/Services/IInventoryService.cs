﻿using SupplierCRUD.Models;

namespace SupplierCRUD.Services
{
    public interface IInventoryService
    {
        Task<Inventory> CreateInventoryAsync(Inventory inventory);
        Task<Inventory> UpdateInventoryAsync(int id, Inventory inventory);
        Task<IEnumerable<Inventory>> GetInventoriesAsync();
        Task<Inventory> GetInventoryAsync(int id);
        Task<bool> DeleteInventoryAsync(int id);
        Task<bool> ReturnInventoryAsync(int id, int quantity);
    }
}