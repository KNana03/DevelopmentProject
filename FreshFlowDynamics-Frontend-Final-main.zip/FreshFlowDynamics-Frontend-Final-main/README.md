This repo is our new Backend repository, as when i tried pushing to the backend repo, github once again deleted the new code we added. So i repurposed the old frontend repo to cater for our backend. I do not want to change the name 
of this repository as I am afraid it will cause damages to the code. 
