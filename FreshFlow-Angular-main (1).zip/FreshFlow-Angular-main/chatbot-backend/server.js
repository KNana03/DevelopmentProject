const express = require('express');
const axios = require('axios');
const cors = require('cors'); // Import cors
const app = express();
const port = 7261;

const BING_API_KEY = 'Aja_o1WilkItwvu9I42c5P7cQOe1DR6NPHOQR7V_mfT2D0ejJITXPsARNZ6ZLj9K';
const BING_SEARCH_URL = 'https://api.bing.microsoft.com/v7.0/search';

app.use(cors()); // Use cors middleware
app.use(express.json());

app.post('/search', async (req, res) => {
    const query = req.body.query;
    if (!query) {
        return res.status(400).send({ error: 'Query is required' });
    }

    try {
        const response = await axios.get(BING_SEARCH_URL, {
            headers: { 'Ocp-Apim-Subscription-Key': BING_API_KEY },
            params: { q: query, count: 3 } // Fetch top 3 results
        });
        const results = response.data.webPages.value.map(result => ({
            name: result.name,
            url: result.url,
            snippet: result.snippet
        }));
        res.send(results);
    } catch (error) {
        console.error(error);
        res.status(500).send({ error: 'Failed to fetch search results' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
