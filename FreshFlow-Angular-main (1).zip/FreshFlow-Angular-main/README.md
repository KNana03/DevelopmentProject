This is the new repository for Iteration 6. We had to switch from the exisiting repo since there were issues with github deleting our code. 
Nick - Inventory code and inventory report documentation 
Sibu - Product code and InventoryTurnover documentation 
Kavish - Orders code and reports code 
Thamsanqa - Login and sales report documentation 
Thuthuza Nhlanhla - Staff and shift documentation and code



Iteration 7:
Nick - Help functionality on each screen
Sibu - Warehouses, products
Kavish - Complexity and report fixing 
Thamsanqa - Excel functionality and authorisation
Thuthuza Nhlanhla - Audit trail and shift


