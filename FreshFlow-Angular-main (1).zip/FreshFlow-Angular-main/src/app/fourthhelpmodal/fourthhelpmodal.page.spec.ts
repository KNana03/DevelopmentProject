import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FourthhelpmodalPage } from './fourthhelpmodal.page';

describe('FourthhelpmodalPage', () => {
  let component: FourthhelpmodalPage;
  let fixture: ComponentFixture<FourthhelpmodalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(FourthhelpmodalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
