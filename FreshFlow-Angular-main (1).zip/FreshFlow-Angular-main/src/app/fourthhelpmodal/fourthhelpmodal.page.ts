import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'app-fourthhelpmodal',
  templateUrl: './fourthhelpmodal.page.html',
  styleUrls: ['./fourthhelpmodal.page.scss'],
})
export class FourthhelpmodalPage implements OnInit {
  constructor(private navCtrl: NavController) { }
  ngOnInit() {
    const iframe = document.getElementById('help-frame') as HTMLIFrameElement;
    iframe.onload = () => {
      iframe.contentWindow?.postMessage('staff', '*');
    };
  }

  dismissModal() {
    this.navCtrl.back();
  }
}
