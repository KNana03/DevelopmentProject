import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FourthhelpmodalPage } from './fourthhelpmodal.page';

const routes: Routes = [
  {
    path: '',
    component: FourthhelpmodalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FourthhelpmodalPageRoutingModule {}
