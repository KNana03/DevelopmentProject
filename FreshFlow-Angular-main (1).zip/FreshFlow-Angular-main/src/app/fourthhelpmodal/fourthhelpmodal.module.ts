import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FourthhelpmodalPageRoutingModule } from './fourthhelpmodal-routing.module';

import { FourthhelpmodalPage } from './fourthhelpmodal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FourthhelpmodalPageRoutingModule
  ],
  declarations: [FourthhelpmodalPage]
})
export class FourthhelpmodalPageModule {}
