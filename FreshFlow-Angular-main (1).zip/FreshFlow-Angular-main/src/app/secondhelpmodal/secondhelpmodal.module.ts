import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SecondhelpmodalPageRoutingModule } from './secondhelpmodal-routing.module';

import { SecondhelpmodalPage } from './secondhelpmodal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SecondhelpmodalPageRoutingModule
  ],
  declarations: [SecondhelpmodalPage]
})
export class SecondhelpmodalPageModule {}
