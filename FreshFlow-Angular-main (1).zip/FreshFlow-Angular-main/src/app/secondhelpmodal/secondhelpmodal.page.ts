import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-secondhelpmodal',
  templateUrl: './secondhelpmodal.page.html',
  styleUrls: ['./secondhelpmodal.page.scss'],
})
export class SecondhelpmodalPage implements OnInit {

  constructor(private navCtrl: NavController) { }

  ngOnInit() {
    const iframe = document.getElementById('help-frame') as HTMLIFrameElement;
    iframe.onload = () => {
      iframe.contentWindow?.postMessage('supplier-documents', '*');
    };
  }

  dismissModal() {
    this.navCtrl.back();
  }
}

