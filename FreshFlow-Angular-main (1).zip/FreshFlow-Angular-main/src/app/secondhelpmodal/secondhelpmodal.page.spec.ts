import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SecondhelpmodalPage } from './secondhelpmodal.page';

describe('SecondhelpmodalPage', () => {
  let component: SecondhelpmodalPage;
  let fixture: ComponentFixture<SecondhelpmodalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondhelpmodalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
