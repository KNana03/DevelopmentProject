import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from '../services/authservice.service';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-create-role-page',
  templateUrl: './create-role-page.page.html',
  styleUrls: ['./create-role-page.page.scss'],
})
export class CreateRolePagePage implements OnInit {
  roleName: string = '';

  constructor(private authService: AuthserviceService, private alertController: AlertController) { }

  ngOnInit() { }

  async createRole() {
    if (!this.roleName.trim()) {
      this.presentAlert('Error', 'Role name cannot be empty.');
      return;
    }

    this.authService.createRole(this.roleName).subscribe(
      () => {
        this.presentAlert('Success', 'Role created successfully');
      },
      (error) => {
        const errorMessage = this.getErrorMessage(error);
        this.presentAlert('Error', errorMessage);
      }
    );
  }

  async presentAlert(header: string, message: string) {
    const alert = await this.alertController.create({
      header,
      message,
      buttons: ['OK'],
    });

    await alert.present();
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to create role due to invalid input. Please check the role name and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while creating the role. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }
}
