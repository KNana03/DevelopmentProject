import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StaffAttendanceService } from '../services/staff-attendance.service';
import { CheckInOutRequest } from '../Model/CheckInOutRequest'; // Import the model

@Component({
  selector: 'app-check-out',
  templateUrl: './check-out.page.html',
  styleUrls: ['./check-out.page.scss'],
})
export class CheckOutPage implements OnInit {
  staffId: number = 0;
  fiveDigitCode: string = '';
  errorMessage: string = '';

  constructor(
    private staffAttendanceService: StaffAttendanceService,
    private router: Router
  ) { }

  ngOnInit() { }

  checkOut() {
    if (!this.staffId || !this.fiveDigitCode) {
      this.errorMessage = 'Please enter Staff ID and Five Digit Code.';
      return;
    }

    const request: CheckInOutRequest = {
      staffId: this.staffId,
      fiveDigitCode: this.fiveDigitCode
    };

    this.staffAttendanceService.checkOut(request).subscribe(
      response => {
        // Handle success response here
        console.log(response);
        // Navigate to another page or show a success message
        this.router.navigate(['/success-page']); // Adjust the path as needed
      },
      error => {
        this.errorMessage = this.getErrorMessage(error);
      }
    );
  }

  private getErrorMessage(error: any): string {
    if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else if (error.error && error.error.message) {
      return error.error.message;
    } else {
      return 'An unexpected error occurred. Please try again later.';
    }
  }
}
