import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdateOrderPage } from './update-order.page';

describe('UpdateOrderPage', () => {
  let component: UpdateOrderPage;
  let fixture: ComponentFixture<UpdateOrderPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateOrderPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
