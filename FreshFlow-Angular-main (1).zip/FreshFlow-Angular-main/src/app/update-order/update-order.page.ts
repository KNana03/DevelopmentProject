import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { OrderService } from '../services/order.service';
import { Order } from '../Model/order';
import { PopoverController } from '@ionic/angular'; // Import PopoverController
 // Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-update-order',
  templateUrl: './update-order.page.html',
  styleUrls: ['./update-order.page.scss'],
})
export class UpdateOrderPage implements OnInit {
  order: Order = {
    id: 0,
    type: '',
    quantity: 0,
    price: 0,
    isPaid: false,
    orderDate: new Date(),
    receivedDate: null
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private orderService: OrderService,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  ngOnInit() {
    const id = +this.route.snapshot.paramMap.get('id')!;
    this.loadOrder(id);
  }

  loadOrder(id: number) {
    this.orderService.getOrderById(id).subscribe(
      order => this.order = order,
      error => {
        console.error('Error fetching order', error);
        alert(this.getErrorMessage(error, 'fetching the order'));
      }
    );
  }

  updateOrder(form: NgForm) {
    if (form.invalid) {
      alert('Please fill in all fields correctly.');
      return;
    }

    this.orderService.updateOrder(this.order).subscribe(
      () => {
        alert('Order updated successfully');
        this.router.navigate(['/view-orders']);
      },
      error => {
        console.error('Error updating order', error);
        alert(this.getErrorMessage(error, 'updating the order'));
      }
    );
  }

  private getErrorMessage(error: any, action: string): string {
    if (error.status === 400) {
      return `Failed to complete the action of ${action} due to invalid input. Please check the fields and try again.`;
    } else if (error.status === 500) {
      return `Server error occurred while ${action}. Please try again later.`;
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return `An unexpected error occurred while ${action}. Please try again.`;
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'type':
        hintMessage = "Enter the name or type of the order item.";
        break;
      case 'quantity':
        hintMessage = "Specify the quantity of the items in the order.";
        break;
      case 'price':
        hintMessage = "Enter the total price for the order.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
