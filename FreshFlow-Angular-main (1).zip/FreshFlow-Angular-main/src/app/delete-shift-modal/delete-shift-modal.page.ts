import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { ShiftService } from '../services/shift.service';

@Component({
  selector: 'app-delete-shift-modal',
  templateUrl: './delete-shift-modal.page.html',
  styleUrls: ['./delete-shift-modal.page.scss'],
})
export class DeleteShiftModalPage implements OnInit {
  shiftId: string = ''; // Default value

  constructor(
    private router: Router,
    private shiftService: ShiftService,
    private modalController: ModalController
  ) { }

  ngOnInit() { }

  closeModal() {
    this.modalController.dismiss().then(() => {
      this.router.navigate(['/view-shifts']);
    }).catch((error) => {
      console.error('Error closing modal', error);
      alert('Failed to close the modal. Please try again.');
    });
  }

  confirmDeletion() {
    if (!this.shiftId.trim()) {
      alert('Shift ID is required to delete a shift.');
      return;
    }

    this.shiftService.deleteShift(this.shiftId).subscribe({
      next: response => {
        console.log('Shift deletion successful', response);
        this.router.navigate(['/view-shifts']).then(() => {
          this.modalController.dismiss();
        }).catch((error) => {
          console.error('Error navigating to view-shifts', error);
          alert('Shift was deleted, but failed to navigate to the shifts view. Please try again.');
        });
      },
      error: error => {
        console.error('Shift deletion error', error);
        alert(this.getErrorMessage(error));
      }
    });
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to delete shift due to invalid input. Please check the Shift ID and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while deleting the shift. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }
}
