import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DeleteShiftModalPageRoutingModule } from './delete-shift-modal-routing.module';

import { DeleteShiftModalPage } from './delete-shift-modal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DeleteShiftModalPageRoutingModule
  ],
  declarations: [DeleteShiftModalPage]
})
export class DeleteShiftModalPageModule {}
