import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DeleteShiftModalPage } from './delete-shift-modal.page';

const routes: Routes = [
  {
    path: '',
    component: DeleteShiftModalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DeleteShiftModalPageRoutingModule {}
