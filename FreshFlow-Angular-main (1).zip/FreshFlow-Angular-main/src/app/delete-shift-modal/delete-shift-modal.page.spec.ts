import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DeleteShiftModalPage } from './delete-shift-modal.page';

describe('DeleteShiftModalPage', () => {
  let component: DeleteShiftModalPage;
  let fixture: ComponentFixture<DeleteShiftModalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteShiftModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
