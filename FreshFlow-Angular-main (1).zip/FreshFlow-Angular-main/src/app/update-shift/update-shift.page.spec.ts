import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdateShiftPage } from './update-shift.page';

describe('UpdateShiftPage', () => {
  let component: UpdateShiftPage;
  let fixture: ComponentFixture<UpdateShiftPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateShiftPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
