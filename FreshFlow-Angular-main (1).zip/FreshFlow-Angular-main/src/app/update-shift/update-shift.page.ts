import { Component, OnInit } from '@angular/core';
import { Shift } from '../Model/shift';
import { ShiftType } from '../Model/shift-type';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { ShiftTypeService } from '../services/shift-type.service';
import { ShiftService } from '../services/shift.service';

@Component({
  selector: 'app-update-shift',
  templateUrl: './update-shift.page.html',
  styleUrls: ['./update-shift.page.scss'],
})
export class UpdateShiftPage implements OnInit {
  shiftData: Shift = {
    id: 0,
    startTime: '',
    endTime: '',
    name: '',
    date: '',
    shiftTypeId: 0,
    typeName: ''
  };
  shiftTypes: ShiftType[] = [];

  constructor(
    private navCtrl: NavController,
    private router: Router,
    private shiftService: ShiftService,
    private shiftTypeService: ShiftTypeService
  ) { }

  ngOnInit() {
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      const state = navigation.extras.state as { [key: string]: any };
      if (state['shift']) {
        this.shiftData = state['shift'];
      }
    }
    this.loadShiftTypes();
  }

  loadShiftTypes() {
    this.shiftTypeService.getAllShiftTypes().subscribe({
      next: (types) => {
        this.shiftTypes = types;
      },
      error: (error) => {
        console.error('Error fetching shift types', error);
        alert(this.getErrorMessage(error, 'loading shift types'));
      },
      complete: () => {
        console.log('Shift types loading completed');
      }
    });
  }

  navigateToViewShifts() {
    this.navCtrl.navigateForward(['/view-shift']);
  }

  updateShift() {
    if (!this.isFormValid()) {
      alert('Please fill in all fields correctly.');
      return;
    }

    this.shiftService.updateShift(this.shiftData.id.toString(), this.shiftData).subscribe({
      next: (response) => {
        console.log('Shift updated successfully', response);
        alert('Shift updated successfully');
        this.navigateToViewShifts();
      },
      error: (error) => {
        console.error('Shift update failed', error);
        alert(this.getErrorMessage(error, 'updating the shift'));
      },
      complete: () => {
        console.log('Shift update completed');
      }
    });
  }

  private isFormValid(): boolean {
    return (
      this.shiftData.name.trim() !== '' &&
      this.shiftData.startTime.trim() !== '' &&
      this.shiftData.endTime.trim() !== '' &&
      this.shiftData.date.trim() !== '' &&
      this.shiftData.shiftTypeId > 0
    );
  }

  private getErrorMessage(error: any, action: string): string {
    if (error.status === 400) {
      return `Failed to complete the action of ${action} due to invalid input. Please check the fields and try again.`;
    } else if (error.status === 500) {
      return `Server error occurred while ${action}. Please try again later.`;
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return `An unexpected error occurred while ${action}. Please try again.`;
    }
  }
}
