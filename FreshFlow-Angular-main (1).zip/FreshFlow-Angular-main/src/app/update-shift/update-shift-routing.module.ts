import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UpdateShiftPage } from './update-shift.page';

const routes: Routes = [
  {
    path: '',
    component: UpdateShiftPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UpdateShiftPageRoutingModule {}
