import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UpdateShiftPageRoutingModule } from './update-shift-routing.module';

import { UpdateShiftPage } from './update-shift.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    UpdateShiftPageRoutingModule
  ],
  declarations: [UpdateShiftPage]
})
export class UpdateShiftPageModule {}
