import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Brand } from 'src/app/Model/brand';
import { Category } from 'src/app/Model/category';
import { ProductService } from 'src/app/services/product.service';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-add-brand',
  templateUrl: './add-brand.component.html',
  styleUrls: ['./add-brand.component.scss'],
})
export class AddBrandComponent implements OnInit {
  @Output() brandAdded = new EventEmitter<Brand>();

  newBrand: Brand = {
    brandId: 0,
    categoryId: 0,
    name: '',
    description: '',
    dateCreated: new Date(),
    dateModified: new Date(),
    isActive: true,
    isDeleted: false
  };

  categories: Category[] = [];

  constructor(
    private productService: ProductService,
    private snackBar: MatSnackBar,
    private modalController: ModalController
  ) { }

  ngOnInit() {
    this.loadCategories();
  }

  loadCategories() {
    this.productService.getCategories().subscribe(
      (categories) => {
        this.categories = categories;
      },
      (error) => {
        const errorMessage = this.getErrorMessage(error);
        console.error('Error loading categories', error);
        this.snackBar.open(errorMessage, 'Close', {
          duration: 3000,
        });
      }
    );
  }

  addBrand() {
    if (!this.newBrand.name.trim()) {
      this.snackBar.open('Brand name is required', 'Close', {
        duration: 3000,
      });
      return;
    }

    if (!this.newBrand.description.trim()) {
      this.snackBar.open('Brand description is required', 'Close', {
        duration: 3000,
      });
      return;
    }

    if (this.newBrand.categoryId === 0) {
      this.snackBar.open('Please select a category', 'Close', {
        duration: 3000,
      });
      return;
    }

    this.productService.addBrand(this.newBrand).subscribe(
      (brand) => {
        console.log('Brand added successfully:', brand);
        this.snackBar.open('Brand added successfully', 'Close', {
          duration: 3000,
        });
        this.brandAdded.emit(brand);
        this.modalController.dismiss(brand);
        this.resetNewBrand();
      },
      (error) => {
        const errorMessage = this.getErrorMessage(error);
        console.error('Error adding brand', error);
        this.snackBar.open(errorMessage, 'Close', {
          duration: 3000,
        });
      }
    );
  }

  private resetNewBrand() {
    this.newBrand = {
      brandId: 0,
      categoryId: 0,
      name: '',
      description: '',
      dateCreated: new Date(),
      dateModified: new Date(),
      isActive: true,
      isDeleted: false
    };
  }

  private getErrorMessage(error: any): string {
    if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else if (error.error && error.error.message) {
      return error.error.message;
    } else {
      return 'An unexpected error occurred. Please try again later.';
    }
  }
}
