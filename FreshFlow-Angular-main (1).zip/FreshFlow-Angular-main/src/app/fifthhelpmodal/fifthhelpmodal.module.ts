import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FifthhelpmodalPageRoutingModule } from './fifthhelpmodal-routing.module';

import { FifthhelpmodalPage } from './fifthhelpmodal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FifthhelpmodalPageRoutingModule
  ],
  declarations: [FifthhelpmodalPage]
})
export class FifthhelpmodalPageModule {}
