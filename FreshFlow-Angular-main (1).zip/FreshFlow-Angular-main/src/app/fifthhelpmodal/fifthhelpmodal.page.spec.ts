import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FifthhelpmodalPage } from './fifthhelpmodal.page';

describe('FifthhelpmodalPage', () => {
  let component: FifthhelpmodalPage;
  let fixture: ComponentFixture<FifthhelpmodalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(FifthhelpmodalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
