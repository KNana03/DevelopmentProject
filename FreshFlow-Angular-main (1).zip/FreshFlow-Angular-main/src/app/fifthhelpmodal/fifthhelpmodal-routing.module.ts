import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FifthhelpmodalPage } from './fifthhelpmodal.page';

const routes: Routes = [
  {
    path: '',
    component: FifthhelpmodalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FifthhelpmodalPageRoutingModule {}
