import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from '../services/authservice.service';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-assign-role',
  templateUrl: './assign-role.page.html',
  styleUrls: ['./assign-role.page.scss'],
})
export class AssignRolePage implements OnInit {
  emailAddress: string = '';
  roleName: string = '';

  constructor(private authService: AuthserviceService, private alertController: AlertController) { }

  ngOnInit() {
  }

  async assignRole() {
    // Validate email
    if (!this.emailAddress || !this.isEmailValid(this.emailAddress)) {
      this.presentAlert('Error', 'Please enter a valid email address.');
      return;
    }
  
    // Validate role name
    if (!this.roleName || this.roleName.trim() === '') {
      this.presentAlert('Error', 'Role name is required.');
      return;
    }
  
    // Proceed with API call only if validations pass
    this.authService.assignRole(this.emailAddress, this.roleName).subscribe(
      () => {
        this.presentAlert('Success', 'Role assigned successfully');
      },
      (error) => {
        const errorMessage = this.getErrorMessage(error);
        this.presentAlert('Error', errorMessage);
        console.error('Error assigning role:', error);
      }
    );
  }
  
  // Improved error message function
  private getErrorMessage(error: any): string {
    // Network issues
    if (error.status === 0) {
      return 'Network error. Please check your connection.';
    }
    
    // HTTP Status 400 Bad Request
    else if (error.status === 400) {
      return 'Invalid request. Please check the entered details.';
    }
    
    // HTTP Status 401 Unauthorized
    else if (error.status === 401) {
      return 'Unauthorized. Please log in again.';
    }
  
    // HTTP Status 403 Forbidden
    else if (error.status === 403) {
      return 'Forbidden. You do not have permission to assign this role.';
    }
  
    // HTTP Status 404 Not Found
    else if (error.status === 404) {
      return 'Endpoint not found. Please contact support.';
    }
  
    // HTTP Status 500 Internal Server Error
    else if (error.status === 500) {
      return 'Server error. Please try again later.';
    }
  
    // // Custom error message from the backend
    // else if (error.error && error.error.message) {
    //   return error.error.message;
    // }
  
    // Catch-all for unexpected errors
    else {
      return 'An unexpected error occurred. Please try again later.';
    }
  }
  
 // Present an alert for errors and successes
async presentAlert(header: string, message: string) {
  const alert = await this.alertController.create({
    header,
    message,
    buttons: ['OK'],
  });
  await alert.present();
}

// Email validation function
public isEmailValid(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

  // private getErrorMessage(error: any): string {
  //   if (error.status === 0) {
  //     return 'Network error. Please check your connection.';
  //   } else if (error.error && error.error.message) {
  //     return error.error.message;
  //   } else {
  //     return 'An unexpected error occurred. Please try again later.';
  //   }
  // }

  // Changed to public so it can be accessed in the template
  // public isEmailValid(email: string): boolean {
  //   const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  //   return emailRegex.test(email);
  // }
}
