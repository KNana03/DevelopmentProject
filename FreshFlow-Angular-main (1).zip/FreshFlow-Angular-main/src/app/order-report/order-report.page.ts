import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { OrderService } from '../services/order.service';
import { AuthserviceService } from '../services/authservice.service'; // Import the Auth service
import { Router } from '@angular/router';
import { Order } from '../Model/order';
import { Chart, registerables } from 'chart.js';
import { NavController } from '@ionic/angular';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { BASE64_LOGO } from '../app.constants';

Chart.register(...registerables);

@Component({
  selector: 'app-order-report',
  templateUrl: './order-report.page.html',
  styleUrls: ['./order-report.page.scss'],
})
export class OrderReportPage implements OnInit {
  totalOrders: number = 0;
  totalRevenue: number = 0;
  pendingOrders: number = 0;
  totalQuantity: number = 0;
  orders: Order[] = [];
  filteredOrders: Order[] = [];
  timeframes: string[] = ['1 Week', '1 Month', '3 Months', '6 Months', '1 Year'];
  selectedTimeframe: string = '1 Month';
  currentUserName: string = ''; // Variable to store the current user's name

  @ViewChild('lineCanvas', { static: true }) private lineCanvas!: ElementRef;
  lineChart: any;

  constructor(
    private orderService: OrderService,
    private authService: AuthserviceService, // Inject the Auth service
    private router: Router,
    private navCtrl: NavController
  ) { }

  ngOnInit() {
    this.fetchOrderSummary();
    this.currentUserName = this.authService.getCurrentUserName(); // Get the current logged-in username
  }
  openHelp() {
    this.navCtrl.navigateForward('/reporthelpmodal');
  }
  fetchOrderSummary() {
    this.orderService.getAllOrders().subscribe(
      data => {
        console.log('Orders fetched:', data); // Debug log
        this.orders = data;
        this.addDummyData(); // Add dummy data after fetching real orders
        this.updateOrderSummary();
      },
      error => {
        console.error('Error fetching order summary', error);
      }
    );
  }

  addDummyData() {
    const now = new Date();
    const dummyData = [
      { id: 1, type: 'Dummy Order 1', price: 100.00, quantity: 10, isPaid: true, orderDate: new Date(now.getTime() - (5 * 24 * 60 * 60 * 1000)) }, // last week
      { id: 2, type: 'Dummy Order 2', price: 150.00, quantity: 5, isPaid: false, orderDate: new Date(now.getTime() - (10 * 24 * 60 * 60 * 1000)) }, // last month
      { id: 3, type: 'Dummy Order 3', price: 200.00, quantity: 7, isPaid: true, orderDate: new Date(now.getTime() - (40 * 24 * 60 * 60 * 1000)) }, // last 3 months
      { id: 4, type: 'Dummy Order 4', price: 250.00, quantity: 3, isPaid: false, orderDate: new Date(now.getTime() - (100 * 24 * 60 * 60 * 1000)) }, // last 6 months
      { id: 5, type: 'Dummy Order 5', price: 300.00, quantity: 9, isPaid: true, orderDate: new Date(now.getTime() - (200 * 24 * 60 * 60 * 1000)) }, // last year
      { id: 6, type: 'Dummy Order 6', price: 110.00, quantity: 2, isPaid: true, orderDate: new Date(now.getTime() - (3 * 24 * 60 * 60 * 1000)) }, // last week
      { id: 7, type: 'Dummy Order 7', price: 210.00, quantity: 6, isPaid: false, orderDate: new Date(now.getTime() - (15 * 24 * 60 * 60 * 1000)) }, // last month
      { id: 8, type: 'Dummy Order 8', price: 160.00, quantity: 8, isPaid: true, orderDate: new Date(now.getTime() - (50 * 24 * 60 * 60 * 1000)) }, // last 3 months
      { id: 9, type: 'Dummy Order 9', price: 130.00, quantity: 4, isPaid: false, orderDate: new Date(now.getTime() - (120 * 24 * 60 * 60 * 1000)) }, // last 6 months
      { id: 10, type: 'Dummy Order 10', price: 90.00, quantity: 12, isPaid: true, orderDate: new Date(now.getTime() - (250 * 24 * 60 * 60 * 1000)) }, // last year
      { id: 11, type: 'Dummy Order 11', price: 140.00, quantity: 1, isPaid: true, orderDate: new Date(now.getTime() - (1 * 24 * 60 * 60 * 1000)) }, // last week
      { id: 12, type: 'Dummy Order 12', price: 240.00, quantity: 3, isPaid: false, orderDate: new Date(now.getTime() - (20 * 24 * 60 * 60 * 1000)) }, // last month
      { id: 13, type: 'Dummy Order 13', price: 180.00, quantity: 5, isPaid: true, orderDate: new Date(now.getTime() - (60 * 24 * 60 * 60 * 1000)) }, // last 3 months
      { id: 14, type: 'Dummy Order 14', price: 270.00, quantity: 7, isPaid: false, orderDate: new Date(now.getTime() - (150 * 24 * 60 * 60 * 1000)) }, // last 6 months
      { id: 15, type: 'Dummy Order 15', price: 350.00, quantity: 6, isPaid: true, orderDate: new Date(now.getTime() - (300 * 24 * 60 * 60 * 1000)) }, // last year
      { id: 16, type: 'Dummy Order 16', price: 130.00, quantity: 8, isPaid: true, orderDate: new Date(now.getTime() - (4 * 24 * 60 * 60 * 1000)) }, // last week
      { id: 17, type: 'Dummy Order 17', price: 170.00, quantity: 3, isPaid: false, orderDate: new Date(now.getTime() - (25 * 24 * 60 * 60 * 1000)) }, // last month
      { id: 18, type: 'Dummy Order 18', price: 190.00, quantity: 7, isPaid: true, orderDate: new Date(now.getTime() - (70 * 24 * 60 * 60 * 1000)) }, // last 3 months
      { id: 19, type: 'Dummy Order 19', price: 210.00, quantity: 9, isPaid: false, orderDate: new Date(now.getTime() - (130 * 24 * 60 * 60 * 1000)) }, // last 6 months
      { id: 20, type: 'Dummy Order 20', price: 310.00, quantity: 11, isPaid: true, orderDate: new Date(now.getTime() - (350 * 24 * 60 * 60 * 1000)) }, // last year
    ];

    this.orders.push(...dummyData);
  }

  updateOrderSummary() {
    this.filterOrdersByTimeframe();
    this.totalOrders = this.filteredOrders.length;
    this.totalRevenue = this.filteredOrders.reduce((sum, order) => sum + (order.price || 0), 0);
    this.pendingOrders = this.filteredOrders.filter(order => !order.isPaid).length;
    this.totalQuantity = this.filteredOrders.reduce((sum, order) => sum + (order.quantity || 0), 0);  // Calculate total quantity
    this.prepareChartData();
  }

  filterOrdersByTimeframe() {
    const now = new Date();
    let startDate: Date;

    switch (this.selectedTimeframe) {
      case '1 Week':
        startDate = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
        break;
      case '1 Month':
        startDate = new Date(now.setMonth(now.getMonth() - 1));
        break;
      case '3 Months':
        startDate = new Date(now.setMonth(now.getMonth() - 3));
        break;
      case '6 Months':
        startDate = new Date(now.setMonth(now.getMonth() - 6));
        break;
      case '1 Year':
        startDate = new Date(now.setFullYear(now.getFullYear() - 1));
        break;
      default:
        startDate = new Date(now.setMonth(now.getMonth() - 1));
    }

    this.filteredOrders = this.orders.filter(order => order.orderDate && new Date(order.orderDate) >= startDate);
  }

  prepareChartData() {
    const labels = this.filteredOrders.map(order => {
      return order.orderDate ? new Date(order.orderDate).toLocaleDateString() : 'Unknown';
    });
    const prices = this.filteredOrders.map(order => order.price || 0);

    if (this.lineChart) {
      this.lineChart.destroy();
    }

    this.lineChart = new Chart(this.lineCanvas.nativeElement, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Order Prices',
            data: prices,
            borderColor: '#42A5F5',
            fill: false,
          }
        ]
      },
      options: {
        responsive: true,
        scales: {
          x: {
            display: true,
            title: {
              display: true,
              text: 'Date'
            }
          },
          y: {
            display: true,
            title: {
              display: true,
              text: 'Price (ZAR)'
            }
          }
        }
      }
    });
  }

  onTimeframeChange() {
    this.updateOrderSummary();
  }

  navigateToOrderDetails() {
    this.router.navigate(['/view-orders']);
  }

  generatePDF() {
    const totalQuantity = this.filteredOrders.reduce((sum, order) => sum + (order.quantity || 0), 0);
    const totalPrice = this.filteredOrders.reduce((sum, order) => sum + (order.price || 0), 0).toFixed(2);

    const docDefinition = {
      content: [
        {
          columns: [
            {
              image: BASE64_LOGO,
              width: 100,
            },
            {
              stack: [
                { text: 'AB Fresh Wholesalers', bold: true, fontSize: 14, alignment: 'right' },
                { text: 'Store 204a, Hall 2, JHB Fresh Produce Market', alignment: 'right' },
                { text: 'City Deep, Johannesburg, 2049', alignment: 'right' },

                { text: `Generated by: ${this.currentUserName}`, alignment: 'right' }, // Include the username here
                { text: `Report Date: ${new Date().toLocaleDateString()}`, alignment: 'right' }, // Include the report date here
              ],
              alignment: 'right'
            }
          ],
          margin: [0, 0, 0, 20]
        },
        { text: 'Order Report', style: 'header', alignment: 'center' },
        { text: `Timeframe: ${this.selectedTimeframe}`, style: 'subheader', alignment: 'center' },
        { text: `Total Orders: ${this.totalOrders}`, style: 'subheader', alignment: 'center' },
        { text: `Total Revenue: ${totalPrice} ZAR`, style: 'subheader', alignment: 'center' },
        { text: `Pending Orders: ${this.pendingOrders}`, style: 'subheader', alignment: 'center' },
        {
          style: 'tableExample',
          table: {
            headerRows: 1,
            widths: ['*', 'auto', 'auto', 'auto'],
            body: [
              [
                { text: 'Order Type', style: 'tableHeader' },
                { text: 'Price (ZAR)', style: 'tableHeader' },
                { text: 'Quantity', style: 'tableHeader' },
                { text: 'Order Date', style: 'tableHeader' }
              ],
              ...this.filteredOrders.map(order => [
                order.type,
                order.price.toFixed(2),
                order.quantity,
                order.orderDate ? new Date(order.orderDate).toLocaleDateString() : 'Unknown'
              ]),
              [
                { text: 'Total', colSpan: 1, alignment: 'right', bold: true },
                { text: totalPrice, alignment: 'right', bold: true },
                { text: totalQuantity.toString(), alignment: 'right', bold: true },
                {}
              ]
            ]
          },
          layout: {
            fillColor: (rowIndex: number) => (rowIndex % 2 === 0 ? '#F5F5F5' : null),
            hLineWidth: () => 0.5,
            vLineWidth: () => 0.5,
            hLineColor: () => '#A9A9A9',
            vLineColor: () => '#A9A9A9'
          }
        }
      ],
      styles: {
        header: {
          fontSize: 22,
          bold: true,
          margin: [0, 20, 0, 10]
        },
        subheader: {
          fontSize: 16,
          margin: [0, 10, 0, 5]
        },
        tableHeader: {
          bold: true,
          fontSize: 13,
          color: 'black'
        },
        tableExample: {
          margin: [0, 5, 0, 15]
        }
      },
      defaultStyle: {
        fontSize: 10
      }
    };

    pdfMake.createPdf(docDefinition).download('OrderReport.pdf');
  }

}
