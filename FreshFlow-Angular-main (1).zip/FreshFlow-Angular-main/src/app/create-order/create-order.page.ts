import { Component } from '@angular/core';
import { NavController, PopoverController } from '@ionic/angular';
import { Order } from '../Model/order';
import { OrderService } from '../services/order.service';
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component'; // Import the HintPopoverComponent

@Component({
  selector: 'app-create-order',
  templateUrl: './create-order.page.html',
  styleUrls: ['./create-order.page.scss'],
})
export class CreateOrderPage {
  order: Order = {
    type: '',
    quantity: 0,
    price: 0,
    isPaid: false
  };

  selectedPaymentType: string = '';
  formSubmitted = false;

  constructor(private navCtrl: NavController, private orderService: OrderService, private popoverController: PopoverController) { }

  // Method to capture the order
  captureOrder() {
    this.formSubmitted = true;

    // Validation for form inputs with user hints
    if (!this.order.type.trim()) {
      alert('Order type cannot be empty. Please enter a valid order type.');
      return;
    }
    if (this.order.quantity <= 0) {
      alert('Quantity must be greater than zero. Please enter a valid quantity.');
      return;
    }
    if (this.order.price <= 0) {
      alert('Price must be greater than zero. Please enter a valid price.');
      return;
    }
    if (!this.selectedPaymentType) {
      alert('Please select a payment type to proceed.');
      return;
    }

    console.log('Final Payload:', this.order); // Log the final payload for debugging

    // Capture the order using the service
    this.orderService.createOrder(this.order).subscribe(
      response => {
        console.log('Order captured successfully', response);
        alert('Order captured successfully');

        // Handle order status based on payment type
        if (response && response.id) {
          if (this.selectedPaymentType === 'Cash') {
            this.orderService.updateOrderStatus(response.id, true).subscribe(() => {
              this.navCtrl.navigateBack('/view-orders');
            }, error => {
              console.error('Error updating order status:', error);
              alert(this.getErrorMessage(error, 'updating the order status'));
            });
          } else if (this.selectedPaymentType === 'Card') {
            // Assuming there's an external payment process, navigate back to view orders
            this.navCtrl.navigateBack('/view-orders');
          }
        } else {
          console.error('Order ID is undefined:', response);
          alert('Order captured, but failed to retrieve order ID. Please check the order list or try again.');
        }
      },
      error => {
        console.error('Error capturing order:', error);
        alert(this.getErrorMessage(error, 'capturing the order'));
      }
    );
  }

  private getErrorMessage(error: any, action: string): string {
    if (error.status === 400) {
      return `Failed to ${action} due to invalid input. Please review the details and try again.`;
    } else if (error.status === 500) {
      return `Server error occurred while ${action}. Please try again later.`;
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return `An unexpected error occurred while ${action}. Please check your input and try again.`;
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'orderType':
        hintMessage = "Enter a descriptive name for the order, e.g., 'Simba Chips'.";
        break;
      case 'quantity':
        hintMessage = 'Enter the number of items for this order.';
        break;
      case 'price':
        hintMessage = 'Enter the price of the order. Price must be a positive value.';
        break;
      case 'paymentType':
        hintMessage = 'Select a payment type for this order: Cash or Card.';
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
