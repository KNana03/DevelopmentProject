import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Inventories } from '../Model/inventory';
import { InventoryService } from '../services/inventory.service';
import { Router } from '@angular/router';
import { PopoverController } from '@ionic/angular'; // Import PopoverController
 // Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-update-inventory',
  templateUrl: './update-inventory.page.html',
  styleUrls: ['./update-inventory.page.scss'],
})
export class UpdateInventoryPage implements OnInit {

  inventoryData: Inventories = {
    id: 0,
    productId: 0,
    warehouseId: 0,
    typeId: 0,
    name: '',
    quantity: 0,
    inventoryType: ''
  };

  inventoryTypes = [
    { id: 'Non-Sellable', name: 'Non-Sellable Items' },
    { id: 'Sellable', name: 'Sellable Items' }
  ];

  constructor(
    private navCtrl: NavController,
    private router: Router,
    private inventoryService: InventoryService,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  ngOnInit() {
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      const state = navigation.extras.state as { [key: string]: any };
      if (state['inventory']) {
        this.inventoryData = state['inventory'];
      }
    }
  }

  navigateToViewInventory() {
    this.navCtrl.navigateForward(['/view-inventory']);
  }

  updateInventory() {
    if (!this.isFormValid()) {
      alert('Please fill in all fields correctly.');
      return;
    }

    this.inventoryService.updateInventory(this.inventoryData.id.toString(), this.inventoryData).subscribe(
      response => {
        console.log('Inventory updated successfully', response);
        this.navCtrl.navigateForward('/view-inventory');
        alert('Inventory updated successfully');
      },
      error => {
        console.error('Inventory update failed', error);
        alert(this.getErrorMessage(error));
      }
    );
  }

  private isFormValid(): boolean {
    return (
      this.inventoryData.productId > 0 &&
      this.inventoryData.warehouseId > 0 &&
      this.inventoryData.typeId > 0 &&
      this.inventoryData.name.trim() !== '' &&
      this.inventoryData.quantity > 0 &&
      this.inventoryData.inventoryType.trim() !== ''
    );
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to update inventory due to invalid input. Please check the fields and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while updating the inventory. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'name':
        hintMessage = "Enter a unique name for the inventory item.";
        break;
      case 'warehouseId':
        hintMessage = "Provide the ID of the warehouse where the item is stored.";
        break;
      case 'quantity':
        hintMessage = "Specify the quantity of the inventory item available.";
        break;
      case 'inventoryType':
        hintMessage = "Choose the inventory type: Sellable or Non-Sellable.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
