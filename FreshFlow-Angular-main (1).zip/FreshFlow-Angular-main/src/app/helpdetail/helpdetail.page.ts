import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-helpdetail',
  templateUrl: './helpdetail.page.html',
  styleUrls: ['./helpdetail.page.scss'],
})
export class HelpdetailPage implements OnInit {
  section!: string;
  searchTerm: string = '';
  sanitizedUrl!: SafeResourceUrl;

  constructor(private route: ActivatedRoute, private sanitizer: DomSanitizer) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.section = params.get('section') ?? '';
      this.updateUrl();
    });
  }

  updateUrl() {
    const url = `assets/help.html#${this.section}`;
    this.sanitizedUrl = this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  search() {
    const iframe = document.querySelector('iframe');
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage(this.searchTerm, '*');
    }
  }
}
