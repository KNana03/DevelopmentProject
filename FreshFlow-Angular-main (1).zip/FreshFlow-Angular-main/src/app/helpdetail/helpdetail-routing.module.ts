import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HelpdetailPage } from './helpdetail.page';

const routes: Routes = [
  {
    path: '',
    component: HelpdetailPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HelpdetailPageRoutingModule {}
