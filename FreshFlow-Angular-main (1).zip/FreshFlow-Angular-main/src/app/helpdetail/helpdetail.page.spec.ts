import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HelpdetailPage } from './helpdetail.page';

describe('HelpdetailPage', () => {
  let component: HelpdetailPage;
  let fixture: ComponentFixture<HelpdetailPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(HelpdetailPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
