import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HelpdetailPageRoutingModule } from './helpdetail-routing.module';

import { HelpdetailPage } from './helpdetail.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HelpdetailPageRoutingModule
  ],
  declarations: [HelpdetailPage]
})
export class HelpdetailPageModule {}
