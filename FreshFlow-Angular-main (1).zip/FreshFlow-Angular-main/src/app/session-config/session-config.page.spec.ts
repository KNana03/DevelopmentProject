import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SessionConfigPage } from './session-config.page';

describe('SessionConfigPage', () => {
  let component: SessionConfigPage;
  let fixture: ComponentFixture<SessionConfigPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(SessionConfigPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
