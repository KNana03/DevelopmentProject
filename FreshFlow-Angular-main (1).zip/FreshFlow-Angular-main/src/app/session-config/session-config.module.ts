import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SessionConfigPageRoutingModule } from './session-config-routing.module';

import { SessionConfigPage } from './session-config.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SessionConfigPageRoutingModule
  ],
  declarations: [SessionConfigPage]
})
export class SessionConfigPageModule {}
