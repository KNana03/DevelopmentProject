import { Component } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { AuthserviceService } from '../services/authservice.service'; // Adjust import path as needed

@Component({
  selector: 'app-session-config',
  templateUrl: './session-config.page.html',
  styleUrls: ['./session-config.page.scss'],
})
export class SessionConfigPage {
  sessionTimeout: number = 0; // Store the timeout in minutes

  constructor(private authService: AuthserviceService, private toastController: ToastController) { }

  /**
   * Save the updated session timeout and notify the user.
   */
  async saveTimeout() {
    if (this.sessionTimeout > 0) {
      // Call the service to update the session timeout
      this.authService.setSessionTimeout(this.sessionTimeout); // Set the timeout in minutes

      // Display a success toast message
      const toast = await this.toastController.create({
        message: 'Session timeout updated successfully',
        duration: 2000,
        color: 'success'
      });
      toast.present();
    } else {
      // Show an error if the timeout is invalid (e.g., zero or negative)
      const toast = await this.toastController.create({
        message: 'Please enter a valid timeout duration',
        duration: 2000,
        color: 'danger'
      });
      toast.present();
    }
  }
}
