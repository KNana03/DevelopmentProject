import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { InventoryService } from '../services/inventory.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Inventories } from '../Model/inventory';
import { PopoverController } from '@ionic/angular'; // Import PopoverController
// Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-create-writeoffreason',
  templateUrl: './create-writeoffreason.page.html',
  styleUrls: ['./create-writeoffreason.page.scss'],
})
export class CreateWriteoffreasonPage implements OnInit {
  writeoffreasonData: { reason: string; quantity: number } = {
    reason: '',
    quantity: 0
  };
  inventory: Inventories | null = null;

  constructor(
    private navCtrl: NavController,
    private inventoryService: InventoryService,
    private router: Router,
    private route: ActivatedRoute,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  ngOnInit() {
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras.state) {
      this.inventory = navigation.extras.state['inventory'];
    }
  }

  navigateToViewWriteoffreason() {
    this.navCtrl.navigateForward(['/view-writeoffreason']);
  }

  register() {
    if (!this.writeoffreasonData.reason.trim() || this.writeoffreasonData.quantity <= 0) {
      alert('Please fill in all fields correctly.');
      return;
    }

    if (this.inventory && this.writeoffreasonData.quantity > this.inventory.quantity) {
      alert('Write-off quantity exceeds available inventory.');
      return;
    }

    if (this.inventory) {
      // Pass the inventory ID, reason, and quantity to the backend
      this.inventoryService.addWriteOffReasonToInventory(this.inventory.id, this.writeoffreasonData).subscribe(
        response => {
          console.log('Write-Off Reason has been added successfully', response);
          alert('Write-Off Reason has been added successfully');

          // Refetch the updated inventory after write-off is successful
          this.refetchInventory();

          this.navigateToViewWriteoffreason();
        },
        error => {
          console.error('Add error', error);
          alert(this.getErrorMessage(error));
        }
      );
    } else {
      alert('No inventory selected.');
    }
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to add Write-Off Reason due to invalid input. Please check the fields and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while adding the Write-Off Reason. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }

  // Refetch the inventory to reflect the changes after write-off
  private refetchInventory() {
    if (this.inventory && this.inventory.id) {
      // Use the inventory ID to fetch the updated inventory
      this.inventoryService.getInventory(this.inventory.id.toString()).subscribe(
        updatedInventory => {
          this.inventory = updatedInventory; // Update the inventory object with the new data
          console.log('Updated inventory:', updatedInventory); // Optional: Log for debugging
        },
        error => {
          console.error('Error fetching updated inventory:', error);
          alert('Error fetching updated inventory.');
        }
      );
    } else {
      console.error('Inventory is null or undefined.');
      alert('No inventory available to update.');
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'reason':
        hintMessage = "Provide a reason for the write-off, e.g., 'Expired products'.";
        break;
      case 'quantity':
        hintMessage = "Enter the quantity of items to be written off.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
