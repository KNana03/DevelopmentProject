import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateWriteoffreasonPage } from './create-writeoffreason.page';
import { CreateWriteoffreasonPageModule } from './create-writeoffreason.module';

const routes: Routes = [
  {
    path: '',
    component: CreateWriteoffreasonPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CreateWriteoffreasonPageRoutingModule {}