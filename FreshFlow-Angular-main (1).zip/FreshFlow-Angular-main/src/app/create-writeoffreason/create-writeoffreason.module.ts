import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import { CreateWriteoffreasonPage } from './create-writeoffreason.page';
import { CreateWriteoffreasonPageRoutingModule } from './create-writeoffreason-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateWriteoffreasonPageRoutingModule
  ],
  declarations: [CreateWriteoffreasonPage]
})
export class CreateWriteoffreasonPageModule {}