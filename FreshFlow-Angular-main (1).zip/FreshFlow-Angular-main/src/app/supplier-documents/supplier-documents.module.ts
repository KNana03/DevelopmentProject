import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SupplierDocumentsPageRoutingModule } from './supplier-documents-routing.module';

import { SupplierDocumentsPage } from './supplier-documents.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SupplierDocumentsPageRoutingModule
  ],
  declarations: [SupplierDocumentsPage]
})
export class SupplierDocumentsPageModule {}
