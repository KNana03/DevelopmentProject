import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SupplierDocumentsPage } from './supplier-documents.page';

describe('SupplierDocumentsPage', () => {
  let component: SupplierDocumentsPage;
  let fixture: ComponentFixture<SupplierDocumentsPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(SupplierDocumentsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
