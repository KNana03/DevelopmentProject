import { Component, OnInit } from '@angular/core';
import { SupplierService } from '../services/supplier.service';
import { SupplierDocumentService } from '../services/supplier-document.service';
import { Suppliers } from '../Model/supplier';
import { Document } from '../Model/document';
import { PdfViewerModalComponent } from '../pdf-viewer-modal/pdf-viewer-modal.component';
import { ModalController, NavController } from '@ionic/angular';

@Component({
  selector: 'app-supplier-documents',
  templateUrl: './supplier-documents.page.html',
  styleUrls: ['./supplier-documents.page.scss'],
})
export class SupplierDocumentsPage implements OnInit {
  suppliers: Suppliers[] = [];
  selectedSupplier: Suppliers | null = null;
  documents: Document[] = [];
  categories = ['All', 'Invoices', 'Receipts'];
  selectedCategory: string = 'All';
  selectedFile: File | null = null;

  constructor(
    private supplierService: SupplierService,
    private documentService: SupplierDocumentService,
    private modalController: ModalController,
    private navCtrl: NavController
  ) { }

  ngOnInit() {
    this.fetchSuppliers();
  }

  fetchSuppliers() {
    this.supplierService.getAllSuppliers().subscribe(
      (data: any[]) => {
        // Map the supplier data to match your interface
        this.suppliers = data.map(supplier => ({
          id: supplier.id,
          Name: supplier.name,  // Match this with the actual API response
          Location: supplier.location,
          Email: supplier.email
        }));
        console.log('Suppliers fetched:', this.suppliers);

        // Optionally, you can set a default selected supplier here
        this.selectedSupplier = this.suppliers.length ? this.suppliers[0] : null;
        if (this.selectedSupplier) {
          this.loadDocuments();  // Load documents for the first supplier by default
        }
      },
      error => {
        console.error('Error fetching suppliers:', error);
      }
    );
  }

  onSupplierChange(supplier: Suppliers) {
    this.selectedSupplier = supplier;
    this.loadDocuments();
  }

  loadDocuments() {
    if (this.selectedSupplier) {
      const fileType = this.selectedCategory === 'All' ? 'all' : this.selectedCategory.toLowerCase();
      this.documentService.getDocumentsBySupplierId(this.selectedSupplier.id, fileType).subscribe(
        documents => this.documents = documents,
        error => console.error('Error loading documents:', error)
      );
    }
  }

  onCategoryChange(category: string) {
    this.selectedCategory = category;
    this.loadDocuments();
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  uploadDocument() {
    if (this.selectedFile && this.selectedSupplier) {
      const formData = new FormData();
      formData.append('file', this.selectedFile);
      formData.append('fileType', this.selectedCategory.toLowerCase());

      this.documentService.uploadDocument(this.selectedSupplier.id, formData).subscribe(
        () => {
          console.log('Document uploaded successfully');
          this.loadDocuments();  // Reload documents after upload
        },
        error => console.error('Error uploading document:', error)
      );
    } else {
      console.error('No file selected or no supplier selected');
    }
  }

  async viewDocument(document: Document) {
    const url = `https://localhost:7261/api/Supplier/documents/download/${document.id}`;

    const modal = await this.modalController.create({
      component: PdfViewerModalComponent,
      componentProps: { pdfUrl: url }
    });

    return await modal.present();
  }

  openHelp() {
    this.navCtrl.navigateForward('/secondhelpmodal');
  }

  deleteDocument(documentId: number) {
    if (confirm('Are you sure you want to delete this document?')) {
      this.documentService.deleteDocument(documentId).subscribe(
        () => {
          console.log('Document deleted successfully');
          this.documents = this.documents.filter(doc => doc.id !== documentId);
        },
        error => console.error('Error deleting document:', error)
      );
    }
  }
}
