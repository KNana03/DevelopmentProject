import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { ProductService } from 'src/app/services/product.service';
import { CustomerReview } from '../Model/CustomerReview';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-review',
  templateUrl: './add-review.page.html',
  styleUrls: ['./add-review.page.scss'],
})
export class AddReviewPage implements OnInit {
  reviewForm: FormGroup;
  productId?: number; // This will be passed in via componentProps

  constructor(
    private fb: FormBuilder,
    private modalCtrl: ModalController,
    private productService: ProductService
  ) {
    this.reviewForm = this.fb.group({
      review: ['', [Validators.required, Validators.minLength(10)]],
      rating: [0, [Validators.required, Validators.min(1), Validators.max(5)]]
    });
  }

  ngOnInit() {
    // Ensure that productId is set before proceeding
    if (this.productId === undefined) {
      this.displayError('Product ID is missing. Please try again.');
      this.dismiss(); // Optionally close the modal if productId is missing
    }
  }

  dismiss() {
    this.modalCtrl.dismiss();
  }

  submitReview() {
    if (this.reviewForm.valid && this.productId !== undefined) {
      const review: CustomerReview = {
        customerReviewId: 0,
        ...this.reviewForm.value,
        productId: this.productId!,
        dateCreated: new Date()
      };

      this.productService.addReviewToProduct(this.productId, review).subscribe({
        next: (res) => {
          console.log('Review added successfully');
          this.modalCtrl.dismiss(res);
        },
        error: (err) => {
          this.displayError('An error occurred while adding the review. Please try again later.');
          console.error('Error adding review', err);
        }
      });
    } else {
      this.displayError('Please ensure all fields are filled out correctly.');
      console.error('Form is invalid or productId is undefined');
    }
  }

  private displayError(message: string) {
    // Implement a method to display the error message to the user
    alert(message); // You can replace this with a more user-friendly UI notification
  }
}
