import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AssignedShiftsPageRoutingModule } from './assigned-shifts-routing.module';

import { AssignedShiftsPage } from './assigned-shifts.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssignedShiftsPageRoutingModule
  ],
  declarations: [AssignedShiftsPage]
})
export class AssignedShiftsPageModule {}
