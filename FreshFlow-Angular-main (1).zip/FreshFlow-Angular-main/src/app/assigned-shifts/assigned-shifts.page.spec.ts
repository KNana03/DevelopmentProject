import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AssignedShiftsPage } from './assigned-shifts.page';

describe('AssignedShiftsPage', () => {
  let component: AssignedShiftsPage;
  let fixture: ComponentFixture<AssignedShiftsPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignedShiftsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
