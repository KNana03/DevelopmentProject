import { Component, OnInit } from '@angular/core';
import { ShiftAssignmentService } from '../services/shift-assignment.service';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-assigned-shifts',
  templateUrl: './assigned-shifts.page.html',
  styleUrls: ['./assigned-shifts.page.scss'],
})
export class AssignedShiftsPage implements OnInit {
  assignedShifts: any[] = [];
  staffIdInput: number = 0;
  staffIdError: string = "";
  isStaffIdValid: boolean = false;

  constructor(
    private shiftAssignmentService: ShiftAssignmentService,
    private router: Router,
    private navCtrl: NavController
  ) { }

  ngOnInit() {
    this.loadAllAssignedShifts();
  }

  navigateToViewShift() {
    // Navigate to the View Shift page
    this.navCtrl.navigateForward('/view-shift');
  }

  validateStaffId() {
    if (!this.staffIdInput || this.staffIdInput <= 0) {
      this.staffIdError = 'Please enter a valid staff ID.';
      this.isStaffIdValid = false;
    } else {
      this.staffIdError = '';
      this.isStaffIdValid = true;
    }
  }

  loadAssignedShifts() {
    this.validateStaffId(); // Ensure the staff ID is validated before loading shifts
    if (!this.isStaffIdValid) {
      return;
    }

    this.shiftAssignmentService.getAssignedShifts(this.staffIdInput).subscribe({
      next: (data) => {
        this.assignedShifts = data;
      },
      error: (error) => {
        console.error('Error fetching assigned shifts:', error);
        alert('Error fetching assigned shifts');
      },
      complete: () => {
        console.log('Fetching assigned shifts completed');
      }
    });
  }

  loadAllAssignedShifts() {
    this.shiftAssignmentService.getAllAssignedShifts().subscribe({
      next: (data) => {
        this.assignedShifts = data;
      },
      error: (error) => {
        console.error('Error loading all assigned shifts', error);
        alert('Error loading all assigned shifts');
      }
    });
  }

  removeAssignedShift(assignmentId: number) {
    if (confirm(`Are you sure you want to remove this assigned shift?`)) {
      this.shiftAssignmentService.removeAssignedShift(assignmentId).subscribe({
        next: () => {
          this.loadAllAssignedShifts(); // Refresh the shifts list
        },
        error: error => {
          console.error('Error removing assigned shift:', error);
        }
      });
    }
  }

}
