import { Component } from '@angular/core';
import { AuthserviceService } from '../services/authservice.service';
import { AlertController, NavController, PopoverController } from '@ionic/angular'; // Import PopoverController
 // Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-verify-otp',
  templateUrl: './verify-otp.page.html',
  styleUrls: ['./verify-otp.page.scss'],
})
export class VerifyOtpPage {
  email: string = '';
  otp: string = '';

  constructor(
    private authService: AuthserviceService,
    private alertController: AlertController,
    private navCtrl: NavController,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  ngOnInit() {
    if (history.state.email) {
      this.email = history.state.email;
    }
  }

  async verifyOTP() {
    if (!this.otp.trim()) {
      await this.showAlert('Error', 'Please enter the OTP.');
      return;
    }

    const verifyOTPData = {
      email: this.email,
      otp: this.otp
    };

    this.authService.verifyOTP(verifyOTPData).subscribe(
      async (response: any) => {
        await this.showAlert('Success', response.message);
        this.navCtrl.navigateForward('/reset-password', { state: { email: this.email } });
      },
      async (error) => {
        const errorMessage = this.getErrorMessage(error);
        await this.showAlert('Error', errorMessage);
      }
    );
  }

  private async showAlert(header: string, message: string) {
    const alert = await this.alertController.create({
      header,
      message,
      buttons: ['OK']
    });
    await alert.present();
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Invalid OTP. Please try again.';
    } else if (error.status === 500) {
      return 'Server error occurred. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return error.error.message || 'OTP verification failed. Please try again.';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'otp':
        hintMessage = "Enter the OTP you received via email.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      cssClass: 'custom-popover',  
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
