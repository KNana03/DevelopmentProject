import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Category } from 'src/app/Model/category';
import { ProductService } from 'src/app/services/product.service';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.scss'],
})
export class AddCategoryComponent implements OnInit {
  @Output() categoryAdded = new EventEmitter<Category>();

  newCategory: Category = {
    categoryId: 0,
    name: '',
    description: '',
    dateCreated: new Date(),
    dateModified: new Date(),
    isActive: true,
    isDeleted: false
  };

  constructor(
    private productService: ProductService,
    private snackBar: MatSnackBar,
    private modalController: ModalController
  ) { }

  ngOnInit() { }

  addCategory() {
    if (!this.newCategory.name.trim()) {
      this.snackBar.open('Category name is required', 'Close', {
        duration: 3000,
      });
      return;
    }

    if (!this.newCategory.description.trim()) {
      this.snackBar.open('Category description is required', 'Close', {
        duration: 3000,
      });
      return;
    }

    this.productService.addCategory(this.newCategory).subscribe(
      (category) => {
        console.log('Category added successfully:', category);
        this.snackBar.open('Category added successfully', 'Close', {
          duration: 3000,
        });
        this.categoryAdded.emit(category);
        this.modalController.dismiss(category);
        this.resetForm();
      },
      (error) => {
        const errorMessage = this.getErrorMessage(error);
        console.error('Error adding category', error);
        this.snackBar.open(errorMessage, 'Close', {
          duration: 3000,
        });
      }
    );
  }

  resetForm() {
    this.newCategory = {
      categoryId: 0,
      name: '',
      description: '',
      dateCreated: new Date(),
      dateModified: new Date(),
      isActive: true,
      isDeleted: false
    };
  }

  private getErrorMessage(error: any): string {
    if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else if (error.error && error.error.message) {
      return error.error.message;
    } else {
      return 'An unexpected error occurred. Please try again later.';
    }
  }
}
