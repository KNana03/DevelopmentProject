import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ReporthelpmodalPageRoutingModule } from './reporthelpmodal-routing.module';

import { ReporthelpmodalPage } from './reporthelpmodal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReporthelpmodalPageRoutingModule
  ],
  declarations: [ReporthelpmodalPage]
})
export class ReporthelpmodalPageModule {}
