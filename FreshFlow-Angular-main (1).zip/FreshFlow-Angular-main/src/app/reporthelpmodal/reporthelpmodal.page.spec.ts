import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReporthelpmodalPage } from './reporthelpmodal.page';

describe('ReporthelpmodalPage', () => {
  let component: ReporthelpmodalPage;
  let fixture: ComponentFixture<ReporthelpmodalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ReporthelpmodalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
