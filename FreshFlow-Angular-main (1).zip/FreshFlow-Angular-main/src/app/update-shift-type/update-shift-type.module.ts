import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UpdateShiftTypePageRoutingModule } from './update-shift-type-routing.module';

import { UpdateShiftTypePage } from './update-shift-type.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    UpdateShiftTypePageRoutingModule
  ],
  declarations: [UpdateShiftTypePage]
})
export class UpdateShiftTypePageModule {}
