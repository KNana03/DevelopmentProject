import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UpdateShiftTypePage } from './update-shift-type.page';

const routes: Routes = [
  {
    path: '',
    component: UpdateShiftTypePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UpdateShiftTypePageRoutingModule {}
