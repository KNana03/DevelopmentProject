import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdateShiftTypePage } from './update-shift-type.page';

describe('UpdateShiftTypePage', () => {
  let component: UpdateShiftTypePage;
  let fixture: ComponentFixture<UpdateShiftTypePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateShiftTypePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
