import { Component, OnInit } from '@angular/core';
import { ShiftType } from '../Model/shift-type';
import { Router } from '@angular/router';
import { ShiftTypeService } from '../services/shift-type.service';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-update-shift-type',
  templateUrl: './update-shift-type.page.html',
  styleUrls: ['./update-shift-type.page.scss'],
})
export class UpdateShiftTypePage implements OnInit {
  shiftType: ShiftType = {
    id: 0,
    name: '',
    description: ''
  };

  constructor(
    private router: Router,
    private shiftTypeService: ShiftTypeService,
    private navCtrl: NavController
  ) { }

  ngOnInit(): void {
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      const state = navigation.extras.state as { [key: string]: any };
      if (state['shiftType']) {
        this.shiftType = state['shiftType'];
      }
    }
  }

  navigateToViewShiftType() {
    this.navCtrl.navigateForward(['/view-shift-type']); // Adjust navigation path as needed
  }

  updateShiftType() {
    if (!this.isFormValid()) {
      alert('Please fill in all required fields.');
      return;
    }

    this.shiftTypeService.updateShiftType(this.shiftType.id, this.shiftType).subscribe(
      response => {
        console.log('Shift type updated successfully', response);
        alert('Shift type updated successfully');
        this.navigateToViewShiftType();
      },
      error => {
        console.error('Shift type update failed', error);
        alert(this.getErrorMessage(error));
      }
    );
  }

  private isFormValid(): boolean {
    return this.shiftType.name.trim() !== '' && this.shiftType.description.trim() !== '';
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to update shift type due to invalid input. Please check the fields and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while updating the shift type. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }
}
