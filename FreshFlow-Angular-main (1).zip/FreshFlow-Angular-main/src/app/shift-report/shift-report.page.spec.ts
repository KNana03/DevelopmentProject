import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ShiftReportPage } from './shift-report.page';

describe('ShiftReportPage', () => {
  let component: ShiftReportPage;
  let fixture: ComponentFixture<ShiftReportPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ShiftReportPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
