import { Component, OnInit } from '@angular/core';
import { ShiftService } from '../services/shift.service';
import { StaffService } from '../services/staff.service';
import { SalesService } from '../services/sales.service';
import { StaffAttendanceService } from '../services/staff-attendance.service';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { BASE64_LOGO } from '../app.constants';
import { AuthserviceService } from '../services/authservice.service';
import { ShiftAssignmentService } from '../services/shift-assignment.service'; // Import the ShiftAssignmentService
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;

interface Shift {
  id: number;
  name: string;
  checkInTime?: string;
  checkOutTime?: string;
  date: string;
  shiftType: { name: string; description: string };
}

interface Staff {
  id: number;
  firstName: string;
  lastName: string;
}

interface ShiftWithDetails extends Shift {
  salesCount: string;
  staffName: string;
  totalHours: string;
  formattedCheckInTime: string;
  formattedCheckOutTime: string;
}

@Component({
  selector: 'app-shift-report',
  templateUrl: './shift-report.page.html',
  styleUrls: ['./shift-report.page.scss'],
})
export class ShiftReportPage implements OnInit {
  shifts: ShiftWithDetails[] = [];
  groupedShifts: { [key: string]: ShiftWithDetails[] } = {};
  currentUserName: string = '';

  constructor(
    private shiftService: ShiftService,
    private staffService: StaffService,
    private salesService: SalesService,
    private staffAttendanceService: StaffAttendanceService,
    private shiftAssignmentService: ShiftAssignmentService, // Inject the ShiftAssignmentService
    private navCtrl: NavController,
    private router: Router,
    private authService: AuthserviceService
  ) { }

  ngOnInit() {
    this.fetchShiftReport();
    this.currentUserName = this.authService.getCurrentUserName();
  }
  openHelp() {
    this.navCtrl.navigateForward('/reporthelpmodal');
  }
  fetchShiftReport(): void {
    forkJoin({
      shifts: this.shiftService.getShiftReport(),
      staffs: this.staffService.getAllStaffs(),
      sales: this.salesService.getSales(),
      assignments: this.shiftAssignmentService.getAllAssignedShifts() // Fetch all assigned shifts
    }).subscribe({
      next: ({ shifts, staffs, sales, assignments }) => {
        this.shifts = shifts.map((shift: Shift) => {
          const staffSales = sales.filter(sale => sale.shiftId === shift.id);
          const salesCount = this.convertToString(staffSales.length);

          // Find the assigned staff member for this shift
          const assignedStaff = assignments.find(assignment => assignment.shiftId === shift.id);
          const staff = assignedStaff ? staffs.find(staff => staff.id === assignedStaff.staffId) : null;
          const staffName = staff ? `${staff.firstName} ${staff.lastName}` : 'Unknown';

          const formattedCheckInTime = shift.checkInTime ? this.extractTime(shift.checkInTime) : 'Not Checked In';
          const formattedCheckOutTime = shift.checkOutTime ? this.extractTime(shift.checkOutTime) : 'Not Checked Out';
          const totalHours = (shift.checkInTime && shift.checkOutTime) ? this.calculateTotalHours(shift.checkInTime, shift.checkOutTime) : '0h 0m';

          return {
            ...shift,
            salesCount,
            staffName,
            totalHours,
            formattedCheckInTime,
            formattedCheckOutTime
          };
        });

        this.groupShiftsByType();
      },
      error: error => {
        console.error('Error fetching shift report:', error);
      },
    });
  }

  extractTime(dateTime: string): string {
    const date = new Date(dateTime);
    if (isNaN(date.getTime())) {
      console.warn('Invalid date:', dateTime);
      return 'Invalid Time';
    }
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  }

  calculateTotalHours(startTime: string, endTime: string): string {
    const start = new Date(startTime).getTime();
    const end = new Date(endTime).getTime();

    if (isNaN(start) || isNaN(end) || start >= end) {
      console.warn('Invalid start or end timestamp:', startTime, endTime);
      return '0h 0m';
    }

    const diffMs = end - start;
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    return `${hours}h ${minutes}m`;
  }

  groupShiftsByType(): void {
    this.groupedShifts = this.shifts.reduce((acc: { [key: string]: ShiftWithDetails[] }, shift: ShiftWithDetails) => {
      const shiftType = shift.shiftType.name || 'Unknown Shift Type';
      if (!acc[shiftType]) {
        acc[shiftType] = [];
      }
      acc[shiftType].push(shift);
      return acc;
    }, {});
  }

  generatePdf(): void {
    const documentDefinition = this.getDocumentDefinition();

    try {
      pdfMake.createPdf(documentDefinition).download('Shift_Report.pdf');
    } catch (error) {
      console.error('Error creating PDF:', error);
    }
  }

  convertToString(value: any): string {
    if (isNaN(value) || value == null) {
      console.warn('Invalid number detected, converting to "0":', value);
      return '0';
    }
    return value.toString();
  }

  getDocumentDefinition() {
    return {
      pageOrientation: 'landscape',
      content: [
        {
          columns: [
            {
              image: BASE64_LOGO,
              width: 100,
            },
            {
              stack: [
                { text: 'AB Fresh Wholesalers', bold: true, fontSize: 14, alignment: 'right' },
                { text: 'Store 204a, Hall 2, JHB Fresh Produce Market', alignment: 'right' },
                { text: 'City Deep, Johannesburg, 2049', alignment: 'right' },
                { text: `Generated by: ${this.currentUserName}`, style: 'subheader', alignment: 'right' },
                { text: `Report Date: ${new Date().toLocaleDateString()}`, style: 'subheader', alignment: 'right' },
              ],
              alignment: 'right'
            }
          ],
          margin: [0, 0, 0, 20]
        },
        {
          text: 'Shift Report',
          style: 'header',
          alignment: 'center'
        },
        ...Object.keys(this.groupedShifts).map(shiftType => this.getShiftsTable(shiftType, this.groupedShifts[shiftType]))
      ],
      styles: {
        header: {
          fontSize: 22,
          bold: true,
          margin: [0, 10, 0, 20]
        },
        tableHeader: {
          bold: true,
          fontSize: 11,
          color: 'black'
        },
        tableBody: {
          fontSize: 10
        },
        shiftTypeHeader: {
          fontSize: 16,
          bold: true,
          margin: [0, 10, 0, 10],
          color: 'blue'
        }
      }
    };
  }

  getShiftsTable(shiftType: string, shifts: ShiftWithDetails[]) {
    // Calculate totals
    const totalHours = shifts.reduce((sum, shift) => {
      const [hours, minutes] = shift.totalHours.split('h').map(part => parseInt(part, 10));
      return sum + (hours * 60) + minutes;
    }, 0);
    const totalSales = shifts.reduce((sum, shift) => sum + parseInt(shift.salesCount, 10), 0);

    const totalFormattedHours = `${Math.floor(totalHours / 60)}h ${totalHours % 60}m`;

    return [
      {
        text: `${shiftType} Shift`,
        style: 'shiftTypeHeader'
      },
      {
        table: {
          widths: ['auto', '*', 'auto', 'auto', 'auto', 'auto'],
          body: [
            [
              { text: 'Name', style: 'tableHeader' },
              { text: 'Check-In Time', style: 'tableHeader' },
              { text: 'Check-Out Time', style: 'tableHeader' },
              { text: 'Total Hours', style: 'tableHeader' },
              { text: 'Number of Sales', style: 'tableHeader' },
              { text: 'Staff Name', style: 'tableHeader' }
            ],
            ...shifts.map(shift => [
              { text: shift.name || 'N/A', style: 'tableBody' },
              { text: shift.formattedCheckInTime || 'Not Checked In', style: 'tableBody' },
              { text: shift.formattedCheckOutTime || 'Not Checked Out', style: 'tableBody' },
              { text: shift.totalHours || '0h 0m', style: 'tableBody' },
              { text: shift.salesCount || '0', style: 'tableBody' },
              { text: shift.staffName || 'Unknown', style: 'tableBody' }
            ]),
            // Add totals row
            [
              { text: 'Total', colSpan: 3, alignment: 'right', style: 'tableHeader' }, '', '',
              { text: totalFormattedHours, style: 'tableHeader' },
              { text: totalSales.toString(), style: 'tableHeader' },
              ''
            ]
          ]
        }
      }
    ];
  }

}
