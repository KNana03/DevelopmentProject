import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ProductsPage } from './products.page';
import { AddProductComponent } from 'src/app/products/add-product/add-product.component';
import { LowStockComponent } from 'src/app/products/low-stock/low-stock.component';
import { BestPerformingComponent } from 'src/app/products/best-performing/best-performing.component';
import { AllProductsPage } from 'src/app/products/all-products/all-products.page';
import { AddBrandComponent } from 'src/app/brands/add-brand/add-brand.component';

const routes: Routes = [
  {
    path: '',
    component: ProductsPage,
    children: [
      {
        path: '',
        redirectTo: 'all-products',
        pathMatch: 'full'
      },
      {
        path: 'all-products',
        component: AllProductsPage
      },
      {
        path: 'add-product',
        component: AddProductComponent
      },
      {
        path: 'low-stock',
        component: LowStockComponent
      },
      {
        path: 'best-performing',
        component: BestPerformingComponent
      },
      {
        path: 'add-brand',
        component: AddBrandComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductsPageRoutingModule { }
