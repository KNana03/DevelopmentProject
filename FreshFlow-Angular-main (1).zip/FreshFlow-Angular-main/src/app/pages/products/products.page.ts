import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'app-products',
  templateUrl: './products.page.html',
  styleUrls: ['./products.page.scss'],
})
export class ProductsPage implements OnInit {
  selectedSegment: string = 'all-products';

  constructor(private router: Router, private navCtrl: NavController) { }

  ngOnInit() {
  }
  navigateToSupplier() {
    this.router.navigate(['/view-supplier']);
  }

  navigateToStaff() {
    this.router.navigate(['/view-staffprofile']);
  }

  navigateToCreateProfile() {
    this.navCtrl.navigateForward('/create-profile');
  }

  navigateToOrder() {
    this.router.navigate(['/view-orders']);
  }

  navigateToViewProfile() {
    this.router.navigate(['/view-profile']);
  }

  navigateToProduct() {
    this.router.navigate(['/all-products']);
  }

  navigateToHome() {
    this.router.navigate(['/home']);
  }

  navigateToOrderReport() {
    this.router.navigate(['/order-report']);
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }

  navigateToSettings() {
    this.router.navigate(['/settings']);
  }

  navigateToInventory() {
    this.router.navigate(['/view-inventory'])
  }


  navigateToViewCheckin() {
    //Navigate to the View Shift page
    this.navCtrl.navigateForward('/check-in');
  }

  navigateToViewCheckout() {
    //Navigate to the View Shift page
    this.navCtrl.navigateForward('/check-out');
  }
  navigateToViewSale() {
    //Navigate to the View Shift page
    this.navCtrl.navigateForward('/view-sales');
  }
  navigateToViewShift() {
    //Navigate to the View Shift page
    this.navCtrl.navigateForward('/view-shift');
  }
  navigateToViewInventoryReport() {
    this.navCtrl.navigateForward('/view-inventory-report')
  }
}
