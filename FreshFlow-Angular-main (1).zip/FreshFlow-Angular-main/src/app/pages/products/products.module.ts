import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

import { ProductsPageRoutingModule } from './products-routing.module';
import { ProductsPage } from './products.page';

import { AddProductComponent } from 'src/app/products/add-product/add-product.component';
import { LowStockComponent } from 'src/app/products/low-stock/low-stock.component';
import { BestPerformingComponent } from 'src/app/products/best-performing/best-performing.component';
import { AddBrandComponent } from 'src/app/brands/add-brand/add-brand.component';
import { AddCategoryComponent } from 'src/app/categories/add-category/add-category.component';
import { ViewProductComponent } from 'src/app/products/view-product/view-product.component';
import { AllProductsPageModule } from "../../products/all-products/all-products.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    ProductsPageRoutingModule,
    AllProductsPageModule
  ],
  declarations: [
    ProductsPage,
    AddProductComponent,
    LowStockComponent,
    BestPerformingComponent,
    AddBrandComponent,
    AddCategoryComponent,
    ViewProductComponent
  ]
})
export class ProductsPageModule { }
