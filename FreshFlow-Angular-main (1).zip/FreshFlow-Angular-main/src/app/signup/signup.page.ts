import { Component } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { AuthserviceService } from '../services/authservice.service';
import { Router } from '@angular/router';
import { PopoverController } from '@ionic/angular'; // Import PopoverController
 // Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage {
  user = {
    UserName: '',
    Email: '',
    Password: '',
    alertMessage: ''
  };

  constructor(
    private router: Router,
    private authService: AuthserviceService,
    private toastController: ToastController,
    private alertController: AlertController,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  async register() {
    this.authService.register(this.user).subscribe(
      async (response) => {
        await this.showAlert('Success', response.message);
        this.router.navigate(['/login']);
      },
      async (error) => {
        const errorMessage = this.getErrorMessage(error);
        await this.showAlert('Error', errorMessage);
      }
    );
  }

  private async showAlert(header: string, message: string) {
    const alert = await this.alertController.create({
      header,
      message,
      buttons: ['OK']
    });
    await alert.present();
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Invalid input. Please check your details and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return error.error.message || 'Registration failed. Please try again.';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'username':
        hintMessage = "Enter a unique username that will be used to log in.";
        break;
      case 'email':
        hintMessage = "Enter a valid email address for account recovery.";
        break;
      case 'password':
        hintMessage = "Choose a strong password with at least 8 characters.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
