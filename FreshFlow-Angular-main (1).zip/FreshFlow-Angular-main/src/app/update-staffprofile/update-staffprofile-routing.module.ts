import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UpdateStaffprofilePage } from './update-staffprofile.page';

const routes: Routes = [
  {
    path: '',
    component: UpdateStaffprofilePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UpdateStaffprofilePageRoutingModule {}
