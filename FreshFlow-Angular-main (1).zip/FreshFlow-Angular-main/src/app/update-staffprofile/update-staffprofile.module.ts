import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UpdateStaffprofilePageRoutingModule } from './update-staffprofile-routing.module';

import { UpdateStaffprofilePage } from './update-staffprofile.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    UpdateStaffprofilePageRoutingModule
  ],
  declarations: [UpdateStaffprofilePage]
})
export class UpdateStaffprofilePageModule {}
