import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdateStaffprofilePage } from './update-staffprofile.page';

describe('UpdateStaffprofilePage', () => {
  let component: UpdateStaffprofilePage;
  let fixture: ComponentFixture<UpdateStaffprofilePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateStaffprofilePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
