import { Component, OnInit } from '@angular/core';
import { NavController, PopoverController } from '@ionic/angular'; // Import PopoverController
import { Staffs } from '../Model/staff';
import { StaffService } from '../services/staff.service';
import { Router } from '@angular/router';
 // Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-staffprofile.page.html',
  styleUrls: ['./update-staffprofile.page.scss'],
})
export class UpdateStaffprofilePage implements OnInit {

  staffData: Staffs = {
    id: 0,
    username: '',
    email: '',
    firstName: '',
    lastName: '',
    password: '',
    profilePhoto: ''
  };
  confirmPassword = '';

  constructor(
    private navCtrl: NavController,
    private router: Router,
    private staffService: StaffService,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  ngOnInit() {
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      const state = navigation.extras.state as { [key: string]: any };
      if (state['staff']) {
        this.staffData = state['staff'];
      }
    }
  }

  navigateToStaff() {
    this.navCtrl.navigateForward(['/view-staffprofile']);
  }

  updateStaff() {
    if (!this.isFormValid()) {
      alert('Please fill in all required fields.');
      return;
    }

    if (this.staffData.password !== this.confirmPassword) {
      alert('Passwords do not match!');
      return;
    }

    this.staffService.updateStaffProfile(this.staffData.id.toString(), this.staffData).subscribe(
      response => {
        console.log('Profile updated successfully', response);
        alert('Profile updated successfully');
        this.navigateToStaff();
      },
      error => {
        console.error('Profile update failed', error);
        alert(this.getErrorMessage(error));
      }
    );
  }

  private isFormValid(): boolean {
    return (
      this.staffData.username.trim() !== '' &&
      this.staffData.email.trim() !== '' &&
      this.staffData.firstName.trim() !== '' &&
      this.staffData.lastName.trim() !== '' &&
      this.staffData.password.trim() !== ''
    );
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to update profile due to invalid email. Please check the fields and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while updating the profile. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'username':
        hintMessage = "Enter a unique username for the staff member.";
        break;
      case 'email':
        hintMessage = "Enter a valid email address.";
        break;
      case 'firstName':
        hintMessage = "Enter the staff member's first name.";
        break;
      case 'lastName':
        hintMessage = "Enter the staff member's last name.";
        break;
      case 'password':
        hintMessage = "Enter a password with at least 6 characters.";
        break;
      case 'confirmPassword':
        hintMessage = "Re-enter the password for confirmation.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
