import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController, AlertController } from '@ionic/angular';
import { AuthserviceService } from '../services/authservice.service'; // Update the path as needed
import { ProductService } from '../services/product.service';
@Component({
  selector: 'app-settings',
  templateUrl: './settings.page.html',
  styleUrls: ['./settings.page.scss'],
})
export class SettingsPage implements OnInit {
  darkMode: boolean = false;
  notificationAlerts: boolean = true;
  autoSync: boolean = true;
  selectedLanguage: string = 'en';

  constructor(
    private router: Router,
    private navCtrl: NavController,
    private authService: AuthserviceService,
    private alertController: AlertController,
    private productService: ProductService
  ) { }

  ngOnInit() {
    // Initialize default settings if needed
    this.applyDarkMode();
  }

  applyDarkMode() {
    document.body.classList.toggle('dark', this.darkMode);
  }

  applyAutoSync() {
    if (this.autoSync) {
      console.log('Auto Sync Enabled');
    } else {
      console.log('Auto Sync Disabled');
    }
  }
  navigateToSession() {
    this.router.navigate(['/session-config']);
  }
  navigateToSupplier() {
    this.router.navigate(['/view-supplier']);
  }

  navigateToStaff() {
    this.router.navigate(['/view-staffprofile']);
  }

  navigateToCreateProfile() {
    this.navCtrl.navigateForward('/create-profile');
  }

  navigateToOrder() {
    this.router.navigate(['/view-orders']);
  }

  navigateToViewProfile() {
    this.router.navigate(['/view-profile']);
  }

  navigateToProduct() {
    this.router.navigate(['/view-product']);
  }

  navigateToHome() {
    this.router.navigate(['/home']);
  }

  navigateToOrderReport() {
    this.router.navigate(['/order-report']);
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }

  navigateToSettings() {
    this.router.navigate(['/settings']);
  }

  navigateToInventory() {
    this.router.navigate(['/view-inventory']);
  }

  navigateToViewCheckin() {
    this.navCtrl.navigateForward('/check-in');
  }

  navigateToViewCheckout() {
    this.navCtrl.navigateForward('/check-out');
  }

  navigateToViewSale() {
    this.navCtrl.navigateForward('/view-sales');
  }

  navigateToViewShift() {
    this.navCtrl.navigateForward('/view-shift');
  }

  navigateToViewInventoryReport() {
    this.navCtrl.navigateForward('/view-inventory-report');
  }

  updatePassword() {
    this.navCtrl.navigateForward('/update-password');
    console.log('Update password clicked');
  }

  async createRole() {
    const alert = await this.alertController.create({
      header: 'Create Role',
      inputs: [
        {
          name: 'roleName',
          type: 'text',
          placeholder: 'Role Name'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Create',
          handler: data => {
            this.authService.createRole(data.roleName).subscribe(
              response => {
                this.presentAlert('Success', 'Role created successfully');
              },
              error => {
                this.presentAlert('Error', error.message);
              }
            );
          }
        }
      ]
    });

    await alert.present();
  }

  async readUserRoles() {
    const alert = await this.alertController.create({
      header: 'View User Roles',
      inputs: [
        {
          name: 'emailAddress',
          type: 'text',
          placeholder: 'Email Address'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'View',
          handler: data => {
            this.authService.getUserRoles(data.emailAddress).subscribe(
              response => {
                this.presentAlert('Roles', `Roles for ${data.emailAddress}: ${response.roles.join(', ')}`);
              },
              error => {
                this.presentAlert('Error', error.message);
              }
            );
          }
        }
      ]
    });

    await alert.present();
  }

  async updateUserRole() {
    const alert = await this.alertController.create({
      header: 'Update User Role',
      inputs: [
        {
          name: 'emailAddress',
          type: 'text',
          placeholder: 'Email Address'
        },
        {
          name: 'oldRoleName',
          type: 'text',
          placeholder: 'Old Role Name'
        },
        {
          name: 'newRoleName',
          type: 'text',
          placeholder: 'New Role Name'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Update',
          handler: data => {
            this.authService.updateUserRole(data.emailAddress, data.oldRoleName, data.newRoleName).subscribe(
              response => {
                this.presentAlert('Success', 'User role updated successfully');
              },
              error => {
                this.presentAlert('Error', error.message);
              }
            );
          }
        }
      ]
    });

    await alert.present();
  }

  async deleteUserRole() {
    const alert = await this.alertController.create({
      header: 'Delete User Role',
      inputs: [
        {
          name: 'emailAddress',
          type: 'text',
          placeholder: 'Email Address'
        },
        {
          name: 'roleName',
          type: 'text',
          placeholder: 'Role Name'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Delete',
          handler: data => {
            this.authService.deleteUserRole(data.emailAddress, data.roleName).subscribe(
              response => {
                this.presentAlert('Success', 'User role deleted successfully');
              },
              error => {
                this.presentAlert('Error', error.message);
              }
            );
          }
        }
      ]
    });

    await alert.present();
  }
  async assignRole() {
    const alert = await this.alertController.create({
      header: 'Assign Role',
      inputs: [
        {
          name: 'emailAddress',
          type: 'text',
          placeholder: 'Email Address'
        },
        {
          name: 'roleName',
          type: 'text',
          placeholder: 'Role Name'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Assign',
          handler: data => {
            this.authService.assignRole(data.emailAddress, data.roleName).subscribe(
              response => {
                this.presentAlert('Success', 'Role assigned successfully');
              },
              error => {
                this.presentAlert('Error', error.message);
              }
            );
          }
        }
      ]
    });

    await alert.present();
  }

  async viewVAT() {
    this.productService.getVAT().subscribe(
      response => {
        this.presentAlert('VAT', `Current VAT: ${response.map(vat => `ID: ${vat.vatId}, Amount: ${vat.amount}, Date: ${vat.date}`).join('\n')}`);
      },
      error => {
        this.presentAlert('Error', error.message);
      }
    );
  }

  async updateVAT() {
    const alert = await this.alertController.create({
      header: 'Update VAT',
      inputs: [
        {
          name: 'id',
          type: 'number',
          placeholder: 'VAT ID'
        },
        {
          name: 'amount',
          type: 'number',
          placeholder: 'Amount'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Update',
          handler: data => {
            this.productService.updateVAT(data.id, data.amount).subscribe(
              response => {
                this.presentAlert('Success', 'VAT updated successfully');
              },
              error => {
                this.presentAlert('Error', error.message);
              }
            );
          }
        }
      ]
    });

    await alert.present();
  }

  async presentAlert(header: string, message: string) {
    const alert = await this.alertController.create({
      header,
      message,
      buttons: ['OK']
    });

    await alert.present();
  }
}
