import { Component, OnInit, HostListener } from '@angular/core';
import { ShiftAssignmentService } from '../services/shift-assignment.service';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss'],
})
export class CalendarComponent implements OnInit {
  assignedShifts: any[] = [];
  currentMonth: number;
  currentYear: number;
  daysInMonth: any[] = [];
  daysOfWeek: string[] = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  months: string[] = [];
  years: number[] = [];
  selectedDate: number | null = null;
  shiftsForSelectedDay: any[] = [];
  selectedShift: any | null = null;

  constructor(private shiftAssignmentService: ShiftAssignmentService) {
    const savedMonth = localStorage.getItem('currentMonth');
    const savedYear = localStorage.getItem('currentYear');

    this.currentMonth = savedMonth ? parseInt(savedMonth) : new Date().getMonth();
    this.currentYear = savedYear ? parseInt(savedYear) : new Date().getFullYear();

    const currentYear = new Date().getFullYear();
    this.years = Array.from({ length: 10 }, (_, i) => currentYear - 5 + i);
  }

  ngOnInit() {
    this.initializeYears();
    this.initializeMonths();
    this.loadAssignedShifts();
  }

  initializeYears(): void {
    const currentYear = new Date().getFullYear();
    this.years = Array.from({ length: 10 }, (_, i) => currentYear - 5 + i);
  }

  initializeMonths(): void {
    this.months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
  }

  loadAssignedShifts(): void {
    this.shiftAssignmentService.getAllAssignedShifts().subscribe({
      next: (data: any[]) => {
        this.assignedShifts = data;
        this.renderCalendar(); // Ensure the calendar is rendered after shifts are loaded
      },
      error: (error) => {
        console.error('Error fetching assigned shifts', error);
      }
    });
  }

  renderCalendar(): void {
    const firstDay = new Date(this.currentYear, this.currentMonth, 1).getDay();
    const lastDate = new Date(this.currentYear, this.currentMonth + 1, 0).getDate();
    this.daysInMonth = [];

    for (let i = 0; i < firstDay; i++) {
      this.daysInMonth.push({ date: '', shifts: [] });
    }

    for (let i = 1; i <= lastDate; i++) {
      const shiftsForDay = this.getShiftsForDay(this.currentYear, this.currentMonth + 1, i);
      this.daysInMonth.push({ date: i, shifts: shiftsForDay });
    }
  }

  getShiftsForDay(year: number, month: number, day: number): any[] {
    return this.assignedShifts.filter(assignment => {
      const shiftDate = new Date(assignment.shift.startTime);
      return (
        shiftDate.getFullYear() === year &&
        shiftDate.getMonth() + 1 === month &&
        shiftDate.getDate() === day
      );
    }).map(assignment => ({
      ...assignment.shift,
      staffName: assignment.staff.firstName
    }));
  }

  selectDay(date: number, event: MouseEvent): void {
    event.stopPropagation(); // Prevent triggering closeShiftDetails when selecting a day
    this.selectedDate = date;

    // Load shifts for the selected day
    this.filterShiftsForSelectedDay();
  }

  filterShiftsForSelectedDay(): void {
    if (this.selectedDate !== null) {
      this.shiftsForSelectedDay = this.getShiftsForDay(this.currentYear, this.currentMonth + 1, this.selectedDate);
    }
  }

  closeShiftDetails(): void {
    this.selectedShift = null;
    this.selectedDate = null;
    this.shiftsForSelectedDay = [];
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    if (!target.closest('.calendar-container') && !target.closest('.shift-details-container')) {
      this.closeShiftDetails();
    }
  }

  changeMonth(direction: number): void {
    this.currentMonth += direction;
    if (this.currentMonth > 11) {
      this.currentMonth = 0;
      this.currentYear++;
    } else if (this.currentMonth < 0) {
      this.currentMonth = 11;
      this.currentYear--;
    }

    // Save the selected month and year in local storage
    localStorage.setItem('currentMonth', this.currentMonth.toString());
    localStorage.setItem('currentYear', this.currentYear.toString());

    // Rerender the calendar for the new month/year
    this.renderCalendar();
  }

  changeYear(): void {
    // Save the selected year in local storage
    localStorage.setItem('currentYear', this.currentYear.toString());

    // Rerender the calendar for the new year
    this.renderCalendar();
  }
}
