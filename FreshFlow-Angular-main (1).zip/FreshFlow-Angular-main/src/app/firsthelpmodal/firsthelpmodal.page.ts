import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'app-firsthelpmodal',
  templateUrl: './firsthelpmodal.page.html',
  styleUrls: ['./firsthelpmodal.page.scss'],
})
export class FirsthelpmodalPage implements OnInit {


  constructor(private navCtrl: NavController) { }

  ngOnInit() {
    const iframe = document.getElementById('help-frame') as HTMLIFrameElement;
    iframe.onload = () => {
      iframe.contentWindow?.postMessage('add-supplier', '*');
    };
  }

  dismissModal() {
    this.navCtrl.back();
  }
}

