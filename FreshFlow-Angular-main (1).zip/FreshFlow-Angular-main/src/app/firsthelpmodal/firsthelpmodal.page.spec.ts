import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FirsthelpmodalPage } from './firsthelpmodal.page';

describe('FirsthelpmodalPage', () => {
  let component: FirsthelpmodalPage;
  let fixture: ComponentFixture<FirsthelpmodalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(FirsthelpmodalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
