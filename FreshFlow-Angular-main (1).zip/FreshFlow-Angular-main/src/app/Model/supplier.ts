export interface Suppliers {
    id: number;
    Name: string;
    Location: string;
    Email: string;
}
