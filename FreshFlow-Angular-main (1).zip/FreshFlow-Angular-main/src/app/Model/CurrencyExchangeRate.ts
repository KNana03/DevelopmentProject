export interface CurrencyExchangeRate {
    currencyExchangeRateId?: number;  // Optional ID
    currencyCode: string;  // The currency code (e.g., USD, EUR)
    exchangeRate: number;  // The conversion rate to Rands
    date: Date;  // The date when the exchange rate was applied
    orderId?: number;  // The ID of the related Order (optional if it’s nullable on the backend)
}
