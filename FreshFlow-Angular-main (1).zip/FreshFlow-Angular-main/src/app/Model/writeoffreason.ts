export interface Writeoffreasons {
    id: number;
    reason: string;
}
