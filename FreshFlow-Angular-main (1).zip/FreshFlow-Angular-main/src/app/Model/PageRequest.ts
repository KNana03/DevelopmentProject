interface PageRequest {
    pageName: string;
    requestCount: number;
    userName: string;
}
