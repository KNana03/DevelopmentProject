export interface PaymentType {
    id: number;
    type: string;  // "Cash" or "Card"
}
