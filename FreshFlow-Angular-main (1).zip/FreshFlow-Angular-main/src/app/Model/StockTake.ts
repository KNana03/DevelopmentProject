export interface StockTake {
    id: number;
    orderId: number;
    quantity: number;
    price: number;
    date: Date;
}
