export interface Product {
  productId: number;
  quantityOnHand: number;
  price: number;
  image: string;
  brandId: number;
  categoryId: number;
  category: {
    categoryId: number;
    name: string;
    description: string;
    dateCreated: string;
    dateModified: string;
    isActive: boolean;
    isDeleted: boolean;
  };
  brand: {
    brandId: number;
    name: string;
    description: string;
    dateCreated: string;
    dateModified: string;
    isActive: boolean;
    isDeleted: boolean;
  };
  name: string;
  description: string;
  dateCreated: string;
  dateModified: string;
  isActive: boolean;
  isDeleted: boolean;
}