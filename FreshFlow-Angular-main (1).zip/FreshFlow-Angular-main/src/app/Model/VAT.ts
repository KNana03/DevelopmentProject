export interface VAT {
    vatId: number;
    amount: number;
    date: Date;
}
