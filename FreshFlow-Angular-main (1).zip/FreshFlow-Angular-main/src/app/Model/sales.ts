import { Inventories } from './inventory';
import { Shift } from './shift';
import { Staffs } from './staff';

export interface Sales {
  id: number;
  staffId: number;
  shiftId: number;
  inventoryId: number;
  quantity: number;
  date: Date;
  // Assuming there's a price for each sale, if not adjust accordingly
  price?: number;
}

