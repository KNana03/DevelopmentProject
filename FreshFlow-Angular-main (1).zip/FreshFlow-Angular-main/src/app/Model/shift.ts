export interface Shift {
  id: number;
  name: string;
  startTime: string;
  endTime: string;
  checkInTime?: string; // Optional property
  checkOutTime?: string; // Optional property
  date: string;
  shiftTypeId: number,
  typeName: string
}
