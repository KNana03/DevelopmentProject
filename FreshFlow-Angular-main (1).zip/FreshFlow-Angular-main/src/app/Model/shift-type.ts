export interface ShiftType {
  id: number;
  name: string;
  description: string;
}