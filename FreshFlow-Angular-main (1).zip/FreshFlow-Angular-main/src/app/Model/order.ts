export interface Order {
    id?: number; // Optional because it's assigned by the backend
    type: string;
    quantity: number;
    price: number;
    isPaid: boolean;
    orderDate?: Date;
    receivedDate?: Date | null;

}
