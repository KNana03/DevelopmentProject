export class Discount {
    isDiscountApplied: boolean = false;
    percentage: number = 10;  // Fixed discount percentage of 10%
}
