export interface CustomerReview {
    customerReviewId: number;
    review: string;
    rating: number;
    productId: number;
    dateCreated: Date;
}
