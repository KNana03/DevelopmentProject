export interface Warehouse {
    warehouseId: number;
    name: string;
    country: {
        countryId: number;
        name: string;
    };
    state: {
        stateId: number;
        name: string;
    };
    city: {
        cityId: number;
        name: string;
    };
}