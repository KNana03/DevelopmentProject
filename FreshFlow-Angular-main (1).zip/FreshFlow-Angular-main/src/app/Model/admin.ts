export interface Admins {
    id: string;
    username: string;
    email: string;
    firstName: string;
    lastName: string;
    password: string;
    profilePhoto?: string;
}