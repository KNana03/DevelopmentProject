export interface ReturnedStock {
    id?: number; // Make 'id' optional
    inventoryId: number;
    staffId: number;
    saleId: number;
    quantity: number;
    reason: string;
    returnDate: Date;
  }
  