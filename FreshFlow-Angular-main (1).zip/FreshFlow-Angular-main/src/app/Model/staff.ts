export interface Staffs {
    id: number;
    username: string;
    email: string;
    firstName: string;
    lastName: string;
    password: string;
    profilePhoto?: string;
    fiveDigitCode?: string; // Optional field for five-digit code
}
