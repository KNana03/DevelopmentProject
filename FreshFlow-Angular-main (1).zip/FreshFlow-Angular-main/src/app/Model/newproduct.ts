export interface ProductViewModel {
  name: string;
  description: string;
  price: number;
  quantityOnHand: number;
  image: string;
  brand: number;
  category: number;
}