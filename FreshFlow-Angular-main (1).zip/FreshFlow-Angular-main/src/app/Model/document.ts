export interface Document {
    id: number;          // Unique identifier for the document
    supplierId: number;  // ID of the supplier associated with this document
    fileName: string;    // Name of the file (e.g., "Invoice001.pdf")
    fileType: string;    // Type of the document (e.g., "Invoice", "Receipt")
    filePath: string;    // Path or URL to access the document
}
