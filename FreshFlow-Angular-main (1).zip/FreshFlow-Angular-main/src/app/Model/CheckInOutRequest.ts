export interface CheckInOutRequest {
    staffId: number;
    fiveDigitCode: string;
}
