import { Writeoffreasons } from './writeoffreason';

export interface Inventories {
    id: number;
    productId: number;
    warehouseId: number;
    typeId: number;
    name: string;
    quantity: number;
    inventoryType: string;
    writeOffReasons?: string[]; // Make it optional
}
