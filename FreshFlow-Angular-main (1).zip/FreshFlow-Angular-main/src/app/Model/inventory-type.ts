export interface InventoryType {
    id: number;
    typeName: string;
    description: string;
}
