import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';
import { GeminiService } from './services/gemini.service';
import * as pdfjsLib from 'pdfjs-dist';
import Tesseract from 'tesseract.js';
import { HttpClient } from '@angular/common/http';

interface Message {
  text?: string;
  isUser: boolean;
  file?: {
    url: string;
    type: string;
  };
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  chatbotVisible = false;
  @ViewChild('pdfCanvas', { static: false }) pdfCanvas!: ElementRef; // Reference to the canvas for PDF rendering
  selectedFile: File | null = null;
  extractedText: string = '';
  filePreview: string | ArrayBuffer | null = null;
  messages: Message[] = [];
  prompt: string = '';
  response: string = '';

  constructor(
    private navCtrl: NavController,
    public router: Router,
    private geminiService: GeminiService,
    private http: HttpClient
  ) {}

  // Toggle Chatbot visibility
  toggleChatbot() {
    this.chatbotVisible = !this.chatbotVisible;
  }

  // Check if the current page is an auth page
  isAuthPage(): boolean {
    const authPages = ['/login', '/signup', '/forgot-password', '/verify-otp'];
    return authPages.includes(this.router.url);
  }

  // Handle file selection (image upload)
  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      this.previewFile(file); // Preview the file
    }
  }

  // Preview the selected file and identify image content
  previewFile(file: File) {
    const reader = new FileReader();

    reader.onload = () => {
      const fileUrl = reader.result as string;

      // Push the image as a user message
      this.messages.push({
        isUser: true,
        file: {
          url: fileUrl,
          type: file.type,
        },
      });

      // Call image recognition function
      if (file.type.startsWith('image/')) {
        this.identifyImage(file); // If it's an image, perform image recognition
      } else if (file.type === 'application/pdf') {
        this.previewPdf(file); // If it's a PDF, render the first page
      }
    };

    reader.readAsDataURL(file);
  }

  // Identify the content of the image using Google Cloud Vision API
  async identifyImage(file: File) {
    const apiKey = 'AIzaSyBGjeWAquSb26PYnQqnvwsJ4DFjr9t-dTk';
    const reader = new FileReader();

    reader.onloadend = async () => {
      const base64Image = reader.result?.toString().split(',')[1]; // Get base64 string of the image

      const requestBody = {
        requests: [
          {
            image: { content: base64Image },
            features: [{ type: 'LABEL_DETECTION', maxResults: 5 }],
          },
        ],
      };

      try {
        // Send POST request to Google Vision API
        const response = await this.http
          .post(`https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`, requestBody)
          .toPromise();
        const result: any = response;

        const labels = result.responses[0].labelAnnotations.map((label: any) => label.description);

        // Display the detected labels as the bot's response
        this.getBotResponse(`I detected: ${labels.join(', ')}`);
      } catch (error) {
        console.error('Error in image recognition:', error);
      }
    };

    reader.readAsDataURL(file);
  }

  // Simulate or fetch bot response for text messages
  getBotResponse(message: string) {
    setTimeout(() => {
      this.messages.push({ text: `Bot received: ${message}`, isUser: false });
    }, 1000);
  }

  // Display PDF preview (render the first page)
  async previewPdf(file: File) {
    const reader = new FileReader();
    reader.onload = async (e: any) => {
      const pdfData = new Uint8Array(e.target.result);
      const pdf = await pdfjsLib.getDocument({ data: pdfData }).promise;
      const page = await pdf.getPage(1);
      const viewport = page.getViewport({ scale: 1.5 });

      const canvas = this.pdfCanvas.nativeElement;
      const context = canvas.getContext('2d')!;
      canvas.height = viewport.height;
      canvas.width = viewport.width;

      await page.render({ canvasContext: context, viewport: viewport }).promise;
    };
    reader.readAsArrayBuffer(file);
  }

  // Extract text from the selected file (image or PDF)
  async extractTextFromFile(selectedFile: File) {
    if (this.selectedFile) {
      const reader = new FileReader();
      reader.onload = async (event: any) => {
        const content = event.target.result;
        let text = '';

        if (this.selectedFile!.type === 'application/pdf') {
          // Extract text from PDF
          const pdf = await pdfjsLib.getDocument({ data: content }).promise;
          const numPages = pdf.numPages;

          for (let i = 1; i <= numPages; i++) {
            const page = await pdf.getPage(i);
            const textContent = await page.getTextContent();
            text += textContent.items.map((item: any) => item.str).join(' ') + ' ';
          }
        } else if (this.selectedFile!.type.startsWith('image/')) {
          // Extract text from image using OCR
          const result = await Tesseract.recognize(content, 'eng');
          text = result.data.text;
        }

        this.prompt = text; // Set the extracted text as the prompt
      };

      reader.readAsArrayBuffer(this.selectedFile);
    }
  }

  // Submit the prompt and file after extraction
  async sendData() {
    if (this.prompt) {
      this.messages.push({ text: this.prompt, isUser: true });

      try {
        const response = await this.geminiService.handleChatbotQuestion(this.prompt);
        this.messages.push({ text: response, isUser: false });
      } catch (error) {
        this.messages.push({ text: 'An error occurred while processing your question.', isUser: false });
      }

      this.prompt = ''; // Clear the input after sending
    }
  }

  // Navigation methods
  navigateToSupplier() {
    this.router.navigate(['/view-supplier']);
  }

  navigateToStaff() {
    this.router.navigate(['/view-staffprofile']);
  }

  navigateToCreateProfile() {
    this.navCtrl.navigateForward('/create-profile');
  }

  navigateToOrder() {
    this.router.navigate(['/view-orders']);
  }

  navigateToViewProfile() {
    this.router.navigate(['/view-profile']);
  }

  navigateToProduct() {
    this.router.navigate(['/products']);
  }

  navigateToHome() {
    this.router.navigate(['/home']);
  }

  navigateToOrderReport() {
    this.router.navigate(['/order-report']);
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }

  navigateToSettings() {
    this.router.navigate(['/settings']);
  }

  navigateToInventory() {
    this.router.navigate(['/view-inventory']);
  }

  navigateToViewCheckin() {
    this.navCtrl.navigateForward('/check-in');
  }

  navigateToViewCheckout() {
    this.navCtrl.navigateForward('/check-out');
  }

  navigateToViewSale() {
    this.navCtrl.navigateForward('/view-sales');
  }

  navigateToViewShift() {
    this.navCtrl.navigateForward('/view-shift');
  }

  navigateToViewInventoryReport() {
    this.navCtrl.navigateForward('/view-inventory-report');
  }

  navigateToViewTurnoverReport() {
    this.navCtrl.navigateForward('/inventory-turnover-report');
  }

  navigateToShiftReport() {
    this.navCtrl.navigateForward('/shift-report');
  }

  navigateToViewSalesReport() {
    this.navCtrl.navigateForward('/sales-report');
  }

  navigateToAuditTrail() {
    this.navCtrl.navigateForward('/audit-trails');
  }

  openHelp() {
    this.navCtrl.navigateForward('helpdetail');
  }
}
