import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';
import { InventoryType } from '../Model/inventory-type';
import { InventoryTypeService } from '../services/inventory-type.service';

@Component({
  selector: 'app-update-inventory-type',
  templateUrl: './update-inventory-type.page.html',
  styleUrls: ['./update-inventory-type.page.scss'],
})
export class UpdateInventorytypePage implements OnInit {
  inventorytypeData: InventoryType = {
    id: 0,
    typeName: '',
    description: '',
  };

  constructor(
    private navCtrl: NavController,
    private router: Router,
    private inventorytypeService: InventoryTypeService
  ) { }

  ngOnInit() {
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      const state = navigation.extras.state as { [key: string]: any };
      if (state['inventorytype']) {
        this.inventorytypeData = state['inventorytype'];
      }
    }
  }

  navigateToViewInventoryType() {
    this.navCtrl.navigateForward(['/view-inventory-type']);
  }

  updateInventoryType() {
    if (!this.inventorytypeData.id || !this.inventorytypeData.typeName || !this.inventorytypeData.description) {
      alert('Please fill in all fields.');
      return;
    }

    console.log('Updating inventory type with data:', this.inventorytypeData);

    this.inventorytypeService.updateInventoryType(this.inventorytypeData.id, {
      id: this.inventorytypeData.id,
      typeName: this.inventorytypeData.typeName,
      description: this.inventorytypeData.description,
    }).subscribe(
      response => {
        console.log('Inventory type updated successfully', response);
        this.navigateToViewInventoryType();
        alert('Inventory type updated successfully');
      },
      error => {
        console.error('Update error', error);
        alert('Inventory type could not be updated. Please try again.');
      }
    );
  }
}
