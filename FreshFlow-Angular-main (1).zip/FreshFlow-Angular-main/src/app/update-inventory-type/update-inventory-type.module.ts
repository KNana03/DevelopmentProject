import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UpdateInventorytypePageRoutingModule } from './update-inventory-type-routing.module';

import { UpdateInventorytypePage } from './update-inventory-type.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    UpdateInventorytypePageRoutingModule
  ],
  declarations: [UpdateInventorytypePage]
})
export class UpdateInventorytypePageModule {}