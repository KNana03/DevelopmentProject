import { Component, Input } from '@angular/core';
import { ModalController } from '@ionic/angular';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { BASE64_LOGO } from '../app.constants';

(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;

interface LogEntry {
  timestamp: Date | string | undefined;
  userName: string;
  pageName: string;
  action: string;
  success: boolean;
  details: string;
}

@Component({
  selector: 'app-activity-log',
  templateUrl: './activity-log.component.html',
  styleUrls: ['./activity-log.component.scss'],
})
export class ActivityLogComponent {
  @Input() logEntries: LogEntry[] = [];
  userColors: { [key: string]: string } = {};

  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
    this.assignUserColors();
  }

  assignUserColors() {
    const distinctUsers = [...new Set(this.logEntries.map(entry => entry.userName))];
    distinctUsers.forEach((user, index) => {
      this.userColors[user] = this.getRandomColor(index);
    });
  }

  getRandomColor(index: number): string {
    const colors = [
      'rgba(255, 99, 132, 1)',
      'rgba(54, 162, 235, 1)',
      'rgba(255, 206, 86, 1)',
      'rgba(75, 192, 192, 1)',
      'rgba(153, 102, 255, 1)',
      'rgba(255, 159, 64, 1)',
    ];
    return colors[index % colors.length];
  }

  dismiss() {
    this.modalCtrl.dismiss();
  }

  downloadPDF() {
    try {
      const documentDefinition = {
        content: [
          {
            image: BASE64_LOGO,
            width: 150,
            alignment: 'center',
            margin: [0, 0, 0, 20]
          },
          { text: 'Activity Log', style: 'header' },
          ...this.logEntries.flatMap(entry => {
            let timestamp = 'Unknown Time';
            if (entry.timestamp) {
              try {
                const date = new Date(entry.timestamp);
                timestamp = date.toLocaleString();
              } catch {
                timestamp = 'Invalid Date';
              }
            }
            return [
              { text: `${timestamp} - ${entry.userName}`, style: 'subheader' },
              { text: entry.pageName, margin: [0, 0, 0, 10] },
              { text: entry.details, margin: [0, 0, 0, 20] }
            ];
          })
        ],
        styles: {
          header: {
            fontSize: 18,
            bold: true,
            margin: [0, 0, 0, 10]
          },
          subheader: {
            fontSize: 14,
            bold: true,
            margin: [0, 10, 0, 5]
          }
        }
      };

      pdfMake.createPdf(documentDefinition).download(
        'ActivityLog.pdf',
        function () {
          console.log('PDF generated and download started.');
        },
        function (error: unknown) {
          console.error('Error generating PDF:', error);
        }
      );

    } catch (error) {
      console.error('An error occurred while generating the PDF:', error);
    }
  }
}
