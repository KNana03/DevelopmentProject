import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AssignShiftPage } from './assign-shift.page';

const routes: Routes = [
  {
    path: '',
    component: AssignShiftPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AssignShiftPageRoutingModule {}
