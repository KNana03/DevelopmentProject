import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AssignShiftPageRoutingModule } from './assign-shift-routing.module';

import { AssignShiftPage } from './assign-shift.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssignShiftPageRoutingModule
  ],
  declarations: [AssignShiftPage]
})
export class AssignShiftPageModule {}
