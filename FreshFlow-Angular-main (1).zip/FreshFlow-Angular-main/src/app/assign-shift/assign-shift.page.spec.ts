import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AssignShiftPage } from './assign-shift.page';

describe('AssignShiftPage', () => {
  let component: AssignShiftPage;
  let fixture: ComponentFixture<AssignShiftPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignShiftPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
