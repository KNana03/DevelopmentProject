import { Component, OnInit } from '@angular/core';
import { ShiftAssignmentService } from '../services/shift-assignment.service';
import { NavController, AlertController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';
import { StaffService } from '../services/staff.service'; // Assuming you have a StaffService

@Component({
  selector: 'app-assign-shift',
  templateUrl: './assign-shift.page.html',
  styleUrls: ['./assign-shift.page.scss'],
})
export class AssignShiftPage implements OnInit {
  staffId: number = 0;
  shiftId: number = 0;
  message: string = "";
  errorMessage: string = "";
  isValidStaffId: boolean = true;
  staffList: any[] = []; // Assuming staff is an array of objects with id and name

  constructor(
    private shiftAssignmentService: ShiftAssignmentService,
    private navCtrl: NavController,
    private alertController: AlertController,
    private staffService: StaffService, // Inject StaffService
    private route: ActivatedRoute // Inject ActivatedRoute to get route params
  ) { }

  ngOnInit() {
    this.fetchStaffList();
    this.route.queryParams.subscribe(params => {
      if (params['shiftId']) {
        this.shiftId = +params['shiftId'];
      }
    });
  }

  fetchStaffList() {
    this.staffService.getAllStaffs().subscribe({
      next: data => {
        this.staffList = data;
        console.log('Staff List:', this.staffList);  // Log to verify data
      },
      error: error => {
        console.error('Error fetching staff list:', error);
      }
    });
  }


  validateStaffId() {
    this.isValidStaffId = this.staffId > 0;
  }

  async assignShift() {
    this.validateStaffId();

    if (this.isValidStaffId && this.shiftId > 0) {
      this.shiftAssignmentService.assignShift(this.staffId, this.shiftId).subscribe({
        next: async () => {
          const successAlert = await this.alertController.create({
            header: 'Success',
            message: 'Shift assigned successfully!',
            buttons: [
              {
                text: 'OK',
                handler: () => {
                  this.navCtrl.navigateForward(['/assigned-shifts']); // Adjust the path as needed
                }
              }
            ]
          });

          await successAlert.present();
        },
        error: async (error) => {
          this.errorMessage = this.getErrorMessage(error);

          const errorAlert = await this.alertController.create({
            header: 'Error',
            message: this.errorMessage,
            buttons: ['OK']
          });

          await errorAlert.present();
        }
      });
    } else {
      this.errorMessage = 'Please select a valid Staff ID and ensure a Shift ID is set.';

      const validationAlert = await this.alertController.create({
        header: 'Validation Error',
        message: this.errorMessage,
        buttons: ['OK']
      });

      await validationAlert.present();
    }
  }

  private getErrorMessage(error: any): string {
    if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else if (error.error && error.error.message) {
      return error.error.message;
    } else {
      return 'An unexpected error occurred. Please try again later.';
    }
  }
}
