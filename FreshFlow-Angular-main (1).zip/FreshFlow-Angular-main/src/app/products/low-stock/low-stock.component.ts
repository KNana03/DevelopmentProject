import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product.service';
import { Product } from 'src/app/Model/products';

@Component({
  selector: 'app-low-stock',
  templateUrl: './low-stock.component.html',
  styleUrls: ['./low-stock.component.scss'],
})
export class LowStockComponent implements OnInit {
  lowStockProducts: Product[] = [];

  constructor(private productService: ProductService) { }

  ngOnInit() {
    this.getLowStockProducts();
  }

  getLowStockProducts() {
    this.productService.getLowStockProducts().subscribe(
      (products) => {
        this.lowStockProducts = products;
      },
      (error) => {
        console.error('Error fetching low stock products:', error);
      }
    );
  }

  getProductImage(image: string): string {
    return image ? `data:image/jpeg;base64,${image}` : 'assets/imgs/placeholder.png';
  }
}
