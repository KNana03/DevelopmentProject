import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { Product } from 'src/app/Model/products';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { FormControl } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators'
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-all-products',
  templateUrl: './all-products.component.html',
  styleUrls: ['./all-products.component.scss'],
})
export class AllProductsComponent implements OnInit {
  products: Product[] = [];

  isNav: boolean = true;
  displayedColumns: string[] = ['image', 'name', 'price', 'brand', 'productType', 'description'];
  ds!: MatTableDataSource<Product>;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  filterFormControl = new FormControl('');
  filteredData: Product[] = [];

  constructor(
    private navCtrl: NavController,
    private router: Router,
    private registerService: ProductService
  ) { }

  ngOnInit() {
    this.ds = new MatTableDataSource<Product>(this.products);
    this.ds.sort = this.sort;
    this.ds.paginator = this.paginator;
    this.filterFormControl.valueChanges
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(filterValue => {
        this.applyFilter(filterValue);
      });
    this.getProducts();
  }

  applyFilter(filterValue: string | null): void {
    filterValue = filterValue?.trim().toLowerCase() || '';
    this.ds.filter = filterValue;
  }

  getProducts(): void {
    this.registerService.getProducts()
      .subscribe(products => {
        this.products = products;
        this.ds.data = this.products; // Update ds with the filtered products
        this.ds.paginator?.firstPage(); // Resets the paginator to first page
      });
  }

  GetImageSource(imageData: string): string {
    return `data:image/jpeg;base64,${imageData}`;
  }

  clearFilter(): void {
    this.filterFormControl.setValue('');
  }

}