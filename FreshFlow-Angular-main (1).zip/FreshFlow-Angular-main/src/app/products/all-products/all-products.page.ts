import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Product } from 'src/app/Model/products';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { ProductService } from 'src/app/services/product.service';
import { ViewProductComponent } from '../view-product/view-product.component';
import { Router, RouteReuseStrategy } from '@angular/router';
import { NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { saveAs } from 'file-saver'; // You will need to install the file-saver package
@Component({
  selector: 'app-all-products',
  templateUrl: './all-products.page.html',
  styleUrls: ['./all-products.page.scss'],
})
export class AllProductsPage implements OnInit {
  products: Product[] = [];
  ds!: MatTableDataSource<Product>;
  filterFormControl = new FormControl('');

  constructor(
    private modalCtrl: ModalController,
    private productService: ProductService,
    private router: Router,
    private navCtrl: NavController,
    private http: HttpClient // Inject the HttpClient service
  ) { }

  ngOnInit() {
    this.ds = new MatTableDataSource<Product>(this.products);
    this.filterFormControl.valueChanges
      .pipe(debounceTime(0), distinctUntilChanged())
      .subscribe(filterValue => {
        this.applyFilter(filterValue);
      });
    this.getProducts();
  }
  openHelp() {
    this.navCtrl.navigateForward('/fifthhelpmodal');
  }
  applyFilter(filterValue: string | null): void {
    filterValue = filterValue?.trim().toLowerCase() || '';
    this.ds.filter = filterValue;
  }

  getProducts(): void {
    this.productService.getProducts()
      .subscribe(products => {
        this.products = products.map(product => {
          return {
            ...product
          };
        });
        this.ds.data = this.products;
        this.ds.filterPredicate = (data: Product, filter: string) => data.name.toLowerCase().includes(filter);
      });
  }

  async openProductModal(product: Product) {
    const modal = await this.modalCtrl.create({
      component: ViewProductComponent,
      componentProps: { product }
    });

    modal.onDidDismiss().then((result) => {
      if (result.data) {
        if (result.data.delete) {
          this.removeProduct(result.data.productId);
        } else {
          this.updateProduct(result.data);
        }
      }
    });

    await modal.present();
  }

  updateProduct(updatedProduct: Product) {
    const index = this.products.findIndex(p => p.productId === updatedProduct.productId);
    if (index !== -1) {
      this.products[index] = updatedProduct;
      this.ds.data = [...this.products]; // Ensure the data source is updated
    }
  }

  removeProduct(productId: number) {
    const index = this.products.findIndex(p => p.productId === productId);
    if (index !== -1) {
      this.products.splice(index, 1);
      this.ds.data = [...this.products]; // Ensure the data source is updated
    }
  }


  GetImageSource(imageData: string): string {
    return `data:image/jpeg;base64,${imageData}`;
  }
  exportToExcel() {
    this.http.get('https://localhost:7261/api/Product/ExportProductsToExcel', { responseType: 'blob' })
      .subscribe((blob) => {
        saveAs(blob, 'Products.xlsx');
      }, error => {
        console.error('Error exporting to Excel', error);
      });
  }
  navigateToSupplier() {
    this.router.navigate(['/view-supplier']);
  }

  navigateToStaff() {
    this.router.navigate(['/view-staffprofile']);
  }

  navigateToCreateProfile() {
    this.navCtrl.navigateForward('/create-profile');
  }

  navigateToOrder() {
    this.router.navigate(['/view-orders']);
  }

  navigateToViewProfile() {
    this.router.navigate(['/view-profile']);
  }

  navigateToProduct() {
    this.router.navigate(['/all-products']);
  }

  navigateToHome() {
    this.router.navigate(['/home']);
  }

  navigateToOrderReport() {
    this.router.navigate(['/order-report']);
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }

  navigateToSettings() {
    this.router.navigate(['/settings']);
  }

  navigateToInventory() {
    this.router.navigate(['/view-inventory'])
  }
}