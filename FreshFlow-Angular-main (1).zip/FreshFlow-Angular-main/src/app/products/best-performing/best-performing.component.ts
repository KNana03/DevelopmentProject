import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-best-performing',
  templateUrl: './best-performing.component.html',
  styleUrls: ['./best-performing.component.scss'],
})
export class BestPerformingComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
