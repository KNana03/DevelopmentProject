import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, AlertController } from '@ionic/angular';
import { ProductViewModel } from 'src/app/Model/newproduct';
import { Brand } from 'src/app/Model/brand';
import { Category } from 'src/app/Model/category';
import { ProductService } from 'src/app/services/product.service';
import { AddBrandComponent } from 'src/app/brands/add-brand/add-brand.component';
import { AddCategoryComponent } from 'src/app/categories/add-category/add-category.component';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss'],
})
export class AddProductComponent implements OnInit {
  brands: Brand[] = [];
  filteredBrands: Brand[] = [];
  categories: Category[] = [];
  selectedCategoryId: number = 0;

  product: ProductViewModel = {
    name: '',
    description: '',
    quantityOnHand: 0,
    price: 0,
    image: '',
    brand: 0,
    category: 0
  };

  constructor(
    private productService: ProductService,
    private modalController: ModalController,
    private alertController: AlertController,
    private router: Router
  ) { }

  ngOnInit() {
    this.loadBrands();
    this.loadCategories();
  }

  loadBrands() {
    this.productService.getBrands().subscribe({
      next: (brands) => {
        this.brands = brands;
        this.updateFilteredBrands();
      },
      error: (error) => {
        console.error('Error loading brands', error);
        alert('Failed to load brands. Please try again later.');
      }
    });
  }

  loadCategories() {
    this.productService.getCategories().subscribe({
      next: (categories) => {
        this.categories = categories;
      },
      error: (error) => {
        console.error('Error loading categories', error);
        alert('Failed to load categories. Please try again later.');
      }
    });
  }

  updateFilteredBrands() {
    this.filteredBrands = this.brands.filter(brand => brand.categoryId === this.selectedCategoryId);
  }

  handleImageInput(event: any): void {
    const file: File = event.target.files[0];
    this.convertImageToBase64(file);
  }

  convertImageToBase64(file: File): void {
    const reader: FileReader = new FileReader();
    reader.onloadend = () => {
      const base64String: string = reader.result as string;
      const base64Data: string = base64String.split(',')[1];
      this.product.image = base64Data;
    };
    reader.readAsDataURL(file);
  }

  async addProduct(): Promise<void> {
    this.productService.addProduct(this.product).subscribe({
      next: async (response) => {
        console.log('Product Added Successfully', response);
        await this.showSuccessAlert(); // Show success alert
        this.router.navigate(['/pages/products']);
      },
      error: (error) => {
        console.error('Product was not added', error);
        alert(this.getErrorMessage(error));
      }
    });
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to add product due to invalid input. Please check the details and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while adding the product. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }

  async showSuccessAlert(): Promise<void> {
    const alert = await this.alertController.create({
      header: 'Success',
      message: 'The product has been added successfully!',
      buttons: ['OK']
    });

    await alert.present();
  }

  async addNewBrand() {
    const modal = await this.modalController.create({
      component: AddBrandComponent
    });

    modal.onDidDismiss().then((result) => {
      if (result.data) {
        this.brands.push(result.data);
        this.updateFilteredBrands();
      }
    });

    return await modal.present();
  }

  async addNewCategory() {
    const modal = await this.modalController.create({
      component: AddCategoryComponent
    });

    modal.onDidDismiss().then((result) => {
      if (result.data) {
        this.categories.push(result.data);
      }
    });

    return await modal.present();
  }

  onCategoryChange(event: any) {
    this.selectedCategoryId = event.detail.value;
    this.updateFilteredBrands();
  }
}
