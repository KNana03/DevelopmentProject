import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalController, AlertController } from '@ionic/angular';
import { Product } from 'src/app/Model/products';
import { ProductService } from 'src/app/services/product.service';

import { AddReviewPage } from 'src/app/add-review/add-review.page';
import { ViewReviewsPage } from 'src/app/view-reviews/view-reviews.page';

@Component({
  selector: 'app-view-product',
  templateUrl: './view-product.component.html',
  styleUrls: ['./view-product.component.scss'],
})
export class ViewProductComponent implements OnInit {
  @Input() product: Product | null = null;
  productForm: FormGroup;
  imageSrc: string | ArrayBuffer | null = null;
  brands: any[] = [];
  categories: any[] = [];

  constructor(
    private fb: FormBuilder,
    private modalCtrl: ModalController,
    private alertCtrl: AlertController,
    private productService: ProductService
  ) {
    this.productForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      price: [0, Validators.required],
      quantityOnHand: [0, Validators.required],
      image: [''],
      brand: [null, Validators.required],
      category: [null, Validators.required]
    });
  }

  ngOnInit() {
    if (this.product) {
      this.productForm.patchValue({
        name: this.product.name,
        description: this.product.description,
        price: this.product.price,
        quantityOnHand: this.product.quantityOnHand,
        image: this.product.image,
        brand: this.product.brandId,
        category: this.product.categoryId
      });

      if (this.product.image) {
        this.imageSrc = `data:image/jpeg;base64,${this.product.image}`;
      }
    }

    this.loadBrands();
    this.loadCategories();
  }

  loadBrands() {
    this.productService.getBrands().subscribe(brands => {
      this.brands = brands;
    });
  }

  loadCategories() {
    this.productService.getCategories().subscribe(categories => {
      this.categories = categories;
    });
  }

  dismiss() {
    this.modalCtrl.dismiss();
  }

  saveChanges() {
    if (this.productForm.valid) {
      const updatedProduct: Product = {
        ...this.product!,
        ...this.productForm.value
      };

      this.productService.updateProduct(updatedProduct.productId, updatedProduct)
        .subscribe({
          next: () => {
            this.modalCtrl.dismiss(updatedProduct);
          },
          error: (err: HttpErrorResponse) => {
            console.error('Error updating product:', err);
            if (err.error && err.error.errors) {
              console.log('Validation errors:', err.error.errors);
            }
          }
        });
    }
  }

  async deleteProduct() {
    const alert = await this.alertCtrl.create({
      header: 'Confirm Delete',
      message: 'Are you sure you want to delete this product?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel'
        },
        {
          text: 'Delete',
          handler: () => {
            if (this.product) {
              this.productService.deleteProduct(this.product.productId)
                .subscribe({
                  next: () => {
                    console.log('Product deleted successfully');
                    this.modalCtrl.dismiss({ delete: true, productId: this.product!.productId });
                  },
                  error: (err: HttpErrorResponse) => {
                    console.error('Error deleting product:', err);
                    this.presentAlert('Error', 'There was an error deleting the product.');
                  }
                });
            }
          }
        }
      ]
    });
    await alert.present();
  }

  async presentAlert(header: string, message: string) {
    const alert = await this.alertCtrl.create({
      header: header,
      message: message,
      buttons: ['OK']
    });

    await alert.present();
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imageSrc = reader.result;
        const base64String = (reader.result as string).split(',')[1];
        this.productForm.patchValue({ image: base64String });
      };
      reader.readAsDataURL(file);
    }
  }

  async openAddReview() {
    if (this.product) {
      const modal = await this.modalCtrl.create({
        component: AddReviewPage,
        componentProps: { productId: this.product.productId }
      });
      await modal.present();
    } else {
      console.error('Product is null or undefined');
    }
  }

  async openViewReviews() {
    if (this.product) {
      const modal = await this.modalCtrl.create({
        component: ViewReviewsPage,
        componentProps: { productId: this.product.productId }
      });
      await modal.present();
    } else {
      console.error('Product is null or undefined');
    }
  }

}