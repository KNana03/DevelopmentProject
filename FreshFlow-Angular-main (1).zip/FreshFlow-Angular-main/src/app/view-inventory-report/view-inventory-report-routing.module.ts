import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ViewInventoryReportPage } from './view-inventory-report.page';

const routes: Routes = [
  {
    path: '',
    component: ViewInventoryReportPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ViewInventoryReportPageRoutingModule {}
