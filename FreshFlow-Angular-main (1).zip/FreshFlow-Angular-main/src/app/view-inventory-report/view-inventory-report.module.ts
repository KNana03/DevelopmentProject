import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ViewInventoryReportPageRoutingModule } from './view-inventory-report-routing.module';

import { ViewInventoryReportPage } from './view-inventory-report.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ViewInventoryReportPageRoutingModule
  ],
  declarations: [ViewInventoryReportPage]
})
export class ViewInventoryReportPageModule {}
