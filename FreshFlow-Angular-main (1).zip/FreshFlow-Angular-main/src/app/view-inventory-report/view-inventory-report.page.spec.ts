import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ViewInventoryReportPage } from './view-inventory-report.page';

describe('ViewInventoryReportPage', () => {
  let component: ViewInventoryReportPage;
  let fixture: ComponentFixture<ViewInventoryReportPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewInventoryReportPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
