import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuditTrailsPage } from './audit-trails.page';

const routes: Routes = [
  {
    path: '',
    component: AuditTrailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AuditTrailsPageRoutingModule {}
