import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { BASE64_LOGO } from '../app.constants';

@Component({
  selector: 'app-audit-trails',
  templateUrl: './audit-trails.page.html',
  styleUrls: ['./audit-trails.page.scss'],
})
export class AuditTrailsPage implements OnInit {
  audits: any[] = [];
  filteredAuditTrails: any[] = [];
  actions: string[] = [];
  users: string[] = [];

  selectedAction: string = '';
  selectedUser: string = '';
  selectedDate: string = '';
  currentUser: string = '';

  searchQuery: string = '';  // Added for search functionality
  noResultsFound: boolean = false;  // Flag to track if no results are found

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem('user') || '{}').username || 'Unknown';
    this.loadAuditTrails();
  }

  loadAuditTrails() {
    this.http.get<any[]>('https://localhost:7261/api/AuditTrail/get-audit-trails')
      .subscribe((data) => {
        // Combine fetched data with dummy data
        const combinedData = this.addDummyData(data);

        // Update the username dynamically based on the current user for new logs
        combinedData.forEach(audit => {
          if (!audit.userName || audit.userName === 'Unknown' || audit.userName === 'Anonymous') {
            audit.userName = this.currentUser;
          }
        });

        // Sort the combined data by timestamp in descending order
        combinedData.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

        this.audits = combinedData;
        this.actions = [...new Set(combinedData.map(audit => audit.event))];
        this.users = [...new Set(combinedData.map(audit => audit.userName))];
        this.filterAuditTrails();
      }, error => {
        console.error('Error fetching audit trails:', error);
      });
  }

  addDummyData(data: any[]): any[] {
    // Dummy data to simulate audit trails
    const dummyData = [
      {
        id: 1,
        event: 'Login',
        userName: 'KNana01',
        entityId: 0,
        description: 'KNana01 logged in',
        timestamp: new Date('2024-08-24T12:00:00'),
        oldValue: '',
        newValue: 'Username: KNana01',
        ipAddress: '::1'
      },
      {
        id: 2,
        event: 'Create Staff',
        userName: 'KNana02',
        entityId: 1001,
        description: 'Created new staff member',
        timestamp: new Date('2024-08-24T12:15:00'),
        oldValue: '',
        newValue: 'Staff ID: 1001, Name: John Doe',
        ipAddress: '::1'
      },
      {
        id: 3,
        event: 'Create Order',
        userName: 'KNana01',
        entityId: 2001,
        description: 'Created new order',
        timestamp: new Date('2024-08-24T12:30:00'),
        oldValue: '',
        newValue: 'Order ID: 2001, Product: Widget',
        ipAddress: '::1'
      },
      {
        id: 4,
        event: 'Create Shift',
        userName: 'KNana03',
        entityId: 3001,
        description: 'Created new shift',
        timestamp: new Date('2024-08-24T12:45:00'),
        oldValue: '',
        newValue: 'Shift ID: 3001, Time: 09:00 - 17:00',
        ipAddress: '::1'
      },
      {
        id: 5,
        event: 'View Products',
        userName: 'KNana02',
        entityId: 4001,
        description: 'Viewed products',
        timestamp: new Date('2024-08-24T13:00:00'),
        oldValue: '',
        newValue: '',
        ipAddress: '::1'
      }
    ];

    // Append dummy data to the actual data for testing purposes
    return [...data, ...dummyData];
  }

  filterAuditTrails() {
    this.filteredAuditTrails = this.audits.filter(audit => {
      const timestampStr = new Date(audit.timestamp).toLocaleString(); // Convert timestamp to string

      const matchesSearchQuery = this.searchQuery === '' ||
        audit.event.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
        audit.userName.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
        timestampStr.toLowerCase().includes(this.searchQuery.toLowerCase());

      return matchesSearchQuery &&
        (!this.selectedAction || audit.event === this.selectedAction) &&
        (!this.selectedUser || audit.userName === this.selectedUser) &&
        (!this.selectedDate || new Date(audit.timestamp).toDateString() === new Date(this.selectedDate).toDateString());
    });

    // Check if no results were found
    this.noResultsFound = this.filteredAuditTrails.length === 0;
  }

  generatePDF() {
    const body = [
      [
        { text: 'Event', style: 'tableHeader' },
        { text: 'User', style: 'tableHeader' },
        { text: 'Entity ID', style: 'tableHeader' },
        { text: 'Description', style: 'tableHeader' },
        { text: 'Date', style: 'tableHeader' },
        { text: 'IP Address', style: 'tableHeader' }
      ],
      ...this.filteredAuditTrails.map((audit) => [
        { text: audit.event, style: 'cell', noWrap: false },
        { text: audit.userName, style: 'cell', noWrap: false },
        { text: audit.entityId.toString(), style: 'cell', noWrap: false },
        { text: audit.description, style: 'cell', noWrap: false },
        { text: new Date(audit.timestamp).toLocaleDateString(), style: 'cell', noWrap: false },
        { text: audit.ipAddress, style: 'cell', noWrap: false }
      ])
    ];

    const docDefinition = {
      content: [
        {
          columns: [
            {
              image: BASE64_LOGO,  // Your base64 logo
              width: 100,
            },
            {
              stack: [
                { text: 'AB Fresh Wholesalers', bold: true, fontSize: 14, alignment: 'right' },
                { text: 'Store 204a, Hall 2, JHB Fresh Produce Market', alignment: 'right' },
                { text: 'City Deep, Johannesburg, 2049', alignment: 'right' },
                { text: `Generated by: ${this.currentUser}`, alignment: 'right' },
                { text: `Report Date: ${new Date().toLocaleDateString()}`, alignment: 'right' },
              ],
              alignment: 'right'
            }
          ],
          margin: [0, 0, 0, 20]
        },
        { text: 'Audit Trail Report', style: 'header', alignment: 'center' },
        {
          style: 'tableBody',
          table: {
            headerRows: 1,
            widths: ['15%', '15%', '10%', '30%', '15%', '15%'],  // Adjusted widths to fit content
            body
          },
          layout: {
            fillColor: function (rowIndex: number, node: any, columnIndex: number) {
              return rowIndex % 2 === 0 ? '#f9f9f9' : null;
            }
          }
        }
      ],
      styles: {
        header: { fontSize: 18, bold: true, margin: [0, 0, 0, 10] },
        tableHeader: { bold: true, fontSize: 12, fillColor: '#4CAF50', color: 'white' },
        cell: { margin: [5, 5, 5, 5] },
        tableBody: { margin: [0, 5, 0, 15] },
      },
      defaultStyle: {
        fontSize: 10,
        columnGap: 20,
      },
    };

    pdfMake.createPdf(docDefinition).download('AuditTrailReport.pdf');
  }

}
