import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AuditTrailsPage } from './audit-trails.page';

describe('AuditTrailsPage', () => {
  let component: AuditTrailsPage;
  let fixture: ComponentFixture<AuditTrailsPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(AuditTrailsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
