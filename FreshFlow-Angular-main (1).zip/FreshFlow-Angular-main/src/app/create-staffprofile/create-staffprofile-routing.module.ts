import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreateStaffprofilePage } from './create-staffprofile.page';

const routes: Routes = [
  {
    path: '',
    component: CreateStaffprofilePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CreateStaffprofilePageRoutingModule {}
