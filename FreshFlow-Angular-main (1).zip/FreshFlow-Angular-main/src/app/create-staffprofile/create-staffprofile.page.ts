import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StaffService } from '../services/staff.service';
import { Router } from '@angular/router';
import { PopoverController } from '@ionic/angular'; // Import PopoverController
// Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-create-staffprofile',
  templateUrl: './create-staffprofile.page.html',
  styleUrls: ['./create-staffprofile.page.scss'],
})
export class CreateStaffprofilePage implements OnInit {
  createStaffForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private staffService: StaffService,
    private router: Router,
    private popoverController: PopoverController // Add PopoverController
  ) {
    this.createStaffForm = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      fiveDigitCode: [''], // Optional field, no validators
    });
  }

  ngOnInit() { }

  registerStaff() {
    if (this.createStaffForm.valid) {
      const staffData = this.createStaffForm.value;

      // Password and Confirm Password validation
      if (staffData.password !== staffData.confirmPassword) {
        alert('Password and Confirm Password do not match.');
        return;
      }

      this.staffService.registerStaff(staffData).subscribe(
        (response) => {
          console.log('Registration successful', response);
          this.router.navigate(['/view-staffprofile']);
        },
        (error) => {
          console.error('Registration failed', error);
          const errorMessage = this.getErrorMessage(error);
          alert(errorMessage);
        }
      );
    } else {
      alert('Please fill out all required fields correctly.');
    }
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to register staff due to invalid input. Please check the fields and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while registering staff. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'username':
        hintMessage = "Enter a unique username that staff will use to log in, e.g., 'Staff01'.";
        break;
      case 'email':
        hintMessage = "Enter a valid email address, e.g., 'staff@email.com'.";
        break;
      case 'firstName':
        hintMessage = "Enter the staff's first name, e.g., 'Mary'.";
        break;
      case 'lastName':
        hintMessage = "Enter the staff's last name, e.g., 'Jane'.";
        break;
      case 'password':
        hintMessage = "Enter a strong password for the staff.";
        break;
      case 'confirmPassword':
        hintMessage = "Re-enter the password to confirm it matches the first one.";
        break;
      case 'fiveDigitCode':
        hintMessage = "The 5-digit code is automatically generated.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
