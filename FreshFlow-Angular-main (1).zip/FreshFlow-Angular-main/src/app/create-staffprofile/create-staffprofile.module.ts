import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateStaffprofilePageRoutingModule } from './create-staffprofile-routing.module';

import { CreateStaffprofilePage } from './create-staffprofile.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateStaffprofilePageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [CreateStaffprofilePage]
})
export class CreateStaffprofilePageModule { }
