import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SupplierService } from '../services/supplier.service';
import { Suppliers } from '../Model/supplier';
import { PopoverController } from '@ionic/angular';
 // Import the HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-update-supplier',
  templateUrl: './update-supplier.page.html',
  styleUrls: ['./update-supplier.page.scss'],
})
export class UpdateSupplierPage implements OnInit {
  supplier: Suppliers = {
    id: 0,
    Name: '',
    Location: '',
    Email: ''
  };

  nameError: boolean = false;
  locationError: boolean = false;
  emailError: boolean = false;
  invalidEmailError: boolean = false;

  constructor(
    private supplierService: SupplierService,
    private router: Router,
    private route: ActivatedRoute,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  ngOnInit() {
    this.supplier = history.state.supplier || {
      id: 0,
      Name: '',
      Location: '',
      Email: ''
    };
  }

  onSubmit() {
    this.resetErrors();

    this.nameError = !this.supplier.Name.trim();
    this.locationError = !this.supplier.Location.trim();
    this.emailError = !this.supplier.Email.trim();
    this.invalidEmailError = !this.validateEmail(this.supplier.Email);

    if (!this.nameError && !this.locationError && !this.emailError && !this.invalidEmailError) {
      this.supplierService.updateSupplier(this.supplier).subscribe({
        next: () => {
          alert('Supplier updated successfully');
          this.router.navigate(['/view-supplier']);
        },
        error: (error) => {
          console.error('Error updating supplier:', error);
          alert(this.getErrorMessage(error));
        }
      });
    }
  }

  validateEmail(email: string): boolean {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@(([^<>()[\]\.,;:\s@"]+\.)+[^<>()[\]\.,;:\s@"]{2,})$/i;
    return re.test(String(email).toLowerCase());
  }

  private resetErrors() {
    this.nameError = false;
    this.locationError = false;
    this.emailError = false;
    this.invalidEmailError = false;
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to update supplier due to invalid input. Please check the fields and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while updating the supplier. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'name':
        hintMessage = "Enter the supplier's name.";
        break;
      case 'location':
        hintMessage = "Enter the supplier's location (e.g., city, office address).";
        break;
      case 'email':
        hintMessage = "Enter a valid email address for the supplier.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
