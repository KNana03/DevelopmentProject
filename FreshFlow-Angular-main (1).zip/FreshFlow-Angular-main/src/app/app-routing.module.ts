import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { ViewSupplierPage } from './view-supplier/view-supplier.page';
import { LowStockComponent } from './products/low-stock/low-stock.component';
import { CalendarComponent } from './calendar/calendar.component';
import { ActivityLogComponent } from './activity-log/activity-log.component';
import { PdfViewerComponent } from 'ng2-pdf-viewer';


const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then(m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'create-supplier',
    loadChildren: () => import('./create-supplier/create-supplier.module').then(m => m.CreateSupplierPageModule)
  },
  {
    path: 'update-supplier',
    loadChildren: () => import('./update-supplier/update-supplier.module').then(m => m.UpdateSupplierPageModule)
  },
  {
    path: 'view-supplier',
    loadChildren: () => import('./view-supplier/view-supplier.module').then(m => m.ViewSupplierPageModule)
  },
  {
    path: 'create-profile',
    loadChildren: () => import('./create-profile/create-profile.module').then(m => m.CreateProfilePageModule)
  },
  {
    path: 'update-profile',
    loadChildren: () => import('./update-profile/update-profile.module').then(m => m.UpdateProfilePageModule)
  },
  {
    path: 'view-profile',
    loadChildren: () => import('./view-profile/view-profile.module').then(m => m.ViewProfilePageModule)
  },
  {
    path: 'create-staffprofile',
    loadChildren: () => import('./create-staffprofile/create-staffprofile.module').then(m => m.CreateStaffprofilePageModule)
  },
  {
    path: 'update-staffprofile',
    loadChildren: () => import('./update-staffprofile/update-staffprofile.module').then(m => m.UpdateStaffprofilePageModule)
  },
  {
    path: 'view-staffprofile',
    loadChildren: () => import('./view-staffprofile/view-staffprofile.module').then(m => m.ViewStaffprofilePageModule)
  },
  {
    path: 'view-staffprofile',
    loadChildren: () => import('./view-staffprofile/view-staffprofile.module').then(m => m.ViewStaffprofilePageModule)
  },
  {
    path: 'create-order',
    loadChildren: () => import('./create-order/create-order.module').then(m => m.CreateOrderPageModule)
  },
  {
    path: 'view-orders',
    loadChildren: () => import('./view-orders/view-orders.module').then(m => m.ViewOrdersPageModule)
  },
  {
    path: 'order-report',
    loadChildren: () => import('./order-report/order-report.module').then(m => m.OrderReportPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then(m => m.LoginPageModule)
  },
  {
    path: 'signup',
    loadChildren: () => import('./signup/signup.module').then(m => m.SignupPageModule)
  },
  {
    path: 'forgot-password',
    loadChildren: () => import('./forgot-password/forgot-password.module').then(m => m.ForgotPasswordPageModule)
  },
  {
    path: 'verify-otp',
    loadChildren: () => import('./verify-otp/verify-otp.module').then(m => m.VerifyOtpPageModule)
  },
  {
    path: 'reset-password',
    loadChildren: () => import('./reset-password/reset-password.module').then(m => m.ResetPasswordPageModule)
  },
  {
    path: 'create-role-page',
    loadChildren: () => import('./create-role-page/create-role-page.module').then(m => m.CreateRolePagePageModule)
  },
  {
    path: 'assign-role',
    loadChildren: () => import('./assign-role/assign-role.module').then(m => m.AssignRolePageModule)
  },
  {
    path: 'products',
    loadChildren: () => import('./pages/products/products.module').then(m => m.ProductsPageModule)
  },
  {
    path: 'all-products',
    loadChildren: () => import('./products/all-products/all-products.module').then(m => m.AllProductsPageModule)
  },
  {
    path: 'settings',
    loadChildren: () => import('./settings/settings.module').then(m => m.SettingsPageModule)
  },
  {
    path: 'create-inventory',
    loadChildren: () => import('./create-inventory/create-inventory.module').then(m => m.CreateInventoryPageModule)
  },
  {
    path: 'update-inventory',
    loadChildren: () => import('./update-inventory/update-inventory.module').then(m => m.UpdateInventoryPageModule)
  },
  {
    path: 'view-inventory',
    loadChildren: () => import('./view-inventory/view-inventory.module').then(m => m.ViewInventoryPageModule)
  },
  {
    path: 'delete-inventory-modal',
    loadChildren: () => import('./delete-inventory-modal/delete-inventory-modal.module').then(m => m.DeleteInventoryModalPageModule)
  },
  {
    path: 'create-writeoffreason',
    loadChildren: () => import('./create-writeoffreason/create-writeoffreason.module').then(m => m.CreateWriteoffreasonPageModule)
  },
  {
    path: 'create-inventory-type',
    loadChildren: () => import('./create-inventory-type/create-inventory-type.module').then(m => m.CreateInventorytypePageModule)
  },
  {
    path: 'delete-inventory-type-modal',
    loadChildren: () => import('./delete-inventory-type-modal/delete-inventory-type-modal.module').then(m => m.DeleteInventorytypeModalPageModule)
  },
  {
    path: 'delete-writeoffreason-modal',
    loadChildren: () => import('./delete-writeoffreason-modal/delete-writeoffreason-modal.module').then(m => m.DeleteWriteoffreasonPageModule)
  },
  {
    path: 'update-inventory-type',
    loadChildren: () => import('./update-inventory-type/update-inventory-type.module').then(m => m.UpdateInventorytypePageModule)
  },
  {
    path: 'update-writeoffreason',
    loadChildren: () => import('./update-writeoffreason/update-writeoffreason.module').then(m => m.UpdateWriteoffreasonPageModule)
  },
  {
    path: 'view-inventory-type',
    loadChildren: () => import('./view-inventory-type/view-inventory-type.module').then(m => m.ViewInventorytypePageModule)
  },
  {
    path: 'view-writeoffreason',
    loadChildren: () => import('./view-writeoffreason/view-writeoffreason.module').then(m => m.ViewWriteoffreasonPageModule)
  },
  {
    path: 'update-order/:id',
    loadChildren: () => import('./update-order/update-order.module').then(m => m.UpdateOrderPageModule)
  },
  {
    path: 'delete-profile-modal',
    loadChildren: () => import('./delete-staffprofile-modal/delete-staffprofile-modal.module').then(m => m.DeleteProfileModalPageModule)
  },

  {
    path: 'view-shift',
    loadChildren: () => import('./view-shift/view-shift.module').then(m => m.ViewShiftPageModule)
  },

  {
    path: 'create-shift',
    loadChildren: () => import('./create-shift/create-shift.module').then(m => m.CreateShiftPageModule)
  },

  {
    path: 'update-shift',
    loadChildren: () => import('./update-shift/update-shift.module').then(m => m.UpdateShiftPageModule)
  },

  {
    path: 'delete-shift-modal',
    loadChildren: () => import('./delete-shift-modal/delete-shift-modal.page').then(m => m.DeleteShiftModalPage)
  },
  {
    path: 'create-shift',
    loadChildren: () => import('./create-shift/create-shift.module').then(m => m.CreateShiftPageModule)
  },
  {
    path: 'create-shift-type',
    loadChildren: () => import('./create-shift-type/create-shift-type.module').then(m => m.CreateShiftTypePageModule)
  },
  {
    path: 'delete-shift-modal',
    loadChildren: () => import('./delete-shift-modal/delete-shift-modal.module').then(m => m.DeleteShiftModalPageModule)
  },
  {
    path: 'view-shift',
    loadChildren: () => import('./view-shift/view-shift.module').then(m => m.ViewShiftPageModule)
  },

  {
    path: 'check-in',
    loadChildren: () => import('./check-in/check-in.module').then(m => m.CheckInPageModule)
  },
  {
    path: 'check-out',
    loadChildren: () => import('./check-out/check-out.module').then(m => m.CheckOutPageModule)
  },
  {
    path: 'view-shift-type',
    loadChildren: () => import('./view-shift-type/view-shift-type.module').then(m => m.ViewShiftTypePageModule)
  },
  {
    path: 'update-shift-type',
    loadChildren: () => import('./update-shift-type/update-shift-type.module').then(m => m.UpdateShiftTypePageModule)
  },
  {
    path: 'delete-shift-type-modal',
    loadChildren: () => import('./delete-shift-type-modal/delete-shift-type-modal.module').then(m => m.DeleteShiftTypeModalPageModule)
  },
  {
    path: 'view-sales',
    loadChildren: () => import('./view-sales/view-sales.module').then(m => m.ViewSalesPageModule)
  },
  {
    path: 'sale-details',
    loadChildren: () => import('./sale-details/sale-details.module').then(m => m.SaleDetailsPageModule)
  },
  {
    path: 'create-sale',
    loadChildren: () => import('./create-sale/create-sale.module').then(m => m.CreateSalePageModule)
  },

  {
    path: 'assign-shift',
    loadChildren: () => import('./assign-shift/assign-shift.module').then(m => m.AssignShiftPageModule)
  },

  {
    path: 'assigned-shifts',
    loadChildren: () => import('./assigned-shifts/assigned-shifts.module').then(m => m.AssignedShiftsPageModule)
  },
  {
    path: 'view-inventory-report',
    loadChildren: () => import('./view-inventory-report/view-inventory-report.module').then(m => m.ViewInventoryReportPageModule)
  },
  {
    path: 'update-password',
    loadChildren: () => import('./update-password/update-password.module').then(m => m.UpdatePasswordPageModule)
  },

  {
    path: 'create-role',
    loadChildren: () => import('./create-role/create-role.module').then(m => m.CreateRolePageModule)
  },
  {
    path: 'delete',
    loadChildren: () => import('./delete/delete.module').then(m => m.DeletePageModule)
  },
  {
    path: 'view',
    loadChildren: () => import('./view/view.module').then(m => m.ViewPageModule)
  },
  {
    path: 'update',
    loadChildren: () => import('./update/update.module').then(m => m.UpdatePageModule)
  },
  {
    path: 'shift-report',
    loadChildren: () => import('./shift-report/shift-report.module').then(m => m.ShiftReportPageModule)
  },
  {
    path: 'inventory-turnover-report',
    loadChildren: () => import('./inventory-turnover-report/inventory-turnover-report.module').then(m => m.InventoryTurnoverReportPageModule)
  },
  {
    path: 'supplier-documents',
    loadChildren: () => import('./supplier-documents/supplier-documents.module').then(m => m.SupplierDocumentsPageModule)
  },
  {
    path: 'session-config',
    loadChildren: () => import('./session-config/session-config.module').then(m => m.SessionConfigPageModule)
  },
  {
    path: 'file-reader',
    loadChildren: () => import('./file-reader/file-reader.module').then(m => m.FileReaderPageModule)
  },
  {
    path: 'calendar',
    component: CalendarComponent
  },
  {
    path: 'activity-log',
    component: ActivityLogComponent
  },

  {
    path: 'sales-report',
    loadChildren: () => import('./sales-report/sales-report.module').then(m => m.SalesReportPageModule)
  },
  {
    path: 'stock-take/:orderId',
    loadChildren: () => import('./stock-take/stock-take.module').then(m => m.StockTakePageModule)
  },
  {
    path: 'add-review',
    loadChildren: () => import('./add-review/add-review.module').then(m => m.AddReviewPageModule)
  },
  {
    path: 'view-reviews',
    loadChildren: () => import('./view-reviews/view-reviews.module').then(m => m.ViewReviewsPageModule)
  },
  {
    path: 'view-warehouses',
    loadChildren: () => import('./warehouses/view-warehouse/view-warehouses.module').then(m => m.ViewWarehousesPageModule)
  },
  {
    path: 'add-warehouse',
    loadChildren: () => import('./warehouses/add-warehouse/add-warehouse.module').then(m => m.AddWarehousePageModule)
  },
  {
    path: 'update-warehouse',
    loadChildren: () => import('./warehouses/update-warehouse/update-warehouse.module').then(m => m.UpdateWarehousePageModule)
  },
  {
    path: 'audit-trails',
    loadChildren: () => import('./audit-trails/audit-trails.module').then(m => m.AuditTrailsPageModule)
  },
  {
    path: 'pdf-viewer',
    component: PdfViewerComponent
  },  {
    path: 'firsthelpmodal',
    loadChildren: () => import('./firsthelpmodal/firsthelpmodal.module').then( m => m.FirsthelpmodalPageModule)
  },
  {
    path: 'secondhelpmodal',
    loadChildren: () => import('./secondhelpmodal/secondhelpmodal.module').then( m => m.SecondhelpmodalPageModule)
  },
  {
    path: 'thirdhelpmodal',
    loadChildren: () => import('./thirdhelpmodal/thirdhelpmodal.module').then( m => m.ThirdhelpmodalPageModule)
  },
  {
    path: 'fourthhelpmodal',
    loadChildren: () => import('./fourthhelpmodal/fourthhelpmodal.module').then( m => m.FourthhelpmodalPageModule)
  },
  {
    path: 'fifthhelpmodal',
    loadChildren: () => import('./fifthhelpmodal/fifthhelpmodal.module').then( m => m.FifthhelpmodalPageModule)
  },
  {
    path: 'sixthhelpmodal',
    loadChildren: () => import('./sixthhelpmodal/sixthhelpmodal.module').then( m => m.SixthhelpmodalPageModule)
  },
  {
    path: 'helpdetail',
    loadChildren: () => import('./helpdetail/helpdetail.module').then( m => m.HelpdetailPageModule)
  },
  {
    path: 'reporthelpmodal',
    loadChildren: () => import('./reporthelpmodal/reporthelpmodal.module').then( m => m.ReporthelpmodalPageModule)
  },
  {
    path: 'invetoryhelpmodal',
    loadChildren: () => import('./invetoryhelpmodal/invetoryhelpmodal.module').then( m => m.InvetoryhelpmodalPageModule)
  },
  {
    path: 'return-stock-modal',
    loadChildren: () => import('./return-stock-modal/return-stock-modal.module').then( m => m.ReturnStockModalPageModule)
  },
  {
    path: 'returned-stock',
    loadChildren: () => import('./returned-stock/returned-stock.module').then( m => m.ReturnedStockPageModule)
  },









];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
