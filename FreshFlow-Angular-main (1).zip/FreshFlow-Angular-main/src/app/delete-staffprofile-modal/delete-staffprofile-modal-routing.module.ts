import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DeleteProfileModalPage } from './delete-staffprofile-modal.page';

const routes: Routes = [
  {
    path: '',
    component: DeleteProfileModalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DeleteProfileModalPageRoutingModule {}
