import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-profile-modal',
  templateUrl: './delete-staffprofile-modal.page.html',
  styleUrls: ['./delete-staffprofile-modal.page.scss'],
})
export class DeleteProfileModalPage implements OnInit {

  constructor(
    private modalController: ModalController,
    private router: Router
  ) { }

  ngOnInit() { }

  closeModal() {
    this.modalController.dismiss().then(() => {
      this.router.navigate(['/view-profile']);
    }).catch((error) => {
      console.error('Error closing modal', error);
      alert('Failed to close the modal. Please try again.');
    });
  }

  confirmDeletion() {
    try {
      // Add logic for profile deletion here

      // After deletion logic, navigate back to the profile view page
      this.router.navigate(['/view-profile']).then(() => {
        // Dismiss the modal once navigation is successful
        this.modalController.dismiss();
      }).catch((error) => {
        console.error('Error navigating to view-profile', error);
        alert('Profile was deleted, but failed to navigate to the profile view. Please try again.');
      });
    } catch (error) {
      console.error('Error during profile deletion process', error);
      alert('An error occurred while deleting the profile. Please try again.');
    }
  }

}
