import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DeleteProfileModalPage } from './delete-staffprofile-modal.page';

describe('DeleteProfileModalPage', () => {
  let component: DeleteProfileModalPage;
  let fixture: ComponentFixture<DeleteProfileModalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteProfileModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
