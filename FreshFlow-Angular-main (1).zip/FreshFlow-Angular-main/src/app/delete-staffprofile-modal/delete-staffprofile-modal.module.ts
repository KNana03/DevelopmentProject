import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DeleteProfileModalPageRoutingModule } from './delete-staffprofile-modal-routing.module';

import { DeleteProfileModalPage } from './delete-staffprofile-modal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DeleteProfileModalPageRoutingModule
  ],
  declarations: [DeleteProfileModalPage]
})
export class DeleteProfileModalPageModule {}
