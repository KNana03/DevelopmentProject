import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DeleteWriteoffreasonModalPage } from './delete-writeoffreason-modal.page';

const routes: Routes = [
  {
    path: '',
    component: DeleteWriteoffreasonModalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DeleteWriteoffreasonModalPageRoutingModule {}