import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DeleteWriteoffreasonModalPage } from './delete-writeoffreason-modal.page';

describe('DeleteWriteoffreasonModalComponent', () => {
  let component: DeleteWriteoffreasonModalPage;
  let fixture: ComponentFixture<DeleteWriteoffreasonModalPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteWriteoffreasonModalPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DeleteWriteoffreasonModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
