import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-writeoffreason-modal',
  templateUrl: './delete-writeoffreason-modal.page.html',
  styleUrls: ['./delete-writeoffreason-modal.page.scss'],
})
export class DeleteWriteoffreasonModalPage implements OnInit {

  constructor(
    private modalController: ModalController,
    private router: Router
  ) { }

  ngOnInit() { }

  closeModal() {
    this.modalController.dismiss().then(() => {
      this.router.navigate(['/view-writeoffreason']);
    }).catch((error) => {
      console.error('Error closing modal', error);
      alert('Failed to close the modal. Please try again.');
    });
  }

  confirmDeletion() {
    try {
      // Add logic for write-off reason deletion here

      // After deletion logic, navigate back to the write-off reason view page
      this.router.navigate(['/view-writeoffreason']).then(() => {
        // Dismiss the modal once navigation is successful
        this.modalController.dismiss();
      }).catch((error) => {
        console.error('Error navigating to view-writeoffreason', error);
        alert('Write-off reason was deleted, but failed to navigate to the write-off reason view. Please try again.');
      });
    } catch (error) {
      console.error('Error during write-off reason deletion process', error);
      alert('An error occurred while deleting the write-off reason. Please try again.');
    }
  }

}
