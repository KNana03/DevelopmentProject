import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-role',
  templateUrl: './create-role.page.html',
  styleUrls: ['./create-role.page.scss'],
})
export class CreateRolePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
