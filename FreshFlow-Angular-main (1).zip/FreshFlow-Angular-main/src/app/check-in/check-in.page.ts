import { Component, OnInit } from '@angular/core';
import { StaffAttendanceService } from '../services/staff-attendance.service';
import { AlertController } from '@ionic/angular';
import { CheckInOutRequest } from '../Model/CheckInOutRequest'; // Import the model

@Component({
  selector: 'app-check-in',
  templateUrl: './check-in.page.html',
  styleUrls: ['./check-in.page.scss'],
})
export class CheckInPage implements OnInit {
  staffId: number = 0;
  fiveDigitCode: string = '';
  errorMessage: string = '';

  constructor(
    private staffAttendanceService: StaffAttendanceService,
    private alertController: AlertController
  ) { }

  ngOnInit() { }

  async handleCheckIn() {
    if (!this.staffId || !this.fiveDigitCode) {
      this.showAlert('Error', 'Please enter Staff ID and Five Digit Code.');
      return;
    }

    const request: CheckInOutRequest = {
      staffId: this.staffId,
      fiveDigitCode: this.fiveDigitCode
    };

    try {
      const response = await this.staffAttendanceService.checkIn(request).toPromise();
      this.showAlert('Success', response.message);
    } catch (error) {
      console.error('Check-in error:', error);
      this.handleError(error);
    }
  }

  async handleCheckOut() {
    if (!this.staffId || !this.fiveDigitCode) {
      this.showAlert('Error', 'Please enter Staff ID and Five Digit Code.');
      return;
    }

    const request: CheckInOutRequest = {
      staffId: this.staffId,
      fiveDigitCode: this.fiveDigitCode
    };

    try {
      const response = await this.staffAttendanceService.checkOut(request).toPromise();
      this.showAlert('Success', response.message);
    } catch (error) {
      console.error('Check-out error:', error);
      this.handleError(error);
    }
  }

  private async handleError(error: any) {
    let message = 'An unexpected error occurred. Please try again later.';
    if (error.status === 0) {
      message = 'Network error. Please check your connection.';
    } else if (error.error && error.error.message) {
      message = error.error.message;
    } else if (typeof error === 'string') {
      message = error;
    }
    this.showAlert('Error', message);
  }

  private async showAlert(header: string, message: string) {
    const alert = await this.alertController.create({
      header,
      message,
      buttons: ['OK']
    });
    await alert.present();
  }
}
