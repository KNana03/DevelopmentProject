import { Component, OnInit } from '@angular/core';
import { ReturnService } from '../services/return.service';
import { StaffService } from '../services/staff.service';
import { InventoryService } from '../services/inventory.service';
import { ReturnedStock } from '../Model/returned-stock';
import { Staffs } from '../Model/staff';
import { Inventories } from '../Model/inventory';

@Component({
  selector: 'app-returned-stock',
  templateUrl: './returned-stock.page.html',
  styleUrls: ['./returned-stock.page.scss'],
})
export class ReturnedStockPage implements OnInit {
  returnedStock: ReturnedStock[] = [];
  staffs: { [key: number]: Staffs } = {};
  inventories: { [key: number]: Inventories } = {};
  loading: boolean = true;
  errorMessage: string | null = null;
  loggedInUserName: string | null = null; // Store logged-in username

  constructor(
    private returnService: ReturnService,
    private staffService: StaffService,
    private inventoryService: InventoryService
  ) {}

  ngOnInit() {
    this.loadLoggedInUser(); // Load the logged-in user
    this.loadReturnedStock();
  }

  loadLoggedInUser() {
    // Fetch the logged-in user from localStorage
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    this.loggedInUserName = user.username || 'Unknown User';
  }

  loadReturnedStock() {
    this.loading = true;
    this.returnService.getReturnedStock().subscribe({
      next: (data: ReturnedStock[]) => {
        this.returnedStock = data;
        this.loadRelatedData();
      },
      error: (error) => {
        console.error('Error fetching returned stock', error);
        this.errorMessage = 'Unable to load returned stock. Please try again later.';
        this.loading = false;
      },
      complete: () => {
        this.loading = false;
      }
    });
  }

  loadRelatedData() {
    this.returnedStock.forEach((item) => {
      if (!this.staffs[item.staffId]) {
        this.staffService.getStaffById(item.staffId.toString()).subscribe({
          next: (staff) => {
            if (staff) {
              this.staffs[item.staffId] = staff;
            }
          },
          error: (error) => {
            console.error('Error fetching staff', error);
          }
        });
      }

      if (!this.inventories[item.inventoryId]) {
        this.inventoryService.getInventory(item.inventoryId.toString()).subscribe({
          next: (inventory) => {
            if (inventory) {
              this.inventories[item.inventoryId] = inventory;
            }
          },
          error: (error) => {
            console.error('Error fetching inventory', error);
          }
        });
      }
    });
  }

  getStaffName(staffId: number): string {
    return this.staffs[staffId]?.firstName || 'Unknown Staff';
  }
}
