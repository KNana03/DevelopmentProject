import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReturnedStockPage } from './returned-stock.page';

describe('ReturnedStockPage', () => {
  let component: ReturnedStockPage;
  let fixture: ComponentFixture<ReturnedStockPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturnedStockPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
