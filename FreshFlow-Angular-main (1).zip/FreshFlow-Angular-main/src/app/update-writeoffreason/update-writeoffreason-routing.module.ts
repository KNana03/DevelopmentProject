import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UpdateWriteoffreasonPage } from './update-writeoffreason.page';

const routes: Routes = [
  {
    path: '',
    component: UpdateWriteoffreasonPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UpdateWriteoffreasonPageRoutingModule {}