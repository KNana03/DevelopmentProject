import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UpdateWriteoffreasonPageRoutingModule } from './update-writeoffreason-routing.module';

import { UpdateWriteoffreasonPage } from './update-writeoffreason.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    UpdateWriteoffreasonPageRoutingModule
  ],
  declarations: [UpdateWriteoffreasonPage]
})
export class UpdateWriteoffreasonPageModule {}