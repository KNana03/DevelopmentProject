import { Component, OnInit } from '@angular/core';
import { NavController, PopoverController } from '@ionic/angular'; // Import PopoverController
import { Writeoffreasons } from '../Model/writeoffreason';
import { WriteoffreasonService } from '../services/writeoffreason.service';
import { Router } from '@angular/router';
 // Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-update-writeoffreason',
  templateUrl: './update-writeoffreason.page.html',
  styleUrls: ['./update-writeoffreason.page.scss'],
})
export class UpdateWriteoffreasonPage implements OnInit {

  writeoffreasonData: Writeoffreasons = {
    id: 0,
    reason: '',
  };

  constructor(
    private navCtrl: NavController,
    private router: Router,
    private writeoffreasonService: WriteoffreasonService,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  ngOnInit() {
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      const state = navigation.extras.state as { [key: string]: any };
      if (state['writeoffreason']) {
        this.writeoffreasonData = state['writeoffreason'];
      }
    }
  }

  navigateToViewWriteoffreason() {
    this.navCtrl.navigateForward(['/view-writeoffreason']);
  }

  updateWriteoffreason() {
    if (!this.isFormValid()) {
      alert('Please fill in the reason field.');
      return;
    }

    this.writeoffreasonService.updateWriteoffreason(this.writeoffreasonData.id.toString(), this.writeoffreasonData).subscribe(
      response => {
        console.log('Write-off reason updated successfully', response);
        alert('Write-off reason updated successfully');
        this.navigateToViewWriteoffreason();
      },
      error => {
        console.error('Write-off reason update failed', error);
        alert(this.getErrorMessage(error));
      }
    );
  }

  private isFormValid(): boolean {
    return this.writeoffreasonData.reason.trim() !== '';
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to update the write-off reason due to invalid input. Please check the fields and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while updating the write-off reason. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'reason':
        hintMessage = "Enter a valid reason for writing off the inventory.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
