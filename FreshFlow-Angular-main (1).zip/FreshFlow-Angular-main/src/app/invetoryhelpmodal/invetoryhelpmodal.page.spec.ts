import { ComponentFixture, TestBed } from '@angular/core/testing';
import { InvetoryhelpmodalPage } from './invetoryhelpmodal.page';

describe('InvetoryhelpmodalPage', () => {
  let component: InvetoryhelpmodalPage;
  let fixture: ComponentFixture<InvetoryhelpmodalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(InvetoryhelpmodalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
