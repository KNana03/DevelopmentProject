import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'app-invetoryhelpmodal',
  templateUrl: './invetoryhelpmodal.page.html',
  styleUrls: ['./invetoryhelpmodal.page.scss'],
})
export class InvetoryhelpmodalPage implements OnInit {

  constructor(private navCtrl: NavController) { }

  ngOnInit() {
    const iframe = document.getElementById('help-frame') as HTMLIFrameElement;
    iframe.onload = () => {
      iframe.contentWindow?.postMessage('inventory', '*');
    };
  }

  dismissModal() {
    this.navCtrl.back();
  }
}