import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { InvetoryhelpmodalPageRoutingModule } from './invetoryhelpmodal-routing.module';

import { InvetoryhelpmodalPage } from './invetoryhelpmodal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InvetoryhelpmodalPageRoutingModule
  ],
  declarations: [InvetoryhelpmodalPage]
})
export class InvetoryhelpmodalPageModule {}
