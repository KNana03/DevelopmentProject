import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateShiftPage } from './create-shift.page';

describe('CreateShiftPage', () => {
  let component: CreateShiftPage;
  let fixture: ComponentFixture<CreateShiftPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateShiftPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
