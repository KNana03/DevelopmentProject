import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateShiftPageRoutingModule } from './create-shift-routing.module';

import { CreateShiftPage } from './create-shift.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateShiftPageRoutingModule
  ],
  declarations: [CreateShiftPage]
})
export class CreateShiftPageModule {}
