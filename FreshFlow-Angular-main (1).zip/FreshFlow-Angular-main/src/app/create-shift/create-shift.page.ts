import { Component, OnInit } from '@angular/core';
import { Shift } from '../Model/shift';
import { Router } from '@angular/router';
import { NavController, AlertController } from '@ionic/angular';
import { ShiftTypeService } from '../services/shift-type.service';
import { ShiftService } from '../services/shift.service';
import { ShiftType } from '../Model/shift-type';

@Component({
  selector: 'app-create-shift',
  templateUrl: './create-shift.page.html',
  styleUrls: ['./create-shift.page.scss'],
})
export class CreateShiftPage implements OnInit {
  shiftData: Omit<Shift, 'id' | 'shiftType'> = {
    name: '',
    startTime: '',
    endTime: '',
    shiftTypeId: 0,
    typeName: "",
    date: '',
    checkInTime: '',
    checkOutTime: ''
  };
  shiftTypes: ShiftType[] = [];
  createdShiftId: number = 0;
  errorMessage: string = '';
  formSubmitted: boolean = false;

  constructor(
    private navCtrl: NavController,
    public shiftService: ShiftService,
    private shiftTypeService: ShiftTypeService,
    private router: Router,
    private alertController: AlertController // Inject AlertController for popups
  ) { }

  ngOnInit() {
    this.loadShiftTypes();
  }

  loadShiftTypes(): void {
    this.shiftTypeService.getShiftTypes().subscribe({
      next: (data: ShiftType[]) => {
        this.shiftTypes = data;
      },
      error: (error) => {
        console.error('Error loading shift types', error);
        this.handleError('loading shift types', error);
      }
    });
  }

  // Update time with the selected date to keep the format intact
  updateDateTime(field: 'startTime' | 'endTime' | 'checkInTime' | 'checkOutTime'): void {
    if (!this.shiftData.date) return;
  
    const selectedTime = this.shiftData[field]; // Fetch selected time (HH:mm)
    if (selectedTime) {
      const date = new Date(this.shiftData.date); // Use selected date
      const timeParts = selectedTime.split(':');
      if (timeParts.length === 2) {
        date.setHours(parseInt(timeParts[0], 10), parseInt(timeParts[1], 10));
        this.shiftData[field] = date.toISOString(); // Combine date with time and set
      }
    }
  }

  formatISODateTime(dateTime: string | undefined): string {
    if (dateTime) {
      const dateObject = new Date(dateTime);
      if (!isNaN(dateObject.getTime())) {
        return dateObject.toISOString();
      }
    }
    return '';
  }

  async registerShift() {
    this.formSubmitted = true;

    if (!this.shiftData.name.trim()) {
      this.errorMessage = 'Please enter a valid shift name.';
      return;
    }

    if (!this.shiftData.shiftTypeId) {
      this.errorMessage = 'Please select a shift type.';
      return;
    }

    if (!this.shiftData.startTime || !this.shiftData.endTime) {
      this.errorMessage = 'Please select valid start and end times.';
      return;
    }

    const selectedShiftType = this.shiftTypes.find(st => st.id === this.shiftData.shiftTypeId);
    if (!selectedShiftType) {
      this.errorMessage = 'Invalid shift type selected.';
      return;
    }

    // Get today's date and reset time to 00:00:00 for accurate comparison
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Convert the shift date to a comparable format
    const selectedDate = new Date(this.shiftData.date);
    selectedDate.setHours(0, 0, 0, 0);

    // Ensure the shift date is not before today
    if (selectedDate < today) {
      await this.showErrorPopup('Error', 'You cannot create a shift with a date before today.');
      return;
    }

    const shiftToCreate: Omit<Shift, 'id' | 'shiftType'> = {
      ...this.shiftData,
      startTime: this.formatISODateTime(this.shiftData.startTime),
      endTime: this.formatISODateTime(this.shiftData.endTime),
      checkInTime: this.shiftData.checkInTime ? this.formatISODateTime(this.shiftData.checkInTime) : undefined,
      checkOutTime: this.shiftData.checkOutTime ? this.formatISODateTime(this.shiftData.checkOutTime) : undefined,
      date: this.formatISODateTime(this.shiftData.date),
    };

    console.log('Formatted Shift Data:', shiftToCreate);

    this.shiftService.createShift(shiftToCreate).subscribe({
      next: (response) => {
        console.log('Shift creation successful', response);
        this.createdShiftId = response.id;
        this.navigateToViewShifts();
      },
      error: (error) => {
        console.error('Shift creation error', error);
        this.handleError('creating shift', error);
      },
    });
  }

  // Function to display a popup error
  async showErrorPopup(header: string, message: string) {
    const alert = await this.alertController.create({
      header: header,
      message: message,
      buttons: ['OK'],
    });
    await alert.present();
  }

  private handleError(action: string, error: any) {
    if (error.status === 0) {
      this.errorMessage = `Network error occurred while ${action}. Please check your connection and try again.`;
    } else if (error.status === 400 && error.error) {
      this.errorMessage = `Validation error occurred while ${action}: ${JSON.stringify(error.error.errors)}`;
    } else {
      this.errorMessage = `Server error occurred while ${action}. Please try again later.`;
    }
    alert(this.errorMessage);
  }

  navigateToViewShifts() {
    this.router.navigate(['/view-shift']);
  }
}
