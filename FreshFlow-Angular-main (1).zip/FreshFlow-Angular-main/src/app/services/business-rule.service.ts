import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BusinessRuleService {
  private rules: any;

  constructor(private http: HttpClient) {}

  // Load the business rules from the JSON file
  loadRules(): Observable<any> {
    return this.http.get('/assets/config/business-rules.json').pipe(
      map((rules) => {
        this.rules = rules;
        return this.rules;
      }),
      catchError((error) => {
        console.error('Error loading business rules:', error);
        return of(null);
      })
    );
  }

  // Calculate the discount based on the sale amount and loaded rules
  calculateDiscount(amount: number): number {
    let discount = 0;

    if (this.rules?.discountRules?.applyDiscount && this.rules.discountRules.thresholds) {
      const thresholds = this.rules.discountRules.thresholds;

      // Find the highest applicable discount based on thresholds
      for (const threshold of thresholds) {
        if (amount >= threshold.minAmount) {
          discount = threshold.discountPercentage;
        }
      }
    }

    return discount;
  }
}
