import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { CheckInOutRequest } from '../Model/CheckInOutRequest'; // Import the new model

@Injectable({
  providedIn: 'root',
})
export class StaffAttendanceService {
  private apiUrl = `${environment.apiUrl}/StaffAttendance`;

  constructor(private http: HttpClient) { }

  checkIn(request: CheckInOutRequest): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(`${this.apiUrl}/check-in`, request, { headers });
  }

  checkOut(request: CheckInOutRequest): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(`${this.apiUrl}/check-out`, request, { headers });
  }
}
