import { TestBed } from '@angular/core/testing';

import { ShiftAssignmentService } from './shift-assignment.service';

describe('ShiftAssignmentService', () => {
  let service: ShiftAssignmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ShiftAssignmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
