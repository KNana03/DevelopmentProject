import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Sales } from '../Model/sales';
import { VAT } from '../Model/VAT';

@Injectable({
  providedIn: 'root'
})
export class SalesService {
  apiUrl = 'https://localhost:7261/api/Sales';
  vatApiUrl = "https://localhost:7261/api/VAT"

  constructor(private http: HttpClient) { }

  getSales(): Observable<Sales[]> {
    return this.http.get<Sales[]>(this.apiUrl);
  }

  getSale(id: number): Observable<Sales> {
    return this.http.get<Sales>(`${this.apiUrl}/${id}`);
  }
  createMultipleSales(sales: Sales[]): Observable<Sales[]> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.post<Sales[]>(`${this.apiUrl}/bulk`, sales, { headers });
  }
  createSale(sale: Sales): Observable<Sales> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.post<Sales>(this.apiUrl, sale, { headers });
  }

  getInventoryQuantity(inventoryId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/inventory-quantity/${inventoryId}`);
  }

  getVAT(): Observable<VAT[]> {
    return this.http.get<VAT[]>(`${this.vatApiUrl}/GetVAT`);
  }
}
