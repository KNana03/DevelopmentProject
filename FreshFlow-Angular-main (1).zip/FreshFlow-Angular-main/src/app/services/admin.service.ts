import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Admins } from '../Model/admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = 'https://localhost:7261/api/Admin'; // Replace with your actual backend URL

  constructor(private http: HttpClient) { }

  getAllAdmins(): Observable<Admins[]> {
    return this.http.get<Admins[]>(this.apiUrl);
  }

  registerAdmin(admin: Omit<Admins, 'id'>): Observable<Admins> {
    return this.http.post<Admins>(`${this.apiUrl}/register`, admin);
  }

  deleteAdminProfile(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  updateAdminProfile(id: string, admin: Admins): Observable<Admins> {
    return this.http.put<Admins>(`${this.apiUrl}/${id}`, admin);
  }
}