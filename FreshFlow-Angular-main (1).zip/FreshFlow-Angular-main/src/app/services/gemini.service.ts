import { Injectable } from '@angular/core';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { Observable, forkJoin } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GeminiService {
  private generativeAI: GoogleGenerativeAI;
  
  // URLs for different data endpoints
  private inventoryUrl = 'https://localhost:7261/api/Inventory';
  private supplierUrl = 'https://localhost:7261/api/Supplier';
  private orderUrl = 'https://localhost:7261/api/Order';
  private productUrl = 'https://localhost:7261/api/Product';
  private salesUrl = 'https://localhost:7261/api/Sales';
  private staffUrl = 'https://localhost:7261/api/Staff';

  // Key for storing conversation context in sessionStorage
  private conversationKey = 'conversationContext';

  constructor(private http: HttpClient) {
    // Initialize Google Generative AI with API key (replace with your actual key)
    this.generativeAI = new GoogleGenerativeAI('AIzaSyBGjeWAquSb26PYnQqnvwsJ4DFjr9t-dTk');
  }

  // Method to fetch all the necessary data from multiple endpoints
  getAllData(): Observable<any[]> {
    const inventoryData = this.http.get(this.inventoryUrl);
    const supplierData = this.http.get(this.supplierUrl);
    const orderData = this.http.get(this.orderUrl);
    const productData = this.http.get(this.productUrl);
    const salesData = this.http.get(this.salesUrl);
    const staffData = this.http.get(this.staffUrl);

    // Use forkJoin to combine multiple HTTP requests into a single observable
    return forkJoin([inventoryData, supplierData, orderData, productData, salesData, staffData]);
  }

  // Method to generate text using Google PaLM API with context
  async generateText(prompt: string): Promise<string> {
    try {
      const model = this.generativeAI.getGenerativeModel({ model: 'gemini-pro' });
      const result = await model.generateContent(prompt);
      const response = await result.response;
      const text = await response.text();
      return text;
    } catch (error) {
      console.error('Error generating text:', error);
      return 'Oops, something went wrong while I was thinking!';
    }
  }

  // Main method to handle user queries with context-awareness
  async handleChatbotQuestion(userQuestion: string): Promise<string> {
    console.log('Question received:', userQuestion); // Debugging

    // Normalize input (remove excessive spaces, punctuation, etc.)
    userQuestion = this.normalizeInput(userQuestion);

    // Retrieve existing conversation context from sessionStorage
    let conversationContext = sessionStorage.getItem(this.conversationKey) || '';
    const fullPrompt = `${conversationContext} User: ${userQuestion}`;

    // Determine the category of the question
    const category = this.determineCategory(userQuestion);

    // Handling questions based on identified categories
    let response;
    switch (category) {
      case 'authentication':
        response = await this.handleAuthenticationFAQ(userQuestion);
        break;
      case 'orders':
        response = await this.handleOrderFAQ(userQuestion);
        break;
      case 'suppliers':
        response = await this.handleSupplierFAQ(userQuestion);
        break;
      case 'inventory':
        response = await this.handleInventoryFAQ(userQuestion);
        break;
      case 'product':
        response = await this.handleProductFAQ(userQuestion);
        break;
      case 'sales':
        response = await this.handleSalesFAQ(userQuestion);
        break;
      case 'staff':
        response = await this.handleStaffFAQ(userQuestion);
        break;
      case 'support':
        response = await this.handleSupportFAQ(userQuestion);
        break;
      case 'greeting':
        response = 'Hello! How can I assist you today?'; // Greeting response
        break;
      default:
        response = await this.generateText(userQuestion); // Fallback for general questions
    }

    // Update the conversation context with the current question and response
    conversationContext += ` User: ${userQuestion} Assistant: ${response}`;
    sessionStorage.setItem(this.conversationKey, conversationContext);

    return response;
  }

  // Method to clear conversation context (useful when resetting the chat)
  clearConversationContext(): void {
    sessionStorage.removeItem(this.conversationKey);
  }

  // Normalize input to handle cases like jumbled or incoherent words
  private normalizeInput(input: string): string {
    return input
      .toLowerCase() // Convert to lowercase
      .replace(/[^a-z0-9\s]/g, '') // Remove special characters
      .replace(/\s+/g, ' ') // Replace multiple spaces with single space
      .trim(); // Remove extra spaces
  }

  // Method to categorize questions based on keywords
  private determineCategory(question: string): string {
    const keywords = {
      'orders': ['order', 'purchase', 'buy'],
      'suppliers': ['supplier', 'vendor'],
      'inventory': ['inventory', 'stock', 'write-off'],
      'product': ['product', 'brand', 'category'],
      'authentication': ['login', 'register', 'password', 'user roles'],
      'sales': ['sales', 'return stock', 'stock take'],
      'staff': ['staff', 'shift', 'check in', 'check out'],
      'support': ['help', 'troubleshoot', 'support'],
      'report': ['report', 'generate', 'control break', 'list'],
      'greeting': ['hi', 'hello', 'hey', 'good morning', 'good evening'] // Greeting keywords
    };

    for (const [category, terms] of Object.entries(keywords)) {
      for (const term of terms) {
        if (question.includes(term)) {
          return category;
        }
      }
    }

    return 'general';
  }

  // Authentication-related FAQ handling
  private async handleAuthenticationFAQ(userQuestion: string): Promise<string> {
    const questionLower = userQuestion.toLowerCase();

    if (questionLower.includes("reset my password")) {
      return `To reset your password, please follow these steps:
      1. Go to the login page of the application.
      2. Click on the "Forgot Password?" link.
      3. Enter your registered email address in the provided field.
      4. Check your email for an OTP.
      5. Enter the OTP you received.
      6. You will be directed to the password reset page.
      7. Enter your new password and confirm it.
      8. Submit the form to complete the password reset process.`;
    }

    if (questionLower.includes("login")) {
      return `To log in to your account, please follow these steps:
      1. Visit the login page of the application.
      2. Enter your registered email address and password.
      3. Click on the "Log In" button.
      4. If you have forgotten your password, you can use the "Forgot Password?" link to reset it.`;
    }

    if (questionLower.includes("register") || questionLower.includes("sign up")) {
      return `To register a new account, please follow these steps:
      1. Go to the registration page of the application.
      2. Fill in the required fields, including your email address, username, and password.
      3. Click on the "Sign Up" button.
      4. Check your email for a confirmation link and follow the instructions to activate your account.`;
    }

    if (questionLower.includes("user roles") || questionLower.includes("manage roles")) {
      return `To manage user roles, please follow these steps:
      1. Log in to your admin account.
      2. Navigate to the User Settings section.
      3. Select a user from the list to edit their role.
      4. Choose the desired role from the dropdown menu.
      5. Save the changes to update the user's role.`;
    }

    return `I'm sorry, but I couldn't understand your question. Please ask about resetting your password, logging in, registering a user, or managing user roles.`;
  }

  // Product-related FAQ handling
  private async handleProductFAQ(userQuestion: string): Promise<string> {
    const questionLower = userQuestion.toLowerCase();
    if (questionLower.includes("add a product")) {
      return `To add a product, follow these steps:
        1. Navigate to the Products tab in the side menu.
        2. Click on the "Add Product" button.
        3. Provide the product details.
        4. Click the "Add Product" button when you are done.`;
    }
    if (questionLower.includes("update a product")) {
      return `To update a product, follow these steps:
        1. Navigate to the Products tab in the side menu.
        2. Select the product you wish to update.
        3. Update the details.
        4. Click the "Save" button when you are done.`;
    }
    if (questionLower.includes("delete a product")) {
      return `To delete a product, follow these steps:
        1. Navigate to the Products tab in the side menu.
        2. Select the product you wish to delete.
        3. Click the "Delete Product" button when you are done.`;
    }
    if (questionLower.includes("create a new brand")) {
      return `To create a new brand, follow these steps:
        1. Navigate to the Products tab in the side menu.
        2. Scroll down to the "Brand" section and click "Create Brand".`;
    }
    if (questionLower.includes("create a new category")) {
      return `To create a new category, follow these steps:
        1. Navigate to the Products tab in the side menu.
        2. Scroll down to the "Category" section and click "Create Category".`;
    }
    return `I'm sorry, but I couldn't understand your question. Please ask about product-related questions.`;
  }

  // Order-related FAQ handling
  private async handleOrderFAQ(userQuestion: string): Promise<string> {
    const questionLower = userQuestion.toLowerCase();
    if (questionLower.includes("add an order")) {
      return `To add an order, follow these steps:
        1. Navigate to the Orders tab in the side menu.
        2. Click on the "Create New Order" button.
        3. Provide the order details.
        4. Click the "Capture Order" button when you are done.`;
    }
    if (questionLower.includes("update an order")) {
      return `To update an order, follow these steps:
        1. Navigate to the Orders tab in the side menu.
        2. Select the order you wish to update.
        3. Update the details.
        4. Click the "Update Order" button when you are done.`;
    }
    if (questionLower.includes("delete an order")) {
      return `To delete an order, follow these steps:
        1. Navigate to the Orders tab in the side menu.
        2. Select the order you wish to delete.
        3. Click the "Delete Order" button when you are done.`;
    }
    if (questionLower.includes("pay for an order")) {
      return `To pay for an order, follow these steps:
        1. Navigate to the Orders tab in the side menu.
        2. Select the order you wish to pay for.
        3. Click the "Pay" button.
        4. You will be directed to PayFast, where you can proceed to pay for your order.`;
    }
    if (questionLower.includes("receive an order")) {
      return `To receive an order, follow these steps:
        1. Navigate to the Orders tab in the side menu.
        2. Select the order you wish to receive.
        3. Click the "Receive" button.
        4. Once the order is received, it will be recorded in inventory.`;
    }
    return `I'm sorry, but I couldn't understand your question. Please ask about order-related questions.`;
  }

  // Inventory-related FAQ handling
  private async handleInventoryFAQ(userQuestion: string): Promise<string> {
    const questionLower = userQuestion.toLowerCase();
    if (questionLower.includes("add inventory")) {
      return `To add inventory, follow these steps:
        1. Navigate to the Inventory tab in the side menu.
        2. Click on the "Add New Inventory" button.
        3. Provide the inventory details.
        4. Click the "Add Inventory" button when you are done.`;
    }
    if (questionLower.includes("update inventory")) {
      return `To update inventory, follow these steps:
        1. Navigate to the Inventory tab in the side menu.
        2. Select the inventory you wish to update and click on the green edit icon.
        3. Update the details.
        4. Click the "Save Changes" button when you are done.`;
    }
    if (questionLower.includes("delete inventory")) {
      return `To delete inventory, follow these steps:
        1. Navigate to the Inventory tab in the side menu.
        2. Select the inventory you wish to delete.
        3. Click the red bin icon to delete it when you are done.`;
    }
    if (questionLower.includes("write-off inventory")) {
      return `To write off inventory, follow these steps:
        1. Navigate to the Inventory tab in the side menu.
        2. Select the inventory you wish to write off.
        3. Click the blue icon to write off.
        4. Provide your reason and the quantity you want to write off, then click the "Write-off" button.`;
    }
    return `I'm sorry, but I couldn't understand your question. Please ask about inventory-related questions.`;
  }

  // Supplier-related FAQ handling
  private async handleSupplierFAQ(userQuestion: string): Promise<string> {
    const questionLower = userQuestion.toLowerCase();
    if (questionLower.includes("add a supplier")) {
      return `To add a supplier, follow these steps:
        1. Navigate to the Supplier tab in the side menu.
        2. Click on the "Add Supplier" button.
        3. Provide the supplier details.
        4. Click the "Add Supplier" button when you are done.`;
    }
    if (questionLower.includes("update a supplier")) {
      return `To update a supplier, follow these steps:
        1. Navigate to the Supplier tab in the side menu.
        2. Click on the green edit icon button.
        3. Update the supplier details.
        4. Click the "Save Changes" button when you are done.`;
    }
    if (questionLower.includes("delete a supplier")) {
      return `To delete a supplier, follow these steps:
        1. Navigate to the Supplier tab in the side menu.
        2. Click on the red bin icon to delete the supplier.`;
    }
    if (questionLower.includes("upload supplier documents")) {
      return `To upload supplier documents, follow these steps:
        1. Click on the Supplier tab.
        2. Navigate to the Document button.
        3. Click on the button.
        4. Select the supplier and the document category.
        5. Choose the document file you want to upload.
        6. Click "Upload".`;
    }
    return `I'm sorry, but I couldn't understand your question. Please ask about supplier-related questions.`;
  }

  // Sales-related FAQ handling
  private async handleSalesFAQ(userQuestion: string): Promise<string> {
    const questionLower = userQuestion.toLowerCase();
    if (questionLower.includes("capture a sale")) {
      return `To capture a sale, follow these steps:
        1. Navigate to the Sales tab in the side menu.
        2. Click on the "Add" button.
        3. Provide the sales details.
        4. Click the "Create Sale" button when you are done.`;
    }
    if (questionLower.includes("return stock")) {
      return `To return stock, follow these steps:
        1. Navigate to the Sales tab in the side menu.
        2. Click on the "Return Stock" button.
        3. Provide the quantity and reason for the return.
        4. Click the "Submit Return" button when you are done.`;
    }
    if (questionLower.includes("perform stock take")) {
      return `To perform a stock take, follow these steps:
        1. Navigate to the Inventory tab in the side menu.
        2. Click on the "Stock Take" button.
        3. Select the warehouse or location where you want to perform the stock take.
        4. Review the list of items in stock and compare it with physical stock levels.
        5. Enter the actual stock count for each item.
        6. Once all items are counted, click the "Submit Stock Take" button to finalize.`;
    }
    return `I'm sorry, but I couldn't understand your question. Please ask about sales-related questions.`;
  }

  // Staff-related FAQ handling (Check in, Check out, Shift)
  private async handleStaffFAQ(userQuestion: string): Promise<string> {
    const questionLower = userQuestion.toLowerCase();
    if (questionLower.includes("add staff")) {
      return `To add a staff member, follow these steps:
        1. Navigate to the Staff tab in the side menu.
        2. Click on the "Add Staff" button.
        3. Provide the staff details.
        4. Click the "Add Staff" button when you are done.`;
    }
    if (questionLower.includes("update staff")) {
      return `To update a staff member, follow these steps:
        1. Navigate to the Staff tab in the side menu.
        2. Select the staff member you wish to update.
        3. Update the details.
        4. Click the "Save" button when you are done.`;
    }
    if (questionLower.includes("delete staff")) {
      return `To delete a staff member, follow these steps:
        1. Navigate to the Staff tab in the side menu.
        2. Select the staff member you wish to delete.
        3. Click the "Delete Staff" button when you are done.`;
    }
    if (questionLower.includes("check in")) {
      return `To check in, follow these steps:
        1. Navigate to the Check-in tab in the side menu.
        2. Provide your staff ID and unique 5-digit code.
        3. Click the "Check-in" button to check in.`;
    }
    if (questionLower.includes("check out")) {
      return `To check out, follow these steps:
        1. Navigate to the Check-in tab in the side menu.
        2. Click the "Check-out" button to check out from your shift.`;
    }
    if (questionLower.includes("create a shift")) {
      return `To create a shift, follow these steps:
        1. Navigate to the Shift tab in the side menu.
        2. Provide the shift name, start time, end time, check-in and check-out times, and shift type.
        3. Click the "Create Shift" button when you are done.`;
    }
    return `I'm sorry, but I couldn't understand your question. Please ask about staff-related questions.`;
  }

  // Support-related FAQ handling
  private async handleSupportFAQ(userQuestion: string): Promise<string> {
    const questionLower = userQuestion.toLowerCase();
    if (questionLower.includes("why is nothing retrieving")) {
      return `It seems like there might be a connection issue. Please check your network connection or try refreshing the page. If the problem persists, please contact support for further assistance.`;
    }
    return `I'm sorry, I couldn't understand your question. Please contact support for assistance.`;
  }

  // If input is incoherent or too jumbled, return an error message
  private async handleIncoherentInput(): Promise<string> {
    return 'Sorry, I could not understand your input. Please try again with a clearer question.';
  }
}
