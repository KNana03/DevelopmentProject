import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Suppliers } from '../Model/supplier';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SupplierService {
  apiUrl = 'https://localhost:7261/api/Supplier';

  constructor(private http: HttpClient) { }

  registerSupplier(supplier: Omit<Suppliers, 'id'>): Observable<Suppliers> {
    return this.http.post<Suppliers>(`${this.apiUrl}/register`, supplier);
  }

  getAllSuppliers(): Observable<Suppliers[]> {
    return this.http.get<Suppliers[]>(this.apiUrl);
  }


  getSupplierById(id: number): Observable<Suppliers> {
    return this.http.get<Suppliers>(`${this.apiUrl}/${id}`).pipe(
      catchError(error => {
        console.error(`Error fetching supplier with ID ${id}:`, error);
        throw error;
      })
    );
  }

  updateSupplier(supplier: Suppliers): Observable<Suppliers> {
    return this.http.put<Suppliers>(`${this.apiUrl}/${supplier.id}`, supplier);
  }

  deleteSupplier(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
