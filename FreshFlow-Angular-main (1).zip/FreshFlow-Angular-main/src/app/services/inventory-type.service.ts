import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { InventoryType } from '../Model/inventory-type';

@Injectable({
  providedIn: 'root'
})
export class InventoryTypeService {
  private apiUrl = 'https://localhost:7261/api/InventoryType'; // Ensure this matches your backend URL

  constructor(private http: HttpClient) { }

  createInventoryType(inventoryType: Omit<InventoryType, 'id'>): Observable<InventoryType> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<InventoryType>(`${this.apiUrl}/addInventoryType`, inventoryType, { headers });
  }

  getAllInventoryTypes(): Observable<InventoryType[]> {
    return this.http.get<InventoryType[]>(this.apiUrl);
  }

  updateInventoryType(id: number, inventoryType: InventoryType): Observable<InventoryType> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.put<InventoryType>(`${this.apiUrl}/${id}`, inventoryType, { headers });
  }

  deleteInventoryType(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
