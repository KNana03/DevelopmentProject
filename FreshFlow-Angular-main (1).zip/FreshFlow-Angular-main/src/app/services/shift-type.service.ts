import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ShiftType } from '../Model/shift-type';

@Injectable({
  providedIn: 'root'
})
export class ShiftTypeService {
  apiUrl = 'https://localhost:7261/api/ShiftType';

  constructor(private http: HttpClient) { }

  /*registerShiftType(shiftType: Omit<ShiftType, 'id'>): Observable<ShiftType> {
    return this.http.post<ShiftType>(`${this.apiUrl}/register`, shiftType);
  }
*/
  getAllShiftTypes(): Observable<ShiftType[]> {
    return this.http.get<ShiftType[]>(this.apiUrl);
  }

  getShiftTypes(): Observable<ShiftType[]> {
    return this.http.get<ShiftType[]>(this.apiUrl);
  }

  createShiftType(shiftType: Omit<ShiftType, 'id'>): Observable<ShiftType> {
    return this.http.post<ShiftType>(this.apiUrl, shiftType);
  }


  updateShiftType(id: number, shiftType: ShiftType): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, shiftType);
  }


  deleteShiftType(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
