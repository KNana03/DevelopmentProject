import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Suppliers } from '../Model/supplier';
import { Document } from '../Model/document';

@Injectable({
  providedIn: 'root'
})
export class SupplierDocumentService {
  private apiUrl = 'https://localhost:7261/api/Supplier';

  constructor(private http: HttpClient) { }

  getDocumentsBySupplierId(supplierId: number, fileType: string): Observable<Document[]> {
    const params = { fileType };
    return this.http.get<Document[]>(`${this.apiUrl}/${supplierId}/documents`, { params })
      .pipe(catchError(this.handleError));
  }


  uploadDocument(supplierId: number, formData: FormData): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/${supplierId}/documents`, formData)
      .pipe(catchError(this.handleError));
  }

  deleteDocument(documentId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/documents/${documentId}`)
      .pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    console.error(`Error: ${error.message}`);
    return throwError('An error occurred while processing the request.');
  }
}
