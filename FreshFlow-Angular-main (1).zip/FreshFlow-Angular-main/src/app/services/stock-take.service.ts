import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { StockTake } from '../Model/StockTake';

@Injectable({
  providedIn: 'root'
})
export class StockTakeService {
  private apiUrl = 'https://localhost:7261/api/StockTake'; // Adjust this URL as needed

  constructor(private http: HttpClient) { }

  getStockTakeByOrderId(orderId: number): Observable<StockTake> { // Ensure the return type is StockTake
    return this.http.get<StockTake>(`${this.apiUrl}/byOrder/${orderId}`);
  }

  createStockTake(stockTake: StockTake): Observable<StockTake> {
    return this.http.post<StockTake>(`${this.apiUrl}/create`, stockTake);
  }

  updateStockTake(stockTake: StockTake): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/update/${stockTake.id}`, stockTake);
  }
}
