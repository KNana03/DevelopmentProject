import { Injectable, HostListener } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, timer } from 'rxjs';
import { Router } from '@angular/router';
import { tap } from 'rxjs';
import { Subscription } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthserviceService {
  private apiUrl = 'https://localhost:7261/api/Authentication'; // Update with your backend URL
  private urlSession = 'https://localhost:7261/api/Session/set-timeout';

  private sessionTimeout!: number;
  private sessionTimeoutSubscription!: Subscription;
  private activityTimeoutSubscription!: Subscription;
  private timeoutDuration: number = 300000;
  private activityTimeout: number = 10000; // Time in milliseconds for user activity detection
  private lastActivityTime!: number;

  constructor(private http: HttpClient, private router: Router) {
    this.sessionTimeout = this.timeoutDuration; // Set your session timeout duration here
    this.initializeSessionTimeout();
    this.startActivityMonitor();
  }

  register(user: any): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(`${this.apiUrl}/Register`, user, { headers });
  }

  getCurrentUserName(): string {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user.username || 'Unknown';
  }

  confirmEmail(token: string, email: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.get(`${this.apiUrl}/ConfirmEmail`, {
      headers,
      params: {
        token,
        email,
      },
    });
  }

  login(credentials: any): Observable<any> {
    return this.http
      .post(`${this.apiUrl}/login`, credentials, {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
      })
      .pipe(
        tap((response: any) => {
          // Assuming the response contains the username
          const username = response.username; // Adjust this based on your actual API response structure
          if (username) {
            localStorage.setItem('user', JSON.stringify({ username })); // Save username to local storage
          }
        })
      );
  }

  forgotPassword(email: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(
      `${this.apiUrl}/forgot-password`,
      { email },
      { headers }
    );
  }

  verifyOTP(verifyOTPData: any): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(`${this.apiUrl}/verify-otp`, verifyOTPData, {
      headers,
    });
  }

  resetPassword(resetPasswordData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/reset-password`, resetPasswordData);
  }

  createRole(roleName: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(
      `${this.apiUrl}/CreateRole?roleName=${roleName}`,
      {},
      { headers }
    );
  }

  updateUserRole(
    emailAddress: string,
    oldRoleName: string,
    newRoleName: string
  ): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    // Append the parameters to the URL as query parameters
    const url = `${
      this.apiUrl
    }/UpdateUserRole?emailAddress=${encodeURIComponent(
      emailAddress
    )}&oldRoleName=${encodeURIComponent(
      oldRoleName
    )}&newRoleName=${encodeURIComponent(newRoleName)}`;

    // Perform the POST request
    return this.http.post(url, {}, { headers });
  }

  deleteUserRole(emailAddress: string, roleName: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(
      `${this.apiUrl}/DeleteUserRole`,
      { emailAddress, roleName },
      { headers }
    );
  }

  getUserRoles(emailAddress: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.get(
      `${this.apiUrl}/GetUserRoles?emailAddress=${emailAddress}`,
      { headers }
    );
  }

  assignRole(emailAddress: string, roleName: string): Observable<any> {
    const token = localStorage.getItem('token'); // Assuming token is stored in localStorage
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    const url = `${this.apiUrl}/AssignRole?emailAddress=${emailAddress}&roleName=${roleName}`;
    return this.http.post(url, null, { headers }); // Sending null as body since parameters are in URL
  }

  updatePassword(updatePasswordData: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    return this.http.post(`${this.apiUrl}/UpdatePassword`, updatePasswordData, {
      headers,
    });
  }

  // updateSessionTimeout(timeout: number): Observable<any> {
  //   return this.http.post(this.urlSession, timeout, {
  //     headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  //   }).pipe(
  //     tap(() => {
  //       localStorage.setItem('sessionTimeout', timeout.toString());
  //       this.startSessionTimer(timeout * 1000); // Ensure timeout is in milliseconds
  //     })
  //   );
  // }

  // private initializeSessionTimeout() {
  //   const timeout = parseInt(localStorage.getItem('sessionTimeout') || '60', 10) * 1000; // default to 60 seconds
  //   this.startSessionTimer(timeout);
  // }

  // private startSessionTimer(timeout: number) {
  //   if (timeout > 0) {
  //     // Clear any existing timer
  //     if (this.sessionTimeoutSubscription) {
  //       this.sessionTimeoutSubscription.unsubscribe();
  //     }

  //     this.sessionTimeoutSubscription = timer(timeout).subscribe(() => {
  //       this.redirectToLogin();
  //     });
  //   }
  // }

  // private startActivityMonitor() {
  //   this.lastActivityTime = Date.now();
  //   this.activityTimeoutSubscription = timer(0, this.activityTimeout).subscribe(() => {
  //     if (Date.now() - this.lastActivityTime > this.sessionTimeout) {
  //       this.redirectToLogin();
  //     }
  //   });
  // }

  // @HostListener('window:mousemove')
  // @HostListener('window:keydown')
  // @HostListener('window:click')
  // onUserActivity() {
  //   this.lastActivityTime = Date.now();
  // }

  // private redirectToLogin() {
  //   this.router.navigate(['/login']); // Adjust the route as needed
  // }

  // ngOnDestroy() {
  //   // Clean up subscriptions on service destruction
  //   if (this.sessionTimeoutSubscription) {
  //     this.sessionTimeoutSubscription.unsubscribe();
  //   }
  //   if (this.activityTimeoutSubscription) {
  //     this.activityTimeoutSubscription.unsubscribe();
  //   }
  // }
  private initializeSessionTimeout() {
    // Start the session timeout with the specified timeout duration
    this.startSessionTimer(this.sessionTimeout);
  }

  public setSessionTimeout(timeoutInSeconds: number) {
    this.sessionTimeout = timeoutInSeconds * 1000; // Convert seconds to milliseconds
    this.resetTimer(); // Reset the session timer with the new timeout
  }
  // public setSessionTimeout(timeoutInMinutes: number) {
  //   this.sessionTimeout = timeoutInMinutes * 60 * 1000; // Convert minutes to milliseconds
  //   this.resetTimer(); // Reset the session timer with the new timeout
  // }
  private startSessionTimer(timeout: number) {
    if (timeout > 0) {
      // Clear any existing timer
      if (this.sessionTimeoutSubscription) {
        this.sessionTimeoutSubscription.unsubscribe();
      }

      // Reset the session timeout on any detected activity
      this.sessionTimeoutSubscription = timer(timeout).subscribe(() => {
        this.redirectToLogin();
      });
    }
  }

  private startActivityMonitor() {
    this.lastActivityTime = Date.now();

    // Monitor for activity (mousemove, keydown, click) and reset the session timer
    window.addEventListener('mousemove', this.resetTimer.bind(this));
    window.addEventListener('keydown', this.resetTimer.bind(this));
    window.addEventListener('scroll', this.resetTimer.bind(this));
    window.addEventListener('click', this.resetTimer.bind(this));
  }

  private resetTimer() {
    this.lastActivityTime = Date.now();

    // Clear the current session timer and restart it
    if (this.sessionTimeoutSubscription) {
      this.sessionTimeoutSubscription.unsubscribe();
    }
    this.startSessionTimer(this.sessionTimeout); // Reset the session timeout
  }

  private redirectToLogin() {
    this.router.navigate(['/login']); // Redirect to the login page when the session times out
  }

  // Ensure to clean up the event listeners and subscriptions on service destruction
  ngOnDestroy() {
    if (this.sessionTimeoutSubscription) {
      this.sessionTimeoutSubscription.unsubscribe();
    }

    window.removeEventListener('mousemove', this.resetTimer.bind(this));
    window.removeEventListener('keydown', this.resetTimer.bind(this));
    window.removeEventListener('scroll', this.resetTimer.bind(this));
    window.removeEventListener('click', this.resetTimer.bind(this));
  }
}
