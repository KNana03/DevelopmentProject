import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Inventories } from '../Model/inventory';
import { Writeoffreasons } from '../Model/writeoffreason';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  apiUrl = 'https://localhost:7261/api/Inventory'; // Ensure this matches the backend URL

  constructor(private http: HttpClient) { }

  // Register a new inventory
  registerInventory(inventory: Omit<Inventories, 'id' | 'writeOffReason'>): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/addInventory`, inventory, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }).pipe(
      catchError(error => {
        console.error('Error adding inventory:', error);
        return throwError(error);
      })
    );
  }

  // Add multiple inventories
  addMultipleInventories(inventories: Inventories[]): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/importInventory`, inventories, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }).pipe(
      catchError(error => {
        console.error('Error adding multiple inventories:', error);
        return throwError(error);
      })
    );
  }

  // Get all inventories
  getAllInventories(): Observable<Inventories[]> {
    return this.http.get<Inventories[]>(this.apiUrl).pipe(
      catchError(error => {
        console.error('Error fetching inventories:', error);
        return throwError(error);
      })
    );
  }

  // Get a specific inventory by ID
  getInventory(id: string): Observable<Inventories> {
    return this.http.get<Inventories>(`${this.apiUrl}/${id}`).pipe(
      catchError(error => {
        console.error('Error fetching inventory:', error);
        return throwError(error);
      })
    );
  }

  // Update an inventory
  updateInventory(id: string, inventory: Inventories): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, inventory, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }).pipe(
      catchError(error => {
        console.error('Error updating inventory:', error);
        return throwError(error);
      })
    );
  }

  // Delete an inventory
  deleteInventory(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`).pipe(
      catchError(error => {
        console.error('Error deleting inventory:', error);
        return throwError(error);
      })
    );
  }

  getInventoryReport(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/inventory-report`).pipe(
      catchError(error => {
        console.error('Error fetching inventory report:', error);
        return throwError(error);
      })
    );
  }

  getInventoryTurnoverReport(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/inventory-turnover-report`).pipe(
      catchError(error => {
        console.error('Error fetching inventory turnover report:', error);
        return throwError(error);
      })
    );
  }

  addWriteOffReasonToInventory(inventoryId: number, writeOffReason: { reason: string; quantity: number }): Observable<any> {
    const dto = {
      InventoryId: inventoryId,
      Reason: writeOffReason.reason,
      Quantity: writeOffReason.quantity // Include the quantity in the DTO
    };
    return this.http.post<any>(`${this.apiUrl.replace('/Inventory', '/WriteOffReason')}/CreateInventoryWriteOffReason`, dto).pipe(
      catchError(error => {
        console.error('Error adding write-off reason to inventory:', error);
        return throwError(error);
      })
    );
  }
}
