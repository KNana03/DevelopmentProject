import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { AuthserviceService } from './authservice.service';
@Injectable({
  providedIn: 'root'
})
export class AnalyticsService {
  private apiUrl = 'https://localhost:7261/api/Analytics'; // Replace with your actual backend URL

  constructor(private http: HttpClient, private authService: AuthserviceService) { }

  getOrderMetrics(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/order-metrics`);
  }

  getPageRequests(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/page-requests`);
  }

  logPageRequest(pageName: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const userName = this.authService.getCurrentUserName();
    return this.http.post(`${this.apiUrl}/log-page-request`, { pageName, userName }, { headers });
  }

  resetPageRequests(): Observable<any> {
    return this.http.post(`${this.apiUrl}/reset-page-requests`, {});
  }
}
