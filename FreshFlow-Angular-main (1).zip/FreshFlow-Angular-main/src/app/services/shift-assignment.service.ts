import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShiftAssignmentService {
  private apiUrl = 'https://localhost:7261/api/ShiftAssignment';


  constructor(private http: HttpClient) { }
  // Fetch the list of assigned shifts for a specific staff member
  getAssignedShifts(staffId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/GetAssignedShifts/${staffId}`);
  }

  assignShift(staffId: number, shiftId: number): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/AssignShift/${staffId}/${shiftId}`, {});
  }

  // New method to fetch all assigned shifts
  getAllAssignedShifts(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/GetAllAssignedShifts`);
  }

  removeAssignedShift(assignmentId: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/RemoveAssignedShift/${assignmentId}`);
  }

}
