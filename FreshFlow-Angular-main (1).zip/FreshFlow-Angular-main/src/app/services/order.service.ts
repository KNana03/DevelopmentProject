import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Order } from '../Model/order';
import { PaymentType } from '../Model/paymentType';
import { CurrencyExchangeRate } from '../Model/CurrencyExchangeRate';
import { of } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class OrderService {
  public apiUrl = 'https://localhost:7261/api/Order';
  private stocktakeUrl = 'https://localhost:7261/api/StockTake';

  constructor(private http: HttpClient) { }

  // Fetch all orders
  getAllOrders(): Observable<Order[]> {
    return this.http.get<Order[]>(this.apiUrl);
  }

  // Fetch a single order by ID
  getOrderById(id: number): Observable<Order> {
    return this.http.get<Order>(`${this.apiUrl}/${id}`);
  }

  // Create a new order with currency code
  createOrder(order: Order): Observable<Order> {
    return this.http.post<Order>(`${this.apiUrl}/capture`, order);
  }

  // Update an existing order
  updateOrder(order: Order): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/update/${order.id}`, order);
  }

  // Mark an order as received
  receiveOrder(id: number): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/receive/${id}`, {});
  }

  // Mark an order as paid
  paySupplier(id: number): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/pay/${id}`, {});
  }

  // Delete an order
  deleteOrder(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  // Update the status of an order
  updateOrderStatus(id: number, isPaid: boolean): Observable<void> {
    const url = `${this.apiUrl}/updateStatus/${id}`;
    const body = { OrderId: id, IsPaid: isPaid };
    return this.http.put<void>(url, body);
  }

  // Fetch all payment types
  getPaymentTypes(): Observable<PaymentType[]> {
    return this.http.get<PaymentType[]>(`${this.apiUrl}/paymenttypes`);
  }

  // Create a stock take
  createStockTake(stockTake: any): Observable<any> {
    return this.http.post(`${this.stocktakeUrl}/create`, stockTake);
  }

  // Fetch all exchange rates

  // Method to initiate a payment via PayFast
  initiatePayment(order: Order): Observable<any> {
    const paymentData: { [key: string]: string | number | undefined } = {
      merchant_id: '10034517', // Replace with your actual merchant ID
      merchant_key: '9oiezzzun73s0', // Replace with your actual merchant key
      return_url: `http://localhost:8100/view-orders?orderId=${order.id}&status=success`,
      cancel_url: `http://localhost:8100/view-orders?orderId=${order.id}&status=cancel`,
      notify_url: '', // URL for payment notifications
      name_first: 'First Name', // Replace with customer's first name
      name_last: 'Last Name', // Replace with customer's last name
      email_address: 'customer-email@example.com', // Replace with customer's email
      m_payment_id: order.id, // Order ID
      amount: order.price.toFixed(2), // Order amount
      item_name: `Payment for Order #${order.id}`, // Order description
    };

    // Create form data for POST request
    const formData: FormData = new FormData();
    for (const key in paymentData) {
      if (paymentData.hasOwnProperty(key) && paymentData[key] !== undefined) {
        formData.append(key, paymentData[key] as string);
      }
    }

    const payfastUrl = 'https://sandbox.payfast.co.za/eng/process';

    // Returning the form data and PayFast URL
    return of({ formData, payfastUrl });
  }


}
