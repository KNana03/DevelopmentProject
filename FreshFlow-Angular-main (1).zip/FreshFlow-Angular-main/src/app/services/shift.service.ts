import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Shift } from '../Model/shift';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ShiftService {
  apiUrl = 'https://localhost:7261/api/Shift';

  constructor(private http: HttpClient) { }

  /*createShift(shift: Omit<Shift, 'id'>): Observable<Shift> {
    return this.http.post<Shift>(`${this.apiUrl}/CreateShift`, shift).pipe(
      catchError(this.handleError)
    );
  }*/
  createShift(shift: Omit<Shift, 'id'>): Observable<Shift> {
    return this.http.post<Shift>(this.apiUrl, shift).pipe(
      catchError(this.handleError)
    );
  }


  getAllShifts(): Observable<Shift[]> {
    return this.http.get<Shift[]>(this.apiUrl).pipe(
      catchError(this.handleError)
    );
  }

  getShiftById(id: string): Observable<Shift> {
    return this.http.get<Shift>(`${this.apiUrl}/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  updateShift(id: string, shift: Shift): Observable<Shift> {
    return this.http.put<Shift>(`${this.apiUrl}/${id}`, shift).pipe(
      catchError(this.handleError)
    );
  }

  deleteShift(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'Unknown error!';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}\nDetails: ${JSON.stringify(error.error)}`;
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }

  getShiftReport(): Observable<any> {
    return this.http.get<any>(this.apiUrl);
  }

  getShiftsByDate(date: string): Observable<Shift[]> {
    return this.http.get<Shift[]>(`/api/shifts/${date}`);
  }

  // Method to get shifts by date range
  getShiftsByDateRange(startDate: string, endDate: string): Observable<Shift[]> {
    const params = { startDate, endDate };
    return this.http.get<Shift[]>(this.apiUrl, { params });
  }
}



