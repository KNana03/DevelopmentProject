import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ReturnedStock } from '../Model/returned-stock';

@Injectable({
  providedIn: 'root',
})
export class ReturnService {
  private apiUrl = 'https://localhost:7261/api/Sales'; // Ensure this URL matches your backend

  constructor(private http: HttpClient) {}

  // POST: Add a new returned stock
  addReturnedStock(returnedStock: ReturnedStock): Observable<any> {
    return this.http.post(`${this.apiUrl}/return-stock`, returnedStock);
  }

  // GET: Fetch all returned stock
  getReturnedStock(): Observable<ReturnedStock[]> {
    return this.http.get<ReturnedStock[]>(`${this.apiUrl}/returned-stock`);
  }
}

