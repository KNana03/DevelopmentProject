import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from '../Model/products';
import { ProductViewModel } from '../Model/newproduct';
import { Brand } from '../Model/brand';
import { Category } from '../Model/category';
import { VAT } from '../Model/VAT';
import { CustomerReview } from '../Model/CustomerReview';
import { Warehouse } from '../Model/Warehouse';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private viewapiUrl = 'https://localhost:7261/api/Product';
  private brandapiUrl = 'https://localhost:7261/api/Brand';
  private categoryapiUrl = 'https://localhost:7261/api/Category';
  private vatApiUrl = 'https://localhost:7261/api/VAT';
  private warehouseapiUrl = 'https://localhost:7261/api/Warehouse';
  private countryapiUrl = 'https://localhost:7261/api/Country';
  constructor(private http: HttpClient) { }

  // To do with products
  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.viewapiUrl}/GetAllProducts`);
  }

  addProduct(product: ProductViewModel): Observable<any> {
    return this.http.post<any>(`${this.viewapiUrl}/addProducts`, product);
  }

  updateProduct(productId: number, product: Product): Observable<Product> {
    const url = `${this.viewapiUrl}/UpdateProduct?id=${productId}`;
    return this.http.put<Product>(url, product, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
  }

  deleteProduct(productId: number): Observable<void> {
    return this.http.delete<void>(`${this.viewapiUrl}/DeleteProduct/${productId}`);
  }

  // To do with brands
  getBrands(): Observable<Brand[]> {
    return this.http.get<Brand[]>(`${this.brandapiUrl}/GetBrands`);
  }

  addBrand(brand: Brand): Observable<Brand> {
    return this.http.post<Brand>(`${this.brandapiUrl}/AddBrand`, brand, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
  }

  // To do with categories
  getCategories(): Observable<Category[]> {
    return this.http.get<Category[]>(`${this.categoryapiUrl}/GetCategories`);
  }
  getLowStockProducts(threshold: number = 50): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.viewapiUrl}/GetLowStockProducts?threshold=${threshold}`);
  }
  addCategory(category: Category): Observable<Category> {
    return this.http.post<Category>(`${this.categoryapiUrl}/AddCategory`, category, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
  }

  getVAT(): Observable<VAT[]> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.get<VAT[]>(`${this.vatApiUrl}/GetVAT`, { headers });
  }

  updateVAT(id: number, amount: number): Observable<VAT> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const body = { amount };
    return this.http.put<VAT>(`${this.vatApiUrl}/UpdateVAT?id=${id}`, body, { headers });
  }

  // Customer Review Methods
  getReviewsByProductId(productId: number): Observable<CustomerReview[]> {
    return this.http.get<CustomerReview[]>(`${this.viewapiUrl}/GetReviewsByProductId/${productId}`);
  }

  addReviewToProduct(productId: number, review: CustomerReview): Observable<CustomerReview> {
    return this.http.post<CustomerReview>(`${this.viewapiUrl}/AddReviewToProduct/${productId}`, review, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
  }

  getWarehouses(): Observable<Warehouse[]> {
    return this.http.get<Warehouse[]>(`${this.warehouseapiUrl}/GetWarehouses`);
  }

  addWarehouse(warehouse: any): Observable<any> {
    return this.http.post(`${this.warehouseapiUrl}/AddWarehouse`, warehouse);
  }

  getWarehouseById(id: number): Observable<Warehouse> {
    return this.http.get<Warehouse>(`${this.warehouseapiUrl}/warehouses/${id}`);
  }

  updateWarehouse(id: number, warehouse: Warehouse): Observable<any> {
    return this.http.put(`${this.warehouseapiUrl}/warehouses/${id}`, warehouse);
  }

  deleteWarehouse(id: number): Observable<void> {
    return this.http.delete<void>(`${this.warehouseapiUrl}/DeleteWarehouse/${id}`);
  }

  getCountries(): Observable<any[]> {
    return this.http.get<any[]>(`${this.countryapiUrl}/GetCountries`);
  }

  getStatesByCountryId(countryId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.countryapiUrl}/GetStatesByCountryId/${countryId}`);
  }

  getCitiesByStateId(stateId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.countryapiUrl}/GetCitiesByStateId/${stateId}`);
  }


}
