import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Staffs } from '../Model/staff';

@Injectable({
  providedIn: 'root'
})
export class StaffService {
  apiUrl = 'https://localhost:7261/api/Staff'; // Replace with your actual API URL

  constructor(private http: HttpClient) { }

  registerStaff(staffData: Omit<Staffs, 'id'>): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/Register`, staffData);
  }

  getAllStaffs(): Observable<Staffs[]> {
    return this.http.get<Staffs[]>(this.apiUrl);
  }

  getStaffById(id: string): Observable<Staffs> {
    return this.http.get<Staffs>(`${this.apiUrl}/${id}`);
  }

  updateStaffProfile(id: string, staff: Staffs): Observable<Staffs> {
    return this.http.put<Staffs>(`${this.apiUrl}/${id}`, staff);
  }

  deleteStaffProfile(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
