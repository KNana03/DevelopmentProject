import { TestBed } from '@angular/core/testing';

import { WriteoffreasonService } from './writeoffreason.service';

describe('WriteoffreasonService', () => {
  let service: WriteoffreasonService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WriteoffreasonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});