import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Writeoffreasons } from '../Model/writeoffreason';

@Injectable({
  providedIn: 'root'
})
export class WriteoffreasonService {

  apiUrl = 'https://localhost:7261/api/WriteOffReason'; // Replace with your actual API URL

  constructor(private http: HttpClient) { }

  registerWriteoffreason(writeoffreason: Omit<Writeoffreasons, 'id'>): Observable<Writeoffreasons> {
    return this.http.post<Writeoffreasons>(`${this.apiUrl}/CreateInventoryWriteOffReason`, writeoffreason);
  }

  getAllWriteoffreasons(): Observable<Writeoffreasons[]> {
    return this.http.get<Writeoffreasons[]>(this.apiUrl);
  }

  updateWriteoffreason(id: string, writeoffreason: Writeoffreasons): Observable<Writeoffreasons> {
    return this.http.put<Writeoffreasons>(`${this.apiUrl}/${id}`, writeoffreason);
  }

  deleteWriteoffreason(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
