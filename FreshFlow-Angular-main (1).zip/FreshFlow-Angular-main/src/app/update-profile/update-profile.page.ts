import { Component, OnInit } from '@angular/core';
import { NavController, PopoverController } from '@ionic/angular'; 
import { Admins } from '../Model/admin';
import { AdminService } from '../services/admin.service';
import { Router } from '@angular/router';
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.page.html',
  styleUrls: ['./update-profile.page.scss'],
})
export class UpdateProfilePage implements OnInit {
  userData: Admins = {
    id: '',
    username: '',
    email: '',
    firstName: '',
    lastName: '',
    password: '',
    profilePhoto: ''
  };
  confirmPassword = '';

  constructor(
    private navCtrl: NavController,
    private router: Router,
    private adminService: AdminService,
    private popoverController: PopoverController 
  ) { }

  ngOnInit() {
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      const state = navigation.extras.state as { [key: string]: any };
      if (state['admin']) {
        this.userData = state['admin'];
      }
    }
  }

  // Validate email format using regex
  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  updateProfile() {
    // Check if the passwords match
    if (this.userData.password !== this.confirmPassword) {
      alert('Passwords do not match!');
      return;
    }

    // Check if the email is valid
    if (!this.isValidEmail(this.userData.email)) {
      alert('Please enter a valid email address.');
      return;
    }

    // Call the service to update the profile
    this.adminService.updateAdminProfile(this.userData.id, this.userData).subscribe(
      response => {
        console.log('Profile updated successfully', response);
        alert('Profile updated successfully');
        this.navCtrl.navigateForward('/view-profile');
      },
      error => {
        console.error('Profile update failed', error);
        alert(this.getErrorMessage(error));
      }
    );
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to update profile due to invalid input. Please check the fields and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while updating the profile. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    switch (field) {
      case 'username':
        hintMessage = "Enter a unique username for your profile.";
        break;
      case 'email':
        hintMessage = "Enter a valid email address.";
        break;
      case 'firstName':
        hintMessage = "Enter your first name.";
        break;
      case 'lastName':
        hintMessage = "Enter your last name.";
        break;
      case 'password':
        hintMessage = "Enter a password with at least 6 characters.";
        break;
      case 'confirmPassword':
        hintMessage = "Re-enter your password for confirmation.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage },
      translucent: true,
    });
    return await popover.present();
  }
}
