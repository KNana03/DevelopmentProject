import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreateInventoryTypePage } from './create-inventory-type.page';

const routes: Routes = [
  {
    path: '',
    component: CreateInventoryTypePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CreateInventorytypePageRoutingModule { }
