import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { InventoryType } from '../Model/inventory-type';
import { InventoryTypeService } from '../services/inventory-type.service';

@Component({
  selector: 'app-create-inventory-type',
  templateUrl: './create-inventory-type.page.html',
  styleUrls: ['./create-inventory-type.page.scss'],
})
export class CreateInventoryTypePage {
  inventoryTypeData: Omit<InventoryType, 'id'> = {
    typeName: '',
    description: ''
  };

  constructor(private navCtrl: NavController, private inventoryTypeService: InventoryTypeService) { }

  navigateToViewInventoryType() {
    this.navCtrl.navigateForward(['/view-inventory-type']);
  }

  register() {
    if (!this.inventoryTypeData.typeName || !this.inventoryTypeData.description) {
      alert('Please fill in all fields.');
      return;
    }

    console.log('Registering inventory type with data:', this.inventoryTypeData);

    this.inventoryTypeService.createInventoryType(this.inventoryTypeData).subscribe(
      response => {
        console.log('Inventory type has been added successfully', response);
        this.navigateToViewInventoryType();
        alert('Inventory type has been added successfully');
      },
      error => {
        console.error('Add error', error);
        alert('Inventory type could not be added. Please try again.');
      }
    );
  }
}
