import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateInventorytypePage } from './create-inventory-type.page';

describe('CreateInventorytypePage', () => {
  let component: CreateInventorytypePage;
  let fixture: ComponentFixture<CreateInventorytypePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateInventorytypePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
