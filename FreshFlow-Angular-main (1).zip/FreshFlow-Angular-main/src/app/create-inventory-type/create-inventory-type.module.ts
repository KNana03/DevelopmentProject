import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateInventorytypePageRoutingModule } from './create-inventory-type-routing.module';

import { CreateInventoryTypePage } from './create-inventory-type.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateInventorytypePageRoutingModule
  ],
  declarations: [CreateInventoryTypePage]
})
export class CreateInventorytypePageModule { }

