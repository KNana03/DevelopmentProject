import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DeleteInventorytypeModalPageRoutingModule } from './delete-inventory-type-modal-routing.module';

import { DeleteInventorytypeModalPage } from './delete-inventory-type-modal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DeleteInventorytypeModalPageRoutingModule
  ],
  declarations: [DeleteInventorytypeModalPage]
})
export class DeleteInventorytypeModalPageModule {}