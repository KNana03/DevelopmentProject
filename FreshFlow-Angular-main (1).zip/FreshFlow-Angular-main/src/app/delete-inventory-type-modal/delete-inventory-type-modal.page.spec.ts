import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DeleteInventorytypeModalPage } from './delete-inventory-type-modal.page';

describe('DeleteInventorytypeModalComponent', () => {
  let component: DeleteInventorytypeModalPage;
  let fixture: ComponentFixture<DeleteInventorytypeModalPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteInventorytypeModalPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DeleteInventorytypeModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
