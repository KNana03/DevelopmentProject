import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-inventory-type-modal',
  templateUrl: './delete-inventory-type-modal.page.html',
  styleUrls: ['./delete-inventory-type-modal.page.scss'],
})
export class DeleteInventorytypeModalPage implements OnInit {

  constructor(
    private modalController: ModalController,
    private router: Router
  ) { }

  ngOnInit() { }

  closeModal() {
    this.modalController.dismiss().then(() => {
      this.router.navigate(['/view-inventory-type']);
    }).catch((error) => {
      console.error('Error closing modal', error);
      alert('Failed to close the modal. Please try again.');
    });
  }

  confirmDeletion() {
    try {
      // Add logic for inventory type deletion here

      // After deletion logic, navigate back to the inventory type page
      this.router.navigate(['/view-inventory-type']).then(() => {
        // Dismiss the modal once navigation is successful
        this.modalController.dismiss();
      }).catch((error) => {
        console.error('Error navigating to view-inventory-type', error);
        alert('Failed to navigate to the inventory type view. Please try again.');
      });
    } catch (error) {
      console.error('Error during deletion process', error);
      alert('An error occurred while deleting the inventory type. Please try again.');
    }
  }

}
