import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { LOCALE_ID } from '@angular/core';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { PdfViewerModalComponent } from './pdf-viewer-modal/pdf-viewer-modal.component';

// Import services
import { AdminService } from './services/admin.service';
import { SupplierService } from './services/supplier.service';
import { StaffService } from './services/staff.service';
import { ProductService } from './services/product.service';
import { InventoryService } from './services/inventory.service';
import { InventoryTypeService } from './services/inventory-type.service';
import { AuthserviceService } from './services/authservice.service';
import { ShiftService } from './services/shift.service';
import { SalesService } from './services/sales.service';
import { AddReviewPageRoutingModule } from './add-review/add-review-routing.module';
import { AddReviewPage } from './add-review/add-review.page';
// Import modules
import { NgxEchartsModule } from 'ngx-echarts';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer';
import { CalendarComponent } from './calendar/calendar.component';
import { ActivityLogComponent } from './activity-log/activity-log.component';
import { registerLocaleData, CurrencyPipe } from '@angular/common';
import localeZa from '@angular/common/locales/en-ZA';
import { ViewWarehousesPageModule } from './warehouses/view-warehouse/view-warehouses.module';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './auth.interceptor';
import { HintPopoverComponentComponent } from './hint-popover-component/hint-popover-component.component';

// Register the locale data
registerLocaleData(localeZa, 'en-ZA');

@NgModule({
  declarations: [
    AppComponent,
    CalendarComponent,
    PdfViewerModalComponent,
    HintPopoverComponentComponent,

    ActivityLogComponent // Ensure CalendarComponent is declared here
  ],
  imports: [
    BrowserModule,
    PdfViewerModule,
    HttpClientModule,
    NgxExtendedPdfViewerModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    MatTableModule,
    MatSortModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatPaginatorModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatButtonModule,
    AddReviewPageRoutingModule,
    FormsModule,
    ViewWarehousesPageModule,
    NgxEchartsModule.forRoot({
      echarts: () => import('echarts')
    })
  ],
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    { provide: LOCALE_ID, useValue: 'en-ZA' }, // Set the default locale to en-ZA
    CurrencyPipe, // Provide the CurrencyPipe for use throughout the application
    SupplierService,
    AdminService,
    StaffService,
    ProductService,
    AuthserviceService,
    InventoryService,
    InventoryTypeService,
    ShiftService,
    SalesService
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
