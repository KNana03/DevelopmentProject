import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SixthhelpmodalPage } from './sixthhelpmodal.page';

const routes: Routes = [
  {
    path: '',
    component: SixthhelpmodalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SixthhelpmodalPageRoutingModule {}
