import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SixthhelpmodalPageRoutingModule } from './sixthhelpmodal-routing.module';

import { SixthhelpmodalPage } from './sixthhelpmodal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SixthhelpmodalPageRoutingModule
  ],
  declarations: [SixthhelpmodalPage]
})
export class SixthhelpmodalPageModule {}
