import { Component } from '@angular/core';
import { NavController, PopoverController } from '@ionic/angular';
import { Admins } from '../Model/admin';
import { AdminService } from '../services/admin.service';
import { Router } from '@angular/router';
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component'; // Import the HintPopoverComponent

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.page.html',
  styleUrls: ['./create-profile.page.scss'],
})
export class CreateProfilePage {
  userData: Omit<Admins, 'id'> = {
    username: '',
    email: '',
    firstName: '',
    lastName: '',
    password: ''
  };

  confirmPassword = '';
  formSubmitted = false;

  constructor(private navCtrl: NavController, private adminService: AdminService, private router: Router, private popoverController: PopoverController) { }

  navigateToSupplier() {
    this.router.navigate(['/view-supplier']);
  }

  navigateToViewProfile() {
    this.navCtrl.navigateForward(['/view-profile']);
  }

  register() {
    this.formSubmitted = true;
  
    // Validate that all fields are filled
    if (!this.userData.username.trim() || !this.userData.email.trim() || !this.userData.firstName.trim() || !this.userData.lastName.trim() || !this.userData.password.trim()) {
      alert('Please fill in all the fields');
      return;
    }
  
    // Validate email format
    if (!this.isValidEmail(this.userData.email)) {
      alert('Please enter a valid email address');
      return;
    }
  
    // Validate password confirmation
    if (this.userData.password !== this.confirmPassword) {
      alert('Passwords do not match!');
      return;
    }
  
    // Call the service to register the admin
    this.adminService.registerAdmin(this.userData).subscribe(
      response => {
        console.log('Registration successful', response);
        alert('Profile created successfully');
        this.navigateToViewProfile();
      },
      error => {
        // Check for email conflict error (409 status)
        if (error.status === 409) {
          alert('The email address is already registered. Please use a different email.');
        } else if (error.status === 400) {
          alert('Failed to register due to invalid input. Please check your details and try again.');
        } else if (error.status === 500) {
          alert('Server error occurred while registering the profile. Please try again later.');
        } else if (error.status === 0) {
          alert('Network error. Please check your connection.');
        } else {
          alert('An unexpected error occurred while registering the profile. Please try again.');
        }
      }
    );
  }
  
  // Changed from private to public
  public isValidEmail(email: string): boolean {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
  }

  private getErrorMessage(error: any, action: string): string {
    if (error.status === 400) {
      return `Failed to ${action} due to invalid input. Please check your details and try again.`;
    } else if (error.status === 500) {
      return `Server error occurred while ${action}. Please try again later.`;
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return `An unexpected error occurred while ${action}. Please try again.`;
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'username':
        hintMessage = "Enter a unique username that you will use to log in, e.g., 'User01'.";
        break;
      case 'email':
        hintMessage = "Enter a valid email address, e.g., 'user@gmail.com'.";
        break;
      case 'firstName':
        hintMessage = "Enter your first name, e.g., 'John'.";
        break;
      case 'lastName':
        hintMessage = "Enter your last name, e.g., 'Doe'.";
        break;
      case 'password':
        hintMessage = "Enter a strong password, at least 8 characters long.";
        break;
      case 'confirmPassword':
        hintMessage = "Re-enter your password to confirm it matches the first one.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
