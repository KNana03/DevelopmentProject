import { Component, OnInit, Input } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { ReturnService } from '../services/return.service'; // This is the service to handle returned stock
import { Router } from '@angular/router';
import { Sales } from '../Model/sales';

@Component({
  selector: 'app-return-stock-modal',
  templateUrl: './return-stock-modal.page.html',
  styleUrls: ['./return-stock-modal.page.scss'],
})
export class ReturnStockModalPage implements OnInit {
  @Input() sale: Sales | null = null;
  returnReason: string = '';
  returnQuantity: number = 0; // Ensure this is set by the user or by default to 1

  constructor(
    private modalController: ModalController,
    private returnService: ReturnService,  // Service to handle returned stock
    private router: Router  // Add the router to handle navigation
  ) {}

  ngOnInit() {}

  submitReturn() {
    if (this.sale && this.returnReason && this.returnQuantity > 0) {
      const returnedStock = {
        inventoryId: this.sale.inventoryId,
        staffId: this.sale.staffId,
        saleId: this.sale.id,
        quantity: this.returnQuantity, // Make sure returnQuantity is set
        reason: this.returnReason,
        returnDate: new Date(),
      };

      this.returnService.addReturnedStock(returnedStock).subscribe({
        next: (response) => {
          console.log('Return stock added successfully', response);

          // Navigate to the Returned Stock page
          this.router.navigate(['/returned-stock']);

          // Dismiss the modal after navigation (optional)
          this.modalController.dismiss({
            returned: true, // Pass back the success flag
          });
        },
        error: (error) => {
          console.error('Error adding return stock', error);
          this.modalController.dismiss({
            returned: false, // Pass back the failure flag
          });
        },
      });
    }
  }

  closeModal() {
    this.modalController.dismiss();
  }
}
