import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ReturnStockModalPageRoutingModule } from './return-stock-modal-routing.module';

import { ReturnStockModalPage } from './return-stock-modal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReturnStockModalPageRoutingModule
  ],
  declarations: [ReturnStockModalPage]
})
export class ReturnStockModalPageModule {}
