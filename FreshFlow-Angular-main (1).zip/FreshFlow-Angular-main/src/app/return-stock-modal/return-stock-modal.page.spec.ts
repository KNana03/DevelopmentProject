import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReturnStockModalPage } from './return-stock-modal.page';

describe('ReturnStockModalPage', () => {
  let component: ReturnStockModalPage;
  let fixture: ComponentFixture<ReturnStockModalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturnStockModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
