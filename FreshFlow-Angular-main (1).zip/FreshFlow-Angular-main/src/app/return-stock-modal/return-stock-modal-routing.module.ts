import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ReturnStockModalPage } from './return-stock-modal.page';

const routes: Routes = [
  {
    path: '',
    component: ReturnStockModalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReturnStockModalPageRoutingModule {}
