import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';


interface ExtractedInvoice {
  invoiceNumber: string;
  supplier: string;
  totalAmount: number; // Ensure totalAmount is of type number for calculations
  // Add other relevant fields as needed
}

@Component({
  selector: 'app-file-reader',
  templateUrl: './file-reader.page.html',
  styleUrls: ['./file-reader.page.scss'],
})
export class FileReaderPage {
  isUploading: boolean = false;
  extractedInvoices: ExtractedInvoice[] = [];
  approvedInvoices: ExtractedInvoice[] = [];
  pendingInvoices: ExtractedInvoice[] = [];
  totalInvoicesProcessed: number = 0;
  totalAmountProcessed: number = 0;
  averageInvoiceAmount: number = 0;
  pendingAmount: number = 0;

  constructor(private http: HttpClient) {
    this.loadApprovedInvoices();
    this.calculateSummary(); // Initial calculation for pre-loaded approved invoices
  }

  onFilesSelected(event: any): void {
    const files: FileList = event.target.files;
    if (files.length > 0) {
      this.isUploading = true;
      this.extractedInvoices = []; // Reset the list for fresh data
      this.pendingInvoices = []; // Reset pending invoices as well

      const promises = Array.from(files).map((file) => this.processFile(file));

      Promise.all(promises)
        .then((results) => {
          this.extractedInvoices = results.filter(result => result !== null) as ExtractedInvoice[];
          this.pendingInvoices = [...this.extractedInvoices]; // Initialize pending invoices with the new set
          this.isUploading = false;
        })
        .catch((error) => {
          console.error('Error processing files:', error);
          this.isUploading = false;
        });
    }
  }

  private async processFile(file: File): Promise<ExtractedInvoice | null> {
    if (file.type !== 'application/pdf') {
      alert('Please upload a valid PDF file.');
      return null;
    }

    const formData = new FormData();
    formData.append('pdfFile', file, file.name);

    try {
      const response = await this.http.post<ExtractedInvoice>('https://localhost:7261/api/pdf/extract-info', formData).toPromise();
      if (response) {
        response.totalAmount = parseFloat(response.totalAmount.toString().replace(/,/g, ''));
      }
      return response || null;
    } catch (error) {
      console.error(`Error extracting information from ${file.name}:`, error);
      return null;
    }
  }

  approveInvoice(invoice: ExtractedInvoice): void {
    // Move the invoice from pending to approved
    this.approvedInvoices.push(invoice);
    this.pendingInvoices = this.pendingInvoices.filter(inv => inv !== invoice);

    // Save approved invoices to local storage
    this.saveApprovedInvoices();

    // Recalculate the summary information
    this.calculateSummary();
  }

  private calculateSummary(): void {
    this.totalInvoicesProcessed = this.approvedInvoices.length;
    this.totalAmountProcessed = this.approvedInvoices.reduce((acc, invoice) => acc + invoice.totalAmount, 0);
    this.averageInvoiceAmount = this.totalInvoicesProcessed ? this.totalAmountProcessed / this.totalInvoicesProcessed : 0;
    this.pendingAmount = this.pendingInvoices.reduce((acc, invoice) => acc + invoice.totalAmount, 0);
  }

  saveApprovedInvoices(): void {
    localStorage.setItem('approvedInvoices', JSON.stringify(this.approvedInvoices));
  }

  loadApprovedInvoices(): void {
    const data = localStorage.getItem('approvedInvoices');
    if (data) {
      this.approvedInvoices = JSON.parse(data);
    }
  }
}