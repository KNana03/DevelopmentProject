import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FileReaderPage } from './file-reader.page';

const routes: Routes = [
  {
    path: '',
    component: FileReaderPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FileReaderPageRoutingModule {}
