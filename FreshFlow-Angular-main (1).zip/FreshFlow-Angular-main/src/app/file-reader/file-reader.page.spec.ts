import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FileReaderPage } from './file-reader.page';

describe('FileReaderPage', () => {
  let component: FileReaderPage;
  let fixture: ComponentFixture<FileReaderPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(FileReaderPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
