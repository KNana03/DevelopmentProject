import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FileReaderPageRoutingModule } from './file-reader-routing.module';

import { FileReaderPage } from './file-reader.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FileReaderPageRoutingModule
  ],
  declarations: [FileReaderPage]
})
export class FileReaderPageModule {}
