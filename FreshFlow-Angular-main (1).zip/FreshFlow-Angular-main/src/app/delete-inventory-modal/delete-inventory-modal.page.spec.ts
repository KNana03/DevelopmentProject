import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DeleteInventoryModalPage } from './delete-inventory-modal.page';

describe('DeleteInventoryModalPage', () => {
  let component: DeleteInventoryModalPage;
  let fixture: ComponentFixture<DeleteInventoryModalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteInventoryModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
