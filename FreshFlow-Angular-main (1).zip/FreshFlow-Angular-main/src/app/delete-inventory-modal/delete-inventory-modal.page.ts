import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-inventory-modal',
  templateUrl: './delete-inventory-modal.page.html',
  styleUrls: ['./delete-inventory-modal.page.scss'],
})
export class DeleteInventoryModalPage implements OnInit {

  constructor(
    private modalController: ModalController,
    private router: Router
  ) { }

  ngOnInit() {
  }

  closeModal() {
    this.modalController.dismiss().then(() => {
      this.router.navigate(['/view-delete-inventory']);
    }).catch((error) => {
      console.error('Error closing modal', error);
      alert('Failed to close the modal. Please try again.');
    });
  }

  confirmDeletion() {
    try {
      // Add logic for inventory deletion here

      // After deletion logic, navigate back to the inventory page
      this.router.navigate(['/view-inventory']).then(() => {
        // Dismiss the modal once navigation is successful
        this.modalController.dismiss();
      }).catch((error) => {
        console.error('Error navigating to view-inventory', error);
        alert('Failed to navigate to the inventory view. Please try again.');
      });
    } catch (error) {
      console.error('Error during deletion process', error);
      alert('An error occurred while deleting the inventory. Please try again.');
    }
  }

}
