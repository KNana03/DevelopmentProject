import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DeleteInventoryModalPageRoutingModule } from './delete-inventory-modal-routing.module';

import { DeleteInventoryModalPage } from './delete-inventory-modal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DeleteInventoryModalPageRoutingModule
  ],
  declarations: [DeleteInventoryModalPage]
})
export class DeleteInventoryModalPageModule {}
