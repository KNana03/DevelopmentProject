import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ThirdhelpmodalPage } from './thirdhelpmodal.page';

describe('ThirdhelpmodalPage', () => {
  let component: ThirdhelpmodalPage;
  let fixture: ComponentFixture<ThirdhelpmodalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ThirdhelpmodalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
