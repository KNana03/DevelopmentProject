import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'app-thirdhelpmodal',
  templateUrl: './thirdhelpmodal.page.html',
  styleUrls: ['./thirdhelpmodal.page.scss'],
})
export class ThirdhelpmodalPage implements OnInit {

  constructor(private navCtrl: NavController) { }

  ngOnInit() {
    const iframe = document.getElementById('help-frame') as HTMLIFrameElement;
    iframe.onload = () => {
      iframe.contentWindow?.postMessage('add-admin', '*');
    };
  }

  dismissModal() {
    this.navCtrl.back();
  }
}
