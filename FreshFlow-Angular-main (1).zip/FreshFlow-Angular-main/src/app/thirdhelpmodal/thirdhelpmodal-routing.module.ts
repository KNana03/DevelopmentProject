import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ThirdhelpmodalPage } from './thirdhelpmodal.page';

const routes: Routes = [
  {
    path: '',
    component: ThirdhelpmodalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ThirdhelpmodalPageRoutingModule {}
