import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ThirdhelpmodalPageRoutingModule } from './thirdhelpmodal-routing.module';

import { ThirdhelpmodalPage } from './thirdhelpmodal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ThirdhelpmodalPageRoutingModule
  ],
  declarations: [ThirdhelpmodalPage]
})
export class ThirdhelpmodalPageModule {}
