import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateSupplierPage } from './create-supplier.page';

describe('CreateSupplierPage', () => {
  let component: CreateSupplierPage;
  let fixture: ComponentFixture<CreateSupplierPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateSupplierPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
