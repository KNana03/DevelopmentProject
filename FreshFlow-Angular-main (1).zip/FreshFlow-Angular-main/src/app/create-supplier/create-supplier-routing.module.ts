import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreateSupplierPage } from './create-supplier.page';

const routes: Routes = [
  {
    path: '',
    component: CreateSupplierPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CreateSupplierPageRoutingModule {}
