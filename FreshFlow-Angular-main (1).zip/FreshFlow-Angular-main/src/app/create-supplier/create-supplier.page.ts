import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { SupplierService } from '../services/supplier.service';
import { Router } from '@angular/router';
import { Suppliers } from '../Model/supplier';
import { PopoverController } from '@ionic/angular'; // Import PopoverController
 // Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-create-supplier',
  templateUrl: './create-supplier.page.html',
  styleUrls: ['./create-supplier.page.scss'],
})
export class CreateSupplierPage implements OnInit {
  supplierData: Omit<Suppliers, 'id'> = {
    Name: '',
    Location: '',
    Email: ''
  };

  constructor(
    private navCtrl: NavController,
    private supplierService: SupplierService,
    private router: Router,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  ngOnInit() { }

  navigateToSupplier() {
    this.router.navigate(['/view-supplier']);
  }

  register() {
    if (!this.supplierData.Name.trim() || !this.supplierData.Location.trim() || !this.supplierData.Email.trim()) {
      alert('Please fill out all required fields.');
      return;
    }

    this.supplierService.registerSupplier(this.supplierData).subscribe(
      response => {
        console.log('Registration successful', response);
        alert('Supplier added successfully!');
        this.navCtrl.navigateForward('/view-supplier');
      },
      error => {
        console.error('Registration error', error);
        alert(this.getErrorMessage(error));
      }
    );
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to add supplier due to invalid input. Please check the fields and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while adding the supplier. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'name':
        hintMessage = "Enter the supplier's name, e.g., 'Supplier01'.";
        break;
      case 'location':
        hintMessage = "Enter the supplier's location, e.g., 'Pretoria'.";
        break;
      case 'email':
        hintMessage = "Enter a valid email address for the supplier, e.g., 'supplier@gmail.com'.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
