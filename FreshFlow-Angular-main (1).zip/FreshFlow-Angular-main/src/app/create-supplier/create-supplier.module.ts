import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateSupplierPageRoutingModule } from './create-supplier-routing.module';

import { CreateSupplierPage } from './create-supplier.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateSupplierPageRoutingModule
  ],
  declarations: [CreateSupplierPage]
})
export class CreateSupplierPageModule {}
