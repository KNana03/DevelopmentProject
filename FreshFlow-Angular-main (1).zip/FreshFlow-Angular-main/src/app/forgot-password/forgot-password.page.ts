import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthserviceService } from '../services/authservice.service';
import { AlertController, LoadingController } from '@ionic/angular';
import { NavController, PopoverController } from '@ionic/angular'; // Import PopoverController
 // Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.page.html',
  styleUrls: ['./forgot-password.page.scss'],
})
export class ForgotPasswordPage {
  email: string = '';

  constructor(
    private authservice: AuthserviceService,
    private alertController: AlertController,
    private loadingController: LoadingController,
    private navCtrl: NavController,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  async sendOTP(form: NgForm) {
    if (form.invalid) {
      return;
    }

    const loading = await this.loadingController.create({
      message: 'Sending OTP...',
    });
    await loading.present();

    this.authservice.forgotPassword(this.email).subscribe(
      async (response: any) => {
        await loading.dismiss();
        const alert = await this.alertController.create({
          header: 'Success',
          message: response.message,
          buttons: ['OK']
        });
        await alert.present();
        this.navCtrl.navigateForward('/verify-otp', { state: { email: this.email } });
      },
      async (error) => {
        await loading.dismiss();
        const errorMessage = this.getErrorMessage(error);
        const alert = await this.alertController.create({
          header: 'Error',
          message: errorMessage,
          buttons: ['OK']
        });
        await alert.present();
      }
    );
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to send OTP due to invalid input. Please check the email and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while sending OTP. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'email':
        hintMessage = "Enter the email address associated with your account to receive an OTP.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
