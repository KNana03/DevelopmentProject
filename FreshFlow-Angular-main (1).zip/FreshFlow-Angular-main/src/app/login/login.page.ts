import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthserviceService } from '../services/authservice.service';
import { PopoverController } from '@ionic/angular'; // Import PopoverController
 // Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  username: string = '';
  password: string = '';
  alertMessage: string = '';

  constructor(
    private authService: AuthserviceService, 
    private router: Router,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  ngOnInit() { }

  async login() {
    this.alertMessage = '';

    try {
      const credentials = { Username: this.username, Password: this.password };
      const res = await this.authService.login(credentials).toPromise();

      // Store token and username in localStorage
      localStorage.setItem('token', res.token);
      localStorage.setItem('username', res.username); // Store the username directly

      this.router.navigate(['/home']); // Navigate to home page after successful login
    } catch (err: any) {
      this.alertMessage = this.getErrorMessage(err);
    }
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Invalid username or password. Please try again.';
    } else if (error.status === 500) {
      return 'Server error occurred. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'Invalid Username Or Password';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'username':
        hintMessage = "Enter your registered username.";
        break;
      case 'password':
        hintMessage = "Enter your password.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
