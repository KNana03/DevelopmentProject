import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateInventoryPageRoutingModule } from './create-inventory-routing.module';

import { CreateInventoryPage } from './create-inventory.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateInventoryPageRoutingModule
  ],
  declarations: [CreateInventoryPage]
})
export class CreateInventoryPageModule {}
