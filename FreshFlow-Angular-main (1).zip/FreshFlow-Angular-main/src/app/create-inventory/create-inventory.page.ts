import { Component } from '@angular/core';
import { NavController, PopoverController } from '@ionic/angular';
import { InventoryService } from '../services/inventory.service';
import { Inventories } from '../Model/inventory';
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component'; // Import the HintPopoverComponent

@Component({
  selector: 'app-create-inventory',
  templateUrl: './create-inventory.page.html',
  styleUrls: ['./create-inventory.page.scss'],
})
export class CreateInventoryPage {
  // Define inventory data with initial placeholder values
  inventoryData: Omit<Inventories, 'id'> = {
    productId: 0, // Include a placeholder productId
    warehouseId: 0,
    typeId: 1, // Automatically set to non-sellable
    name: '',
    quantity: 0,
    inventoryType: 'Non-Sellable', // Automatically set as non-sellable
  };

  constructor(
    private navCtrl: NavController,
    public inventoryService: InventoryService,
    private popoverController: PopoverController // PopoverController is injected here
  ) {}

  // Navigate back to the inventory list view
  navigateToViewInventory() {
    this.navCtrl.navigateForward(['/view-inventory']);
  }

  // Method to register the inventory item, with validations
  register() {
    console.log('Sending data: ', this.inventoryData);

    // Validate all fields with appropriate hints for the user
    if (!this.inventoryData.name.trim()) {
      alert('Please enter a valid name for the inventory item.');
      return;
    }
    if (this.inventoryData.warehouseId <= 0) {
      alert('Please enter a valid Warehouse ID. It must be a positive number.');
      return;
    }
    if (this.inventoryData.quantity <= 0) {
      alert('Quantity must be greater than zero. Please enter a valid quantity.');
      return;
    }

    // Call the inventory service to register the inventory item
    this.inventoryService.registerInventory(this.inventoryData).subscribe(
      (response) => {
        console.log('Inventory item has been added successfully', response);
        this.navigateToViewInventory(); // Navigate to the inventory view
        alert('Inventory item has been added successfully');
      },
      (error) => {
        console.error('Add error', error);
        let errorMessage = this.getErrorMessage(error);
        alert(errorMessage);
      }
    );
  }

  // Error handling for inventory registration failures
  private getErrorMessage(error: any): string {
    let errorMessage = 'Inventory item could not be added. Please try again.';
    if (error.status === 400) {
      errorMessage = 'Invalid data. Please check the fields and try again.';
      if (error.error && error.error.errors) {
        errorMessage += '\n' + Object.values(error.error.errors).join('\n');
      }
    } else if (error.status === 0) {
      errorMessage = 'Network error. Please check your connection.';
    } else if (error.error && error.error.message) {
      errorMessage = error.error.message;
    }
    return errorMessage;
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'name':
        hintMessage = "Enter a descriptive name for the inventory item, e.g., 'Mop'.";
        break;
      case 'warehouseId':
        hintMessage = 'Enter the ID of the warehouse where this inventory is stored.';
        break;
      case 'quantity':
        hintMessage = 'Enter the number of items available in this inventory.';
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      cssClass: 'custom-popover',  
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
