import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateInventoryPage } from './create-inventory.page';

describe('CreateInventoryPage', () => {
  let component: CreateInventoryPage;
  let fixture: ComponentFixture<CreateInventoryPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateInventoryPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
