import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { StockTakePageRoutingModule } from './stock-take-routing.module';

import { StockTakePage } from './stock-take.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    StockTakePageRoutingModule
  ],
  declarations: [StockTakePage]
})
export class StockTakePageModule {}
