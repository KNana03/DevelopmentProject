import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { StockTakeService } from '../services/stock-take.service';
import { StockTake } from '../Model/StockTake';

@Component({
  selector: 'app-stock-take',
  templateUrl: './stock-take.page.html',
  styleUrls: ['./stock-take.page.scss'],
})
export class StockTakePage implements OnInit {
  stockTake: StockTake = {
    id: 0,
    orderId: 0,
    quantity: 0,
    price: 0,
    date: new Date()
  };

  constructor(
    private route: ActivatedRoute,
    private stockTakeService: StockTakeService
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      const orderId = this.route.snapshot.paramMap.get('orderId');
      if (orderId) {
        this.loadStockTake(+orderId);
      }
    });
  }

  loadStockTake(orderId: number) {
    this.stockTakeService.getStockTakeByOrderId(orderId).subscribe(
      data => {
        console.log('StockTake data:', data); // Log the fetched data for debugging
        this.stockTake = data;
      },
      error => {
        console.error('Error loading stock take', error);
        this.handleError('loading stock take', error);
      }
    );
  }

  private handleError(action: string, error: any) {
    let errorMessage = `An error occurred while ${action}. Please try again later.`;
    if (error.status === 0) {
      errorMessage = 'Network error. Please check your internet connection.';
    } else if (error.status === 404) {
      errorMessage = `No stock take data found for the provided order ID.`;
    } else if (error.status === 500) {
      errorMessage = 'Server error occurred. Please try again later.';
    }
    alert(errorMessage); // You can also use a more sophisticated alert or toast for better UX
  }
}
