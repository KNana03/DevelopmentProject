import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { StockTakePage } from './stock-take.page';

const routes: Routes = [
  {
    path: '',
    component: StockTakePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StockTakePageRoutingModule {}
