import { Component, OnInit } from '@angular/core';
import { SalesService } from '../services/sales.service';
import { StaffService } from '../services/staff.service';
import { InventoryService } from '../services/inventory.service';
import { ShiftService } from '../services/shift.service';
import { ProductService } from '../services/product.service';
import { BusinessRuleService } from '../services/business-rule.service'; // Import BusinessRuleService
import { Chart, registerables } from 'chart.js';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { forkJoin } from 'rxjs';
import { BASE64_LOGO } from '../app.constants';
import { AuthserviceService } from '../services/authservice.service';
import { NavController } from '@ionic/angular';
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;
Chart.register(...registerables);

interface DetailedSale {
  id: number;
  quantity: number;
  date: Date;
  staffName: string;
  shiftName: string;
  inventoryName: string;
  price: number;
  vatAmount: number; // VAT amount
  discounted: boolean; // Flag for discount indicator
}

@Component({
  selector: 'app-sales-report',
  templateUrl: './sales-report.page.html',
  styleUrls: ['./sales-report.page.scss'],
})
export class SalesReportPage implements OnInit {
  salesRecords: DetailedSale[] = [];
  filteredSalesRecords: DetailedSale[] = [];
  totalRevenue: number = 0;
  totalSales: number = 0;
  totalQuantity: number = 0;
  mostSoldItem: string = '';
  lineChart: any;
  pieChart: any;
  currentUserName: string = '';
  selectedStaffName: string = '';
  selectedTimePeriod: string = '1month';

  timePeriods = [
    { label: '1 Week', value: '1week' },
    { label: '1 Month', value: '1month' },
    { label: '3 Months', value: '3months' },
    { label: '6 Months', value: '6months' },
    { label: '1 Year', value: '1year' },
  ];

  constructor(
    private salesService: SalesService,
    private staffService: StaffService,
    private inventoryService: InventoryService,
    private shiftService: ShiftService,
    private productService: ProductService,
    private businessRuleService: BusinessRuleService, // Inject BusinessRuleService
    private authService: AuthserviceService,
    private navCtrl: NavController
  ) {}

  ngOnInit() {
    this.loadBusinessRules(); // Load business rules
    this.currentUserName = this.authService.getCurrentUserName();
    this.loadSalesData();
  }

  loadBusinessRules() {
    this.businessRuleService.loadRules().subscribe((rules) => {
      console.log('Business rules loaded:', rules);
    });
  }

  loadSalesData() {
    this.salesService.getSales().subscribe(
      (salesData) => {
        forkJoin({
          staff: this.staffService.getAllStaffs(),
          inventory: this.inventoryService.getAllInventories(),
          shifts: this.shiftService.getAllShifts(),
          products: this.productService.getProducts(),
        }).subscribe(({ staff, inventory, shifts, products }) => {
          this.salesRecords = salesData.map((sale) => {
            const staffName = staff.find((s) => s.id === sale.staffId)?.firstName || 'Unknown';
            const inventoryName = inventory.find((i) => i.id === sale.inventoryId)?.name || 'Unknown';
            const shiftName = shifts.find((shift) => shift.id === sale.shiftId)?.name || 'Unknown';

            const inventoryItem = inventory.find((i) => i.id === sale.inventoryId);
            const product = products.find((p) => p.productId === inventoryItem?.productId);
            const price = product ? sale.quantity * product.price : 0;

            // Apply 15% VAT to the sale price
            const vatOnSale = price * 0.15;
            const priceWithVAT = price + vatOnSale;

            // Apply discount based on business rules
            const discountPercentage = this.businessRuleService.calculateDiscount(priceWithVAT);
            const finalPrice = priceWithVAT - (priceWithVAT * discountPercentage / 100);
            const discounted = discountPercentage > 0; // Mark as discounted

            return {
              id: sale.id,
              quantity: sale.quantity,
              date: sale.date,
              staffName,
              shiftName,
              inventoryName,
              price: finalPrice, // Final price after VAT and discount
              vatAmount: vatOnSale, // VAT amount
              discounted: discounted, // Discount indicator
            } as DetailedSale;
          });

          this.filterSalesRecords();
        });
      },
      (error) => {
        console.error('Error loading sales data', error);
      }
    );
  }

  filterSalesRecords() {
    const currentDate = new Date();
    const timeFrameStart = this.getTimeFrameStart(currentDate, this.selectedTimePeriod);

    this.filteredSalesRecords = this.salesRecords.filter((sale) => {
      const saleDate = new Date(sale.date);
      return saleDate >= timeFrameStart && saleDate <= currentDate;
    });

    if (this.selectedStaffName) {
      this.filteredSalesRecords = this.filteredSalesRecords.filter(
        (sale) => sale.staffName === this.selectedStaffName
      );
    }

    this.calculateSummary(this.filteredSalesRecords);
    this.initializeCharts();
  }

  getTimeFrameStart(currentDate: Date, period: string): Date {
    const startDate = new Date(currentDate);
    switch (period) {
      case '1week':
        startDate.setDate(startDate.getDate() - 7);
        break;
      case '1month':
        startDate.setMonth(startDate.getMonth() - 1);
        break;
      case '3months':
        startDate.setMonth(startDate.getMonth() - 3);
        break;
      case '6months':
        startDate.setMonth(startDate.getMonth() - 6);
        break;
      case '1year':
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
    }
    return startDate;
  }

  calculateSummary(salesRecords: DetailedSale[]) {
    const totalQuantities = salesRecords.reduce((acc, sale) => {
      acc[sale.inventoryName] = (acc[sale.inventoryName] || 0) + sale.quantity;
      return acc;
    }, {} as Record<string, number>);

    this.mostSoldItem = Object.keys(totalQuantities).reduce(
      (a, b) => (totalQuantities[a] > totalQuantities[b] ? a : b),
      'N/A'
    );

    this.totalRevenue = salesRecords.reduce((sum, sale) => sum + sale.price, 0);
    this.totalSales = salesRecords.length;
    this.totalQuantity = salesRecords.reduce((sum, sale) => sum + sale.quantity, 0);
  }

  initializeCharts() {
    this.initializeLineChart();
    this.initializePieChart();
  }

  initializeLineChart() {
    if (this.lineChart) {
      this.lineChart.destroy();
    }

    const sortedSalesRecords = [...this.filteredSalesRecords].sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    const dates = sortedSalesRecords.map((sale) => new Date(sale.date).toLocaleDateString());
    const quantities = sortedSalesRecords.map((sale) => sale.quantity);

    this.lineChart = new Chart('lineCanvas', {
      type: 'line',
      data: {
        labels: dates,
        datasets: [
          {
            label: 'Sales Quantity',
            data: quantities,
            borderColor: 'rgba(75, 192, 192, 1)',
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            fill: false,
            tension: 0.1,
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: true,
            position: 'top',
          },
        },
        scales: {
          x: {
            display: true,
            title: {
              display: true,
              text: 'Date',
            },
          },
          y: {
            display: true,
            title: {
              display: true,
              text: 'Quantity',
            },
          },
        },
      },
    });
  }

  initializePieChart() {
    if (this.pieChart) {
      this.pieChart.destroy();
    }

    const inventoryNames = [...new Set(this.filteredSalesRecords.map((sale) => sale.inventoryName))];
    const quantities = inventoryNames.map((name) =>
      this.filteredSalesRecords
        .filter((sale) => sale.inventoryName === name)
        .reduce((sum, sale) => sum + sale.quantity, 0)
    );

    this.pieChart = new Chart('pieCanvas', {
      type: 'doughnut',
      data: {
        labels: inventoryNames,
        datasets: [
          {
            label: 'Inventory Sales Distribution',
            data: quantities,
            backgroundColor: [
              '#FF6384',
              '#36A2EB',
              '#FFCE56',
              '#4BC0C0',
              '#9966FF',
              '#FF9F40',
            ],
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: true,
            position: 'right',
          },
        },
      },
    });
  }

  generatePDF() {
    const documentDefinition = {
      content: [
        {
          columns: [
            {
              image: BASE64_LOGO,
              width: 100,
            },
            {
              stack: [
                { text: 'AB Fresh Wholesalers', bold: true, fontSize: 14, alignment: 'right' },
                { text: 'Store 204a, Hall 2, JHB Fresh Produce Market', alignment: 'right' },
                { text: 'City Deep, Johannesburg, 2049', alignment: 'right' },
                { text: `Generated by: ${this.currentUserName}`, style: 'subheader', alignment: 'right' },
                { text: `Report Date: ${new Date().toLocaleDateString()}`, style: 'subheader', alignment: 'right' },
              ],
              alignment: 'right',
            },
          ],
          margin: [0, 0, 0, 20],
        },
        { text: 'Sales Report', style: 'header', alignment: 'center' },
        `Total Revenue: ${this.totalRevenue.toFixed(2)} ZAR`,
        `Total Sales: ${this.totalSales}`,
        `Most Sold Item: ${this.mostSoldItem}`,
        this.getSalesTable(),
        { image: this.lineChart.toBase64Image(), width: 500 },
        { image: this.pieChart.toBase64Image(), width: 500 },
      ],
      styles: {
        header: {
          fontSize: 18,
          bold: true,
          margin: [0, 0, 0, 10],
        },
        tableHeader: {
          bold: true,
          fontSize: 11,
          color: 'black',
        },
      },
      defaultStyle: {
        fontSize: 10,
      },
    };

    pdfMake.createPdf(documentDefinition).download('SalesReport.pdf');
  }

  getSalesTable() {
    const sortedSalesRecords = [...this.filteredSalesRecords].sort((a, b) => {
      if (a.inventoryName === b.inventoryName) {
        return a.staffName.localeCompare(b.staffName);
      }
      return a.inventoryName.localeCompare(b.inventoryName);
    });
  
    const body = [];
    let currentInventory = '';
    let inventorySubtotal = 0;
    let inventoryQuantitySubtotal = 0;
  
    let staffSubtotals: { [key: string]: { quantity: number; total: number } } = {};
  
    // Header row
    body.push([
      { text: 'Sale ID', style: 'tableHeader' },
      { text: 'Inventory Item', style: 'tableHeader' },
      { text: 'Quantity', style: 'tableHeader' },
      { text: 'Staff Name', style: 'tableHeader' },
      { text: 'Shift', style: 'tableHeader' },
      { text: 'Date', style: 'tableHeader' },
      { text: 'Price (ZAR)', style: 'tableHeader' },
      { text: 'Discounted', style: 'tableHeader' }
    ]);
  
    sortedSalesRecords.forEach((sale, index) => {
      const priceWithVAT = sale.price || 0;
  
      // Control break for inventoryName
      if (sale.inventoryName !== currentInventory) {
        if (index > 0) {
          // Add subtotal for the previous inventory group
          body.push([
            { text: `Subtotal for ${currentInventory}`, colSpan: 2, style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' }, 
            {},
            { text: inventoryQuantitySubtotal, style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
            { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
            { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
            { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
            { text: inventorySubtotal.toFixed(2), style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
            { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' }
          ]);
        }
        // Reset subtotals
        inventorySubtotal = 0;
        inventoryQuantitySubtotal = 0;
        currentInventory = sale.inventoryName;
      }
  
      // Add the current sale row
      body.push([
        sale.id !== undefined ? sale.id : 'N/A',
        sale.inventoryName !== undefined ? sale.inventoryName : 'N/A',
        sale.quantity !== undefined ? sale.quantity : 0,
        sale.staffName !== undefined ? sale.staffName : 'N/A',
        sale.shiftName !== undefined ? sale.shiftName : 'N/A',
        sale.date ? new Date(sale.date).toLocaleDateString() : 'N/A',
        priceWithVAT.toFixed(2),  // Price already includes VAT from the backend
        sale.discounted !== undefined ? (sale.discounted ? 'Yes' : 'No') : 'No'
      ]);
  
      // Add to inventory subtotals
      inventorySubtotal += priceWithVAT;
      inventoryQuantitySubtotal += sale.quantity || 0;
  
      // Track staff subtotals
      if (!staffSubtotals[sale.staffName]) {
        staffSubtotals[sale.staffName] = { quantity: 0, total: 0 };
      }
      staffSubtotals[sale.staffName].quantity += sale.quantity || 0;
      staffSubtotals[sale.staffName].total += priceWithVAT;
    });
  
    // Add the final subtotal for the last inventory group
    body.push([
      { text: `Subtotal for ${currentInventory}`, colSpan: 2, style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' }, 
      {},
      { text: inventoryQuantitySubtotal, style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
      { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
      { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
      { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
      { text: inventorySubtotal.toFixed(2), style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
      { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' }
    ]);
  
    // Totals row
    body.push([
      { text: 'Totals:', colSpan: 2, style: 'tableHeader', fillColor: '#D3D3D3' }, 
      {},
      { text: this.totalQuantity !== undefined ? this.totalQuantity.toFixed(2) : '0', style: 'cell' },
      { text: '', style: 'cell' },
      { text: '', style: 'cell' },
      { text: '', style: 'cell' },
      { text: this.totalRevenue !== undefined ? this.totalRevenue.toFixed(2) : '0.00', style: 'cell' },
      { text: '', style: 'cell' }
    ]);
  
    // Add staff subtotals at the very bottom
    Object.keys(staffSubtotals).forEach(staffName => {
      body.push([
        { text: `Subtotal for ${staffName}`, colSpan: 2, style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' }, 
        {},
        { text: staffSubtotals[staffName].quantity.toFixed(2), style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
        { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
        { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
        { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
        { text: staffSubtotals[staffName].total.toFixed(2), style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' },
        { text: '', style: 'subtotal', border: [false, true, false, true], fillColor: '#eeeeee' }
      ]);
    });
  
    return {
      table: {
        headerRows: 1,
        widths: ['auto', '*', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto'],
        body: body
      },
      layout: {
        fillColor: (rowIndex: number) => {
          return rowIndex % 2 === 0 ? '#F5F5F5' : null;  // Add alternating row colors for better readability
        }
      }
    };
  }
  

  openHelp() {
    this.navCtrl.navigateForward('/reporthelpmodal');
  }


  
  getUniqueStaffNames() {
    return [...new Set(this.salesRecords.map((sale) => sale.staffName))];
  }

}
