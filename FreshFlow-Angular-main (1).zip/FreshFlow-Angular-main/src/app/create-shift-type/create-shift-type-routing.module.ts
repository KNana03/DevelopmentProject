import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreateShiftTypePage } from './create-shift-type.page';

const routes: Routes = [
  {
    path: '',
    component: CreateShiftTypePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CreateShiftTypePageRoutingModule {}
