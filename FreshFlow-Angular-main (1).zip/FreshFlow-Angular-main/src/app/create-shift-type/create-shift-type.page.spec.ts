import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateShiftTypePage } from './create-shift-type.page';

describe('CreateShiftTypePage', () => {
  let component: CreateShiftTypePage;
  let fixture: ComponentFixture<CreateShiftTypePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateShiftTypePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
