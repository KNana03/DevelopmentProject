import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateShiftTypePageRoutingModule } from './create-shift-type-routing.module';

import { CreateShiftTypePage } from './create-shift-type.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateShiftTypePageRoutingModule
  ],
  declarations: [CreateShiftTypePage]
})
export class CreateShiftTypePageModule {}
