import { Component, OnInit } from '@angular/core';
import { ShiftType } from '../Model/shift-type';
import { ShiftTypeService } from '../services/shift-type.service';
import { NavController } from '@ionic/angular/common';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-create-shift-type',
  templateUrl: './create-shift-type.page.html',
  styleUrls: ['./create-shift-type.page.scss'],
})
export class CreateShiftTypePage implements OnInit {
  shiftTypeData: Omit<ShiftType, 'id'> = {
    name: '',
    description: ''
  };

  constructor(private navCtrl: NavController, private shiftTypeService: ShiftTypeService) { }

  ngOnInit() { }

  navigateToViewShiftTypes() {
    this.navCtrl.navigateForward(['/view-shift-type']);
  }

  registerShiftType(form: NgForm) {
    if (form.valid) {
      this.shiftTypeService.createShiftType(this.shiftTypeData).subscribe({
        next: (response) => {
          console.log('Shift Type creation successful', response);
          this.navigateToViewShiftTypes();
        },
        error: (error) => {
          console.error('Shift Type creation error', error);
          const errorMessage = this.getErrorMessage(error);
          alert(errorMessage);
        },
        complete: () => {
          // Optionally, handle the completion if needed
        }
      });
    } else {
      console.error('Form is invalid');
      alert('Please fill out all required fields.');
    }
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to create Shift Type due to invalid input. Please check the fields and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while creating the Shift Type. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }
}
