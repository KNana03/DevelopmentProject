import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AnalyticsService } from '../services/analytics.service';
import { InventoryService } from '../services/inventory.service'; // Inventory service to get low stock inventories
import { OrderService } from '../services/order.service';
import { SearchService } from '../services/search.service';
import { Chart, registerables } from 'chart.js';
import { Router, NavigationEnd } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { Order } from '../Model/order';
import { Inventories } from '../Model/inventory'; // Import the inventory model
import { ActivityLogComponent } from '../activity-log/activity-log.component';

Chart.register(...registerables);

interface PageRequest {
  pageName: string;
  requestCount: number;
  userName: string;
  timestamp: Date;
  action: string;
  success: boolean;
  details: string;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  @ViewChild('lineCanvas', { static: true }) private lineCanvas!: ElementRef;
  lineChart: any;
  metrics: any = { totalOrders: 0, totalRevenue: 0, unpaidOrders: 0 };
  productDetails: any = { lowStockItems: 0, allItems: 0 }; // To display the low stock and total items
  query: string = '';
  response: string = '';
  pageRequests: PageRequest[] = [];

  constructor(
    private analyticsService: AnalyticsService,
    private inventoryService: InventoryService, // Inject InventoryService
    private orderService: OrderService,
    private searchService: SearchService,
    private router: Router,
    private modalCtrl: ModalController
  ) {}

  ngOnInit() {
    this.initializePageRequests();
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        const currentPage = event.urlAfterRedirects.split('/').pop() || 'Home';
        this.analyticsService.logPageRequest(currentPage).subscribe();
      }
    });
    this.fetchMetrics();
    this.checkLowStockItems(); // Check low stock items on init
    this.loadPageRequests();
  }

  initializePageRequests() {
    const hasReset = localStorage.getItem('pageRequestsReset');
    if (!hasReset) {
      this.resetPageRequests();
      localStorage.setItem('pageRequestsReset', 'true');
    }
  }

  resetPageRequests() {
    this.analyticsService.resetPageRequests().subscribe(
      () => {
        console.log('Page requests have been reset.');
      },
      (error) => {
        console.error('Error resetting page requests', error);
      }
    );
  }

  fetchMetrics() {
    this.orderService.getAllOrders().subscribe(
      (orders: Order[]) => {
        if (orders) {
          this.metrics.totalOrders = orders.length;
          this.metrics.totalRevenue = orders.reduce((sum, order) => sum + order.price, 0);
          this.metrics.unpaidOrders = orders.filter((order) => !order.isPaid).length;
        }
      },
      (error) => {
        console.error('Error fetching order metrics', error);
      }
    );
  }

  // Fetch low stock items from the InventoryService (like ViewInventoryPage)
  checkLowStockItems() {
    this.inventoryService.getAllInventories().subscribe(
      (inventories: Inventories[]) => {
        this.productDetails.lowStockItems = inventories.filter(item => item.quantity < 50).length; // Count low stock items
        this.productDetails.allItems = inventories.length; // Count all items in inventory
      },
      (error) => {
        console.error('Error fetching inventories for low stock:', error);
      }
    );
  }

  loadPageRequests() {
    this.analyticsService.getPageRequests().subscribe(
      (data) => {
        this.pageRequests = data;
        this.initializeChart();
      },
      (error) => {
        console.error('Error fetching page requests data', error);
      }
    );
  }

  initializeChart() {
    if (this.lineChart) {
      this.lineChart.destroy();
    }

    const groupedByUser = this.pageRequests.reduce((acc, request) => {
      if (!acc[request.userName]) {
        acc[request.userName] = [];
      }
      acc[request.userName].push(request);
      return acc;
    }, {} as { [key: string]: PageRequest[] });

    const datasets = Object.keys(groupedByUser).map((userName, index) => {
      const color = this.getRandomColor(index);
      const userRequests = groupedByUser[userName];
      return {
        label: `Requests by ${userName}`,
        data: userRequests.map((req: PageRequest) => req.requestCount),
        borderColor: color,
        backgroundColor: color.replace('1)', '0.2)'),
        fill: false,
        tension: 0.1,
      };
    });

    const labels = [...new Set(this.pageRequests.map((req) => req.pageName))];

    this.lineChart = new Chart(this.lineCanvas.nativeElement, {
      type: 'line',
      data: {
        labels: labels,
        datasets: datasets,
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: true,
            position: 'top',
          },
          tooltip: {
            callbacks: {
              label: (context) => {
                const index = context.dataIndex;
                const request = this.pageRequests.find((req) => req.pageName === context.label);
                return `User: ${request?.userName}, Requests: ${context.parsed.y}`;
              },
            },
          },
        },
        scales: {
          x: {
            display: true,
            title: {
              display: true,
              text: 'Pages',
            },
          },
          y: {
            display: true,
            title: {
              display: true,
              text: 'Number of Requests',
            },
          },
        },
      },
    });
  }

  async openActivityLog() {
    const modal = await this.modalCtrl.create({
      component: ActivityLogComponent,
      componentProps: {
        logEntries: this.pageRequests
      }
    });
    return await modal.present();
  }

  getRandomColor(index: number): string {
    const colors = [
      'rgba(255, 99, 132, 1)',
      'rgba(54, 162, 235, 1)',
      'rgba(255, 206, 86, 1)',
      'rgba(75, 192, 192, 1)',
      'rgba(153, 102, 255, 1)',
      'rgba(255, 159, 64, 1)',
    ];
    return colors[index % colors.length];
  }

  sendQuery() {
    if (this.query.trim()) {
      this.searchService.generateResponse(this.query).subscribe(
        (res) => {
          this.response = res.choices[0].text.trim();
        },
        (error) => {
          console.error('Error fetching ChatGPT response:', error);
        }
      );
    }
  }

  navigateToSupplier() {
    this.router.navigate(['/view-supplier']);
  }

  navigateToStaff() {
    this.router.navigate(['/view-staffprofile']);
  }

  navigateToCreateProfile() {
    this.router.navigate(['/create-profile']);
  }

  navigateToOrder() {
    this.router.navigate(['/view-orders']);
  }

  navigateToViewProfile() {
    this.router.navigate(['/view-profile']);
  }

  navigateToProduct() {
    this.router.navigate(['/products']);
  }

  navigateToHome() {
    this.router.navigate(['/home']);
  }

  navigateToOrderReport() {
    this.router.navigate(['/order-report']);
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }

  navigateToSettings() {
    this.router.navigate(['/settings']);
  }

  navigateToInventory() {
    this.router.navigate(['/view-inventory']);
  }

  navigateToViewCheckin() {
    this.router.navigate(['/check-in']);
  }

  navigateToViewCheckout() {
    this.router.navigate(['/check-out']);
  }

  navigateToViewSale() {
    this.router.navigate(['/view-sales']);
  }

  navigateToViewShift() {
    this.router.navigate(['/view-shift']);
  }

  navigateToViewInventoryReport() {
    this.router.navigate(['/view-inventory-report']);
  }

  navigateToShiftReport() {
    this.router.navigate(['/shift-report']);
  }
}
