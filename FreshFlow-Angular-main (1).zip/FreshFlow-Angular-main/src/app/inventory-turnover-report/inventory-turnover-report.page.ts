import { Component, OnInit } from '@angular/core';
import { InventoryService } from '../services/inventory.service';
import { AuthserviceService } from '../services/authservice.service';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { BASE64_LOGO } from '../app.constants';
import { NavController, AlertController } from '@ionic/angular';
pdfMake.vfs = pdfFonts.pdfMake.vfs;

interface InventoryTurnover {
  inventoryId: number;
  inventoryName: string;
  totalSales: number;
  averageInventory: number;
  turnoverRatio: number;
}

@Component({
  selector: 'app-inventory-turnover-report',
  templateUrl: './inventory-turnover-report.page.html',
  styleUrls: ['./inventory-turnover-report.page.scss'],
})
export class InventoryTurnoverReportPage implements OnInit {
  turnoverData: InventoryTurnover[] = [];
  highTurnoverData: InventoryTurnover[] = [];
  midTurnoverData: InventoryTurnover[] = [];
  lowTurnoverData: InventoryTurnover[] = [];
  largeInventoryData: InventoryTurnover[] = [];
  smallInventoryData: InventoryTurnover[] = [];
  highestTurnover: InventoryTurnover | null = null;
  lowestTurnover: InventoryTurnover | null = null;
  totalSales: number = 0;
  totalAverageInventory: number = 0;
  overallAverageTurnover: number = 0;
  currentUserName: string = '';
  turnoverThresholdHigh: number = 100; // Threshold for high turnover
  turnoverThresholdLow: number = 50; // Threshold for low turnover
  largeInventoryThreshold: number = 100; // Threshold for large inventory

  constructor(
    private inventoryService: InventoryService,
    private authService: AuthserviceService,
    private navCtrl: NavController,
    private alertCtrl: AlertController
  ) {}

  ngOnInit() {
    this.loadTurnoverData();
    this.currentUserName = this.authService.getCurrentUserName(); // Get the current logged-in username
  }

  loadTurnoverData() {
    this.inventoryService.getInventoryTurnoverReport().subscribe(
      (data) => {
        const dummyData: InventoryTurnover[] = [
          { inventoryId: 103, inventoryName: 'Dummy Product C', totalSales: 100, averageInventory: 80, turnoverRatio: 125 },
          { inventoryId: 104, inventoryName: 'Dummy Product D', totalSales: 300, averageInventory: 200, turnoverRatio: 150 },
          { inventoryId: 105, inventoryName: 'Dummy Product E', totalSales: 150, averageInventory: 100, turnoverRatio: 150 },
          { inventoryId: 106, inventoryName: 'Dummy Product F', totalSales: 50, averageInventory: 60, turnoverRatio: 83.33 },
          { inventoryId: 107, inventoryName: 'Dummy Product G', totalSales: 200, averageInventory: 180, turnoverRatio: 111.11 },
          { inventoryId: 108, inventoryName: 'Dummy Product H', totalSales: 50, averageInventory: 110, turnoverRatio: 45.45 },
          { inventoryId: 109, inventoryName: 'Dummy Product I', totalSales: 60, averageInventory: 70, turnoverRatio: 85.71 },
        ];

        this.turnoverData = [
          ...data.map((item) => ({
            inventoryId: item.inventoryId,
            inventoryName: item.inventoryName,
            totalSales: item.totalSales,
            averageInventory: item.averageInventory,
            turnoverRatio: item.turnoverRatio * 100,
          })),
          ...dummyData,
        ];

        // Split data into groups
        this.highTurnoverData = this.turnoverData.filter(item => item.turnoverRatio >= this.turnoverThresholdHigh);
        this.midTurnoverData = this.turnoverData.filter(item => item.turnoverRatio < this.turnoverThresholdHigh && item.turnoverRatio >= this.turnoverThresholdLow);
        this.lowTurnoverData = this.turnoverData.filter(item => item.turnoverRatio < this.turnoverThresholdLow);

        this.largeInventoryData = this.turnoverData.filter(item => item.averageInventory >= this.largeInventoryThreshold);
        this.smallInventoryData = this.turnoverData.filter(item => item.averageInventory < this.largeInventoryThreshold);

        this.calculateTurnoverStats();
        this.calculateOverallAverageTurnover();
      },
      (error) => {
        console.error('Error loading turnover data', error);
      }
    );
  }

  calculateOverallAverageTurnover() {
    this.totalSales = this.turnoverData.reduce((sum, item) => sum + item.totalSales, 0);
    this.totalAverageInventory = this.turnoverData.reduce((sum, item) => sum + item.averageInventory, 0) / this.turnoverData.length;
    const totalTurnover = this.turnoverData.reduce((sum, item) => sum + item.turnoverRatio, 0);
    this.overallAverageTurnover = this.turnoverData.length ? (totalTurnover / this.turnoverData.length) : 0;
  }

  calculateTurnoverStats() {
    if (this.turnoverData.length > 0) {
      this.highestTurnover = this.turnoverData.reduce((prev, current) => (prev.turnoverRatio > current.turnoverRatio ? prev : current));
      this.lowestTurnover = this.turnoverData.reduce((prev, current) => (prev.turnoverRatio < current.turnoverRatio ? prev : current));
    }
  }

  // Complete PDF Generation Method
  generatePDF() {
    const body = [];
  
    // Add table header
    body.push([
      { text: 'Inventory ID', style: 'tableHeader' },
      { text: 'Inventory Name', style: 'tableHeader' },
      { text: 'Total Sales', style: 'tableHeader' },
      { text: 'Avg Inventory', style: 'tableHeader' }
    ]);
  
    // Helper function to calculate subtotals for each group
    const calculateSubtotals = (data: InventoryTurnover[]) => {
      const totalSales = data.reduce((sum, item) => sum + item.totalSales, 0);
      const totalAvgInventory = data.reduce((sum, item) => sum + item.averageInventory, 0);
      return { totalSales, totalAvgInventory };
    };
  
    // High Turnover Items (colored in green)
    if (this.highTurnoverData.length > 0) {
      body.push([{ text: 'High Turnover Items', colSpan: 4, style: 'highTurnoverGroupHeader', fillColor: '#d4edda' }, {}, {}, {}]);
      this.highTurnoverData.forEach(item => {
        body.push([
          { text: item.inventoryId.toString(), style: 'cell' },
          { text: item.inventoryName, style: 'cell' },
          { text: item.totalSales.toLocaleString(), style: 'cell' },
          { text: item.averageInventory.toLocaleString(), style: 'cell' }
        ]);
      });
  
      const { totalSales, totalAvgInventory } = calculateSubtotals(this.highTurnoverData);
      body.push([
        { text: 'Subtotal for High Turnover Items', colSpan: 2, style: 'subtotal' }, {},
        { text: totalSales.toLocaleString(), style: 'subtotal' },
        { text: totalAvgInventory.toLocaleString(), style: 'subtotal' }
      ]);
    }
  
    // Mid Turnover Items (colored in orange)
    if (this.midTurnoverData.length > 0) {
      body.push([{ text: 'Mid Turnover Items', colSpan: 4, style: 'midTurnoverGroupHeader', fillColor: '#fff3cd' }, {}, {}, {}]);
      this.midTurnoverData.forEach(item => {
        body.push([
          { text: item.inventoryId.toString(), style: 'cell' },
          { text: item.inventoryName, style: 'cell' },
          { text: item.totalSales.toLocaleString(), style: 'cell' },
          { text: item.averageInventory.toLocaleString(), style: 'cell' }
        ]);
      });
  
      const { totalSales, totalAvgInventory } = calculateSubtotals(this.midTurnoverData);
      body.push([
        { text: 'Subtotal for Mid Turnover Items', colSpan: 2, style: 'subtotal' }, {},
        { text: totalSales.toLocaleString(), style: 'subtotal' },
        { text: totalAvgInventory.toLocaleString(), style: 'subtotal' }
      ]);
    }
  
    // Low Turnover Items (colored in red)
    if (this.lowTurnoverData.length > 0) {
      body.push([{ text: 'Low Turnover Items', colSpan: 4, style: 'lowTurnoverGroupHeader', fillColor: '#f8d7da' }, {}, {}, {}]);
      this.lowTurnoverData.forEach(item => {
        body.push([
          { text: item.inventoryId.toString(), style: 'cell' },
          { text: item.inventoryName, style: 'cell' },
          { text: item.totalSales.toLocaleString(), style: 'cell' },
          { text: item.averageInventory.toLocaleString(), style: 'cell' }
        ]);
      });
  
      const { totalSales, totalAvgInventory } = calculateSubtotals(this.lowTurnoverData);
      body.push([
        { text: 'Subtotal for Low Turnover Items', colSpan: 2, style: 'subtotal' }, {},
        { text: totalSales.toLocaleString(), style: 'subtotal' },
        { text: totalAvgInventory.toLocaleString(), style: 'subtotal' }
      ]);
    }
  
    // Large Inventory Items (colored in blue)
    if (this.largeInventoryData.length > 0) {
      body.push([{ text: 'Large Inventory Items', colSpan: 4, style: 'largeInventoryGroupHeader', fillColor: '#cce5ff' }, {}, {}, {}]);
      this.largeInventoryData.forEach(item => {
        body.push([
          { text: item.inventoryId.toString(), style: 'cell' },
          { text: item.inventoryName, style: 'cell' },
          { text: item.totalSales.toLocaleString(), style: 'cell' },
          { text: item.averageInventory.toLocaleString(), style: 'cell' }
        ]);
      });
  
      const { totalSales, totalAvgInventory } = calculateSubtotals(this.largeInventoryData);
      body.push([
        { text: 'Subtotal for Large Inventory Items', colSpan: 2, style: 'subtotal' }, {},
        { text: totalSales.toLocaleString(), style: 'subtotal' },
        { text: totalAvgInventory.toLocaleString(), style: 'subtotal' }
      ]);
    }
  
    // Small Inventory Items (colored in purple)
    if (this.smallInventoryData.length > 0) {
      body.push([{ text: 'Small Inventory Items', colSpan: 4, style: 'smallInventoryGroupHeader', fillColor: '#d6d8db' }, {}, {}, {}]);
      this.smallInventoryData.forEach(item => {
        body.push([
          { text: item.inventoryId.toString(), style: 'cell' },
          { text: item.inventoryName, style: 'cell' },
          { text: item.totalSales.toLocaleString(), style: 'cell' },
          { text: item.averageInventory.toLocaleString(), style: 'cell' }
        ]);
      });
  
      const { totalSales, totalAvgInventory } = calculateSubtotals(this.smallInventoryData);
      body.push([
        { text: 'Subtotal for Small Inventory Items', colSpan: 2, style: 'subtotal' }, {},
        { text: totalSales.toLocaleString(), style: 'subtotal' },
        { text: totalAvgInventory.toLocaleString(), style: 'subtotal' }
      ]);
    }
  
    // Totals row
    body.push([
      { text: 'Totals:', colSpan: 2, style: 'tableHeader' }, {},
      { text: this.totalSales.toLocaleString(), style: 'cell' },
      { text: this.totalAverageInventory.toLocaleString(), style: 'cell' }
    ]);
  
    const docDefinition = {
      content: [
        {
          columns: [
            {
              image: BASE64_LOGO,
              width: 100,
            },
            {
              stack: [
                { text: 'AB Fresh Wholesalers', bold: true, fontSize: 14, alignment: 'right' },
                { text: 'Store 204a, Hall 2, JHB Fresh Produce Market', alignment: 'right' },
                { text: 'City Deep, Johannesburg, 2049', alignment: 'right' },
                { text: `Generated by: ${this.currentUserName}`, alignment: 'right' },
                { text: `Report Date: ${new Date().toLocaleDateString()}`, alignment: 'right' },
              ],
              alignment: 'right'
            }
          ],
          margin: [0, 0, 0, 20]
        },
        { text: 'Inventory Turnover Report', style: 'header', alignment: 'center' },
        {
          columns: [
            {
              width: '50%',
              text: `Highest Turnover\n${this.highestTurnover?.inventoryName ?? 'N/A'}\n${(this.highestTurnover?.totalSales ?? 0).toLocaleString()} sales`,
              style: 'turnoverMetric',
              alignment: 'center',
            },
            {
              width: '50%',
              text: `Lowest Turnover\n${this.lowestTurnover?.inventoryName ?? 'N/A'}\n${(this.lowestTurnover?.totalSales ?? 0).toLocaleString()} sales`,
              style: 'turnoverMetric',
              alignment: 'center',
            },
          ],
        },
        {
          style: 'tableBody',
          table: { headerRows: 1, widths: ['auto', '*', 'auto', 'auto'], body },
          layout: {
            fillColor: function (rowIndex: number, node: any, columnIndex: number) { 
              return rowIndex % 2 === 0 ? '#f9f9f9' : null;
            }
          
          
          }
        }
      ],
      styles: {
        header: { fontSize: 24, bold: true, margin: [0, 0, 0, 10], alignment: 'center' },
        turnoverMetric: { fontSize: 14, margin: [10, 0, 10, 10] },
        tableHeader: { bold: true, fontSize: 14, color: 'white', fillColor: '#4CAF50' },
        highTurnoverGroupHeader: { bold: true, fillColor: '#d4edda', fontSize: 14 },
        midTurnoverGroupHeader: { bold: true, fillColor: '#fff3cd', fontSize: 14 },
        lowTurnoverGroupHeader: { bold: true, fillColor: '#f8d7da', fontSize: 14 },
        largeInventoryGroupHeader: { bold: true, fillColor: '#cce5ff', fontSize: 14 },
        smallInventoryGroupHeader: { bold: true, fillColor: '#d6d8db', fontSize: 14 },
        subtotal: { bold: true, fillColor: '#f2f2f2' },
        tableBody: { margin: [0, 5, 0, 15] },
        cell: { margin: [5, 5, 5, 5] },
      },
      defaultStyle: {
        fontSize: 12,
        columnGap: 20,
      },
    };
  
    pdfMake.createPdf(docDefinition).download('InventoryTurnoverReport.pdf');
  }
  

  // Method to display hints using an alert
  async showHint(hintType: string) {
    let message = '';

    switch (hintType) {
      case 'Turnover Summary':
        message = 'This section provides an overview of your highest and lowest inventory turnovers based on sales data.';
        break;
      case 'Detailed Report':
        message = 'The detailed turnover report shows individual inventory items along with their sales and average inventory.';
        break;
      case 'Inventory ID':
        message = 'This is the unique identifier for each inventory item.';
        break;
        case 'Overall Average Turnover Ratio':
          message = 'This represents the overall efficiency of inventory movement through the business. It is calculated as the total turnover ratio for all inventory items divided by the number of items.\n\nFormula:\nOverall Average Turnover Ratio = (Sum of all turnover ratios) / (Number of inventory items)';
          break;
      
      default:
        message = 'This is additional information to help you understand this section.';
    }

    const alert = await this.alertCtrl.create({
      header: 'Hint',
      message: message,
      buttons: ['OK'],
    });

    await alert.present();
  }

  openHelp() {
    this.navCtrl.navigateForward('/reporthelpmodal');
  }
}
