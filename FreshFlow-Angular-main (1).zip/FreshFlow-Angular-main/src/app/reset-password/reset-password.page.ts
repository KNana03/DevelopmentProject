import { Component } from '@angular/core';
import { AuthserviceService } from '../services/authservice.service';
import { AlertController, NavController, PopoverController } from '@ionic/angular'; // Import PopoverController
// Import HintPopoverComponent
import { HintPopoverComponentComponent } from '../hint-popover-component/hint-popover-component.component';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.page.html',
  styleUrls: ['./reset-password.page.scss'],
})
export class ResetPasswordPage {
  email: string = '';
  password: string = '';
  confirmPassword: string = '';

  constructor(
    private authService: AuthserviceService,
    private alertController: AlertController,
    private navCtrl: NavController,
    private popoverController: PopoverController // Add PopoverController
  ) { }

  ngOnInit() {
    if (history.state.email) {
      this.email = history.state.email;
    }
  }

  async resetPassword() {
    if (this.password !== this.confirmPassword) {
      await this.showAlert('Error', 'Passwords do not match');
      return;
    }

    const resetPasswordData = {
      email: this.email,
      password: this.password
    };

    this.authService.resetPassword(resetPasswordData).subscribe(
      async (response: any) => {
        await this.showAlert('Success', response?.message || 'Password reset successfully');
        this.navCtrl.navigateForward('/login');
      },
      async (error) => {
        const errorMessage = this.getErrorMessage(error);
        await this.showAlert('Error', errorMessage);
      }
    );
  }

  private async showAlert(header: string, message: string) {
    const alert = await this.alertController.create({
      header,
      message,
      buttons: ['OK']
    });
    await alert.present();
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Invalid request. Please check your details and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return error?.error?.message || 'Password reset failed. Please try again.';
    }
  }

  // Method to present hints in a popover for the fields
  async presentHint(field: string) {
    let hintMessage: string;

    // Switch case to provide the appropriate hint based on the field
    switch (field) {
      case 'email':
        hintMessage = "Enter the email address associated with your account.";
        break;
      case 'password':
        hintMessage = "Enter a strong password. Use at least 8 characters, including uppercase, lowercase, and numbers.";
        break;
      case 'confirmPassword':
        hintMessage = "Confirm your new password by entering the same password.";
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Create and present the popover using the HintPopoverComponent
    const popover = await this.popoverController.create({
      component: HintPopoverComponentComponent,
      componentProps: { hintMessage: hintMessage }, // Pass the hint message
      translucent: true,
    });
    return await popover.present();
  }
}
