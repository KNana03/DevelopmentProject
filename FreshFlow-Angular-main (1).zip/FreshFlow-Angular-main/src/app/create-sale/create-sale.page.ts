import { Component, OnInit } from '@angular/core';
import { Sales } from '../Model/sales';
import { Inventories } from '../Model/inventory';
import { Shift } from '../Model/shift';
import { Staffs } from '../Model/staff';
import { Router } from '@angular/router';
import { SalesService } from '../services/sales.service';
import { InventoryService } from '../services/inventory.service';
import { StaffService } from '../services/staff.service';
import { ShiftService } from '../services/shift.service';
import { ProductService } from '../services/product.service';
import { NavController, AlertController } from '@ionic/angular'; // Use AlertController instead of PopoverController
import { BusinessRuleService } from '../services/business-rule.service';

@Component({
  selector: 'app-create-sale',
  templateUrl: './create-sale.page.html',
  styleUrls: ['./create-sale.page.scss'],
})
export class CreateSalePage implements OnInit {
  sale: Sales = {
    id: 0,
    staffId: 0,
    shiftId: 0,
    inventoryId: 0,
    quantity: 0,
    date: new Date(),
    price: 0,
  };
  inventories: Inventories[] = [];
  shifts: Shift[] = [];
  staffs: Staffs[] = [];
  cart: Sales[] = [];
  availableQuantity: number = 0;
  selectedPrice: number = 0;
  formSubmitted: boolean = false;

  constructor(
    private salesService: SalesService,
    private inventoryService: InventoryService,
    private productService: ProductService,
    private staffService: StaffService,
    private shiftService: ShiftService,
    private businessRuleService: BusinessRuleService,
    private router: Router,
    private navCtrl: NavController,
    private alertController: AlertController // Inject AlertController here
  ) {}

  ngOnInit() {
    this.fetchInventories();
    this.fetchStaffs();
    this.fetchShifts();
    this.loadBusinessRules();
  }

  loadBusinessRules() {
    this.businessRuleService.loadRules().subscribe((rules) => {
      console.log('Business rules loaded:', rules);
    });
  }

  fetchInventories() {
    this.inventoryService.getAllInventories().subscribe(
      (data) => {
        this.inventories = data.filter(
          (inventory) => inventory.inventoryType === 'Sellable'
        );
      },
      (error) => {
        console.error('Error fetching inventories', error);
      }
    );
  }

  fetchStaffs() {
    this.staffService.getAllStaffs().subscribe(
      (data) => {
        this.staffs = data;
      },
      (error) => {
        console.error('Error fetching staffs', error);
      }
    );
  }

  fetchShifts() {
    this.shiftService.getAllShifts().subscribe(
      (data) => {
        this.shifts = data;
      },
      (error) => {
        console.error('Error fetching shifts', error);
      }
    );
  }

  onInventoryChange() {
    const selectedInventory = this.inventories.find(
      (inv) => inv.id === this.sale.inventoryId
    );
    if (selectedInventory) {
      this.availableQuantity = selectedInventory.quantity;

      this.productService.getProducts().subscribe(
        (products) => {
          const product = products.find(
            (p) => p.productId === selectedInventory.productId
          );
          if (product) {
            this.selectedPrice = product.price;
            this.sale.price = this.selectedPrice;
          }
        },
        (error) => {
          console.error('Error fetching product price', error);
        }
      );
    }
  }

  async presentHint(field: string) {
    let hintMessage: string;

    switch (field) {
      case 'staff':
        hintMessage = 'Select the staff responsible for making the sale.';
        break;
      case 'shift':
        hintMessage = 'Select the shift during which the sale is made.';
        break;
      case 'inventory':
        hintMessage = 'Select the inventory item being sold.';
        break;
      case 'quantity':
        hintMessage =
          'Enter the quantity of the selected inventory item being sold.';
        break;
      default:
        hintMessage = 'No hint available.';
        break;
    }

    // Use AlertController to show the hint
    const alert = await this.alertController.create({
      header: 'Hint',
      message: hintMessage,
      buttons: ['OK'],
    });

    await alert.present();
  }

  async validateForm(): Promise<string | null> {
    if (!this.sale.staffId) {
      return 'Staff is not selected.';
    }
    if (!this.sale.shiftId) {
      return 'Shift is not selected.';
    }
    if (!this.sale.inventoryId) {
      return 'Inventory is not selected.';
    }
    if (this.sale.quantity <= 0) {
      return 'Quantity must be greater than 0.';
    }
    // if ((this.sale.price ?? 0) <= 0) {
    //   return 'Price is invalid.';
    // }
    return null;
  }

  async addToCart() {
    const errorMessage = await this.validateForm();

    if (errorMessage) {
      // Show an alert if there is an error
      const alert = await this.alertController.create({
        header: 'Form Incomplete',
        message: errorMessage,
        buttons: ['OK'],
      });
      await alert.present();
      return;
    }

    const saleToAdd = { ...this.sale };

    if (saleToAdd.quantity > this.availableQuantity) {
      const alert = await this.alertController.create({
        header: 'Quantity Error',
        message: 'Quantity exceeds available inventory.',
        buttons: ['OK'],
      });
      await alert.present();
      return;
    }

    const price = saleToAdd.price ?? 0;
    const discountPercentage =
      this.businessRuleService.calculateDiscount(price);
    saleToAdd.price = price - (price * discountPercentage) / 100;

    this.cart.push(saleToAdd);

    this.sale = {
      id: 0,
      staffId: this.sale.staffId,
      shiftId: this.sale.shiftId,
      inventoryId: 0,
      quantity: 0,
      date: new Date(),
      price: 0,
    };
    this.availableQuantity = 0;
    this.selectedPrice = 0;
  }

  removeFromCart(index: number) {
    this.cart.splice(index, 1);
  }

  submitSales() {
    if (!this.cart.length) {
      console.error('Cart is empty. Add items to the cart before submitting.');
      return;
    }

    this.salesService.createMultipleSales(this.cart).subscribe({
      next: (response) => {
        console.log('Sales created successfully', response);
        this.router.navigate(['/view-sales']);
      },
      error: (error) => {
        console.error('Error creating sales', error);
      },
    });
  }
}
