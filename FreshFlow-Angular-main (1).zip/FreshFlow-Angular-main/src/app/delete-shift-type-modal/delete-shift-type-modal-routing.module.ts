import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DeleteShiftTypeModalPage } from './delete-shift-type-modal.page';

const routes: Routes = [
  {
    path: '',
    component: DeleteShiftTypeModalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DeleteShiftTypeModalPageRoutingModule {}
