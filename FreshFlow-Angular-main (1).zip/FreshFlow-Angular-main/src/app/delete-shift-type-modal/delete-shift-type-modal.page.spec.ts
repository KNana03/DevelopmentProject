import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DeleteShiftTypeModalPage } from './delete-shift-type-modal.page';

describe('DeleteShiftTypeModalPage', () => {
  let component: DeleteShiftTypeModalPage;
  let fixture: ComponentFixture<DeleteShiftTypeModalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteShiftTypeModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
