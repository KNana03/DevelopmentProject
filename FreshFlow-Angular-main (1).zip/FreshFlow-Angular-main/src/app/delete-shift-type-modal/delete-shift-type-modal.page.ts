import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { ShiftTypeService } from '../services/shift-type.service';

@Component({
  selector: 'app-delete-shift-type-modal',
  templateUrl: './delete-shift-type-modal.page.html',
  styleUrls: ['./delete-shift-type-modal.page.scss'],
})
export class DeleteShiftTypeModalPage implements OnInit {
  ShifttypeId: number = 0;

  constructor(
    private modalController: ModalController,
    private router: Router,
    private ShiftTypeservice: ShiftTypeService
  ) { }

  ngOnInit() { }

  closeModal() {
    this.modalController.dismiss().then(() => {
      this.router.navigate(['/view-shift-type']);
    }).catch((error) => {
      console.error('Error closing modal', error);
      alert('Failed to close the modal. Please try again.');
    });
  }

  confirmDeletion() {
    if (this.ShifttypeId === 0) {
      alert('Invalid Shift Type ID.');
      return;
    }

    this.ShiftTypeservice.deleteShiftType(this.ShifttypeId).subscribe({
      next: response => {
        console.log('Shift type deletion successful', response);
        this.router.navigate(['/view-shift-type']).then(() => {
          this.modalController.dismiss();
        }).catch((error) => {
          console.error('Error navigating to view-shift-type', error);
          alert('Shift type was deleted, but failed to navigate to the shift type view. Please try again.');
        });
      },
      error: error => {
        console.error('Shift type deletion error', error);
        alert(this.getErrorMessage(error));
      }
    });
  }

  private getErrorMessage(error: any): string {
    if (error.status === 400) {
      return 'Failed to delete shift type due to invalid input. Please check the Shift Type ID and try again.';
    } else if (error.status === 500) {
      return 'Server error occurred while deleting the shift type. Please try again later.';
    } else if (error.status === 0) {
      return 'Network error. Please check your connection.';
    } else {
      return 'An unexpected error occurred. Please try again.';
    }
  }
}
