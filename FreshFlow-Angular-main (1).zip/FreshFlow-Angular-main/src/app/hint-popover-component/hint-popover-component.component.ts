import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-hint-popover', // Optionally add a selector
  template: `
    <ion-content class="ion-padding">
      <ion-text>{{ hintMessage }}</ion-text>
    </ion-content>
  `
})
export class HintPopoverComponentComponent {
  @Input() hintMessage!: string; // Definite Assignment Assertion

  constructor() {}
}
